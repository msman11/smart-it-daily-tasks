/**
 * Google Sheets Service Layer
 * 
 * Communicates with a Google Apps Script Web App endpoint.
 * The Apps Script acts as a REST API proxy to a Google Spreadsheet.
 * 
 * Expected Apps Script contract:
 *   POST { action, sheet, payload, id }
 *   Returns JSON { success, data, error }
 * 
 * Sheets: tasks, departments, services, device_types, team_members, notes, settings, activity_logs
 */

let _apiUrl = "";
let _spreadsheetId = "";
let _enabled = false;

export function configureGoogleSheets(apiUrl: string, spreadsheetId: string, enabled: boolean) {
  _apiUrl = apiUrl;
  _spreadsheetId = spreadsheetId;
  _enabled = enabled && !!apiUrl && !!spreadsheetId;
}

export function isGoogleSheetsEnabled() {
  return _enabled;
}

async function request(action: string, sheet: string, payload?: any, id?: string): Promise<any> {
  if (!_enabled || !_apiUrl) {
    return null;
  }

  const body = JSON.stringify({
    spreadsheetId: _spreadsheetId,
    action,
    sheet,
    payload,
    id,
    timestamp: new Date().toISOString(),
  });

  try {
    const response = await fetch(_apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body,
    });

    if (!response.ok) {
      // If CORS blocks reading the response, treat as success for no-cors mode
      console.warn(`Google Sheets API returned ${response.status}`);
      return null;
    }

    const json = await response.json();
    if (json.error) {
      console.error("Google Sheets API Error:", json.error);
      throw new Error(json.error);
    }
    return json.data ?? json;
  } catch (err: any) {
    // For no-cors mode where we can't read response, just log
    if (err.message?.includes("Failed to fetch") || err.message?.includes("NetworkError")) {
      // Try no-cors fallback (fire-and-forget for writes)
      if (action !== "read") {
        try {
          await fetch(_apiUrl, { method: "POST", mode: "no-cors", body });
        } catch {
          // silently fail
        }
      }
      return null;
    }
    console.error("Google Sheets request failed:", err);
    return null;
  }
}

export const googleSheetsService = {
  // --- Generic CRUD ---
  async getAll(sheet: string) {
    return (await request("read", sheet)) || [];
  },

  async create(sheet: string, payload: any) {
    return await request("create", sheet, payload);
  },

  async update(sheet: string, id: string, payload: any) {
    return await request("update", sheet, payload, id);
  },

  async remove(sheet: string, id: string) {
    return await request("delete", sheet, null, id);
  },

  async upsert(sheet: string, payload: any) {
    return await request("upsert", sheet, payload, payload?.id);
  },

  // --- Sync All (backup entire dataset) ---
  async syncAll(data: {
    tasks?: any[];
    departments?: any[];
    services?: any[];
    device_types?: any[];
    team_members?: any[];
    notes?: any[];
    settings?: any;
  }) {
    return await request("sync_all", "all", data);
  },
};
