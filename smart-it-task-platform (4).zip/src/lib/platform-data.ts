export type Language = "ar" | "en";
export type ThemeMode = "light" | "dark" | "system";
export type Priority = "Low" | "Medium" | "High" | "Critical";
export type TaskStatus =
  | "New"
  | "In Progress"
  | "Pending Review"
  | "Completed"
  | "Delayed"
  | "Postponed"
  | "Cancelled";

export type LocalizedText = {
  ar: string;
  en: string;
};

export type YearArchive = {
  year: number;
  closedAt: string;
  closedBy: string;
  locked: boolean;
  stats: {
    totalTasks: number;
    completedTasks: number;
    inProgressTasks: number;
    delayedTasks: number;
    criticalTasks: number;
    completionRate: number;
    productivityRate: number;
    topServices: { name: string; count: number }[];
    topDepartments: { name: string; count: number }[];
    topTechnicians: { name: string; count: number }[];
  };
};

export type IconType = "emoji" | "lucide" | "image";

export type IconData = {
  type: IconType;
  value: string;
};

export type TaskComment = {
  id: string;
  author: string;
  text: LocalizedText;
  time: string;
};

export type Task = {
  id: string;
  title: LocalizedText;
  description: LocalizedText;
  serviceId: string;
  service: LocalizedText;
  priority: Priority;
  status: TaskStatus;
  startDate: string;
  dueDate: string;
  timeLabel: string;
  attachments: string[];
  notes: LocalizedText;
  comments: TaskComment[];
  productivityScore: number;
  assignee: string;
  location: LocalizedText;
  department?: string;
  employeeName?: string;
  deviceType?: string;
  technicianName?: string;
  createdDate?: string;
  executionDate?: string;
  actionsTaken?: LocalizedText;
  finalResolution?: LocalizedText;
  changeLog?: string[];
};

export type Service = {
  id: string;
  name: LocalizedText;
  category: LocalizedText;
  description: LocalizedText;
  iconData: IconData;
  enabled: boolean;
  tickets: number;
  color: string;
  subServices: LocalizedText[];
};

export type Department = {
  id: string;
  name: LocalizedText;
  code: string;
  enabled: boolean;
  order: number;
};

export type DeviceType = {
  id: string;
  name: LocalizedText;
  code: string;
  iconData: IconData;
  enabled: boolean;
  order: number;
};

export type TeamRole =
  | "admin"
  | "it-manager"
  | "supervisor"
  | "technician"
  | "operator"
  | "user";

export const teamRoleLabels: Record<TeamRole, LocalizedText> = {
  admin: { ar: "مدير النظام", en: "System Administrator" },
  "it-manager": { ar: "مدير تقنية المعلومات", en: "IT Manager" },
  supervisor: { ar: "مشرف", en: "Supervisor" },
  technician: { ar: "فني دعم", en: "Support Technician" },
  operator: { ar: "مشغل", en: "Operator" },
  user: { ar: "مستخدم", en: "User" },
};

export const teamRoleOrder: TeamRole[] = [
  "admin",
  "it-manager",
  "supervisor",
  "technician",
  "operator",
  "user",
];

export type TeamMember = {
  id: string;
  employeeCode: string;
  name: LocalizedText;
  email: string;
  mobile: string;
  jobTitle: LocalizedText;
  departmentId: string;
  role: TeamRole;
  photo: string;
  enabled: boolean;
  createdAt: string;
};

export type NoteBlock =
  | { type: "paragraph"; content: LocalizedText }
  | { type: "checklist"; items: { label: LocalizedText; done: boolean }[] }
  | { type: "code"; language: string; code: string }
  | {
      type: "table";
      headers: LocalizedText[];
      rows: LocalizedText[][];
    };

export type Note = {
  id: string;
  title: LocalizedText;
  summary: LocalizedText;
  updatedAt: string;
  tags: string[];
  blocks: NoteBlock[];
  files: string[];
};

export type NotificationItem = {
  id: string;
  channel: "system" | "email" | "mobile";
  type: "info" | "success" | "warning" | "danger";
  read: boolean;
  title: LocalizedText;
  message: LocalizedText;
  time: string;
};

export type MeetingTool = {
  id: string;
  name: string;
  provider: string;
  link: string;
  room: string;
  nextMeeting: string;
  status: "ready" | "scheduled" | "attention";
  accent: string;
};

export type ReportItem = {
  id: string;
  period: "daily" | "weekly" | "monthly" | "yearly";
  title: LocalizedText;
  subtitle: LocalizedText;
  generatedAt: string;
  completionRate: number;
  productivityRate: number;
  delayedTasks: number;
};

export type MessageItem = {
  id: string;
  sender: string;
  subject: LocalizedText;
  preview: LocalizedText;
  time: string;
  unread: boolean;
};

export type AppSettings = {
  systemName: LocalizedText;
  universityName: LocalizedText;
  themeMode: ThemeMode;
  language: Language;
  timezone: string;
  primaryGreen: string;
  primaryBlue: string;
  accentSuccess: string;
  accentWarning: string;
  accentDanger: string;
  fontScale: number;
  sidebarGlass: boolean;
  roundedActions: boolean;
  openAiModel: string;
  openAiEnabled: boolean;
  googleSheetId: string;
  googleAppsScriptUrl: string;
  googleSheetsEnabled: boolean;
  supabaseUrl: string;
  supabaseEnabled: boolean;
  logoDataUrl: string;
  printHeaderColor: string;
  printFooterColor: string;
  showPrintLogo: boolean;
  showPrintFooter: boolean;
  printedFields: string[];
  primaryColor1: string;
  primaryColor2: string;
  successColor: string;
  warningColor: string;
  dangerColor: string;
  bgColor: string;
  cardColor: string;
  headerColor: string;
  sidebarColor: string;
  tableColor: string;
  gradientEnabled: boolean;
  gradientType: "green-blue" | "blue-green" | "custom" | "linear" | "radial" | "angle";
  gradientAngle: number;
  fontArabic: string;
  fontEnglish: string;
  fontSize: "small" | "medium" | "large" | "xlarge" | "custom";
  fontSizeCustom: number;
  fontSizeSystem: number;
  fontSizePage: number;
  fontSizeCard: number;
  fontSizeTable: number;
  fontSizeMenu: number;
  fontSizeButton: number;
  fontSizeModal: number;
  fontSizeReport: number;
  fontSizePrint: number;
  printHeaderBg: string;
  printFooterBg: string;
  printTitleColor: string;
  printTableColor: string;
  printBorderColor: string;
  printTextColor: string;
  printFontArabic: string;
  printFontEnglish: string;
  printTitleSize: number;
  printTableSize: number;
  printFooterSize: number;
  orgLogoUrl: string;
  showOrgLogo: boolean;
  logoSize: "small" | "medium" | "large";
  logoPosition: "right" | "left" | "center";
  showHeaderUni: boolean;
  showHeaderSystem: boolean;
  showHeaderOrg: boolean;
  showHeaderDate: boolean;
  showHeaderTime: boolean;
  showHeaderPage: boolean;
  showFooter: boolean;
  footerText: LocalizedText;
  footerColor: string;
  footerLogo: boolean;
};

export const priorityOrder: Priority[] = ["Critical", "High", "Medium", "Low"];
export const statusOrder: TaskStatus[] = [
  "New",
  "In Progress",
  "Pending Review",
  "Completed",
  "Delayed",
  "Postponed",
  "Cancelled",
];

export const navItems = [
  {
    key: "dashboard",
    route: "/",
    label: { ar: "لوحة التحكم", en: "Dashboard" },
    icon: "LayoutDashboard",
  },
  {
    key: "tasks",
    route: "/tasks",
    label: { ar: "إدارة المهام", en: "Task Management" },
    icon: "ClipboardList",
  },
  {
    key: "smart-day",
    route: "/smart-day",
    label: { ar: "اليوم الذكي", en: "Smart Day" },
    icon: "Zap",
  },
  {
    key: "calendar",
    route: "/calendar",
    label: { ar: "التقويم", en: "Calendar" },
    icon: "CalendarDays",
  },
  {
    key: "departments",
    route: "/departments",
    label: { ar: "الجهات", en: "Departments" },
    icon: "Building2",
  },
  {
    key: "device-types",
    route: "/device-types",
    label: { ar: "أنواع الأجهزة", en: "Device Types" },
    icon: "MonitorSmartphone",
  },
  {
    key: "services",
    route: "/services",
    label: { ar: "الخدمات التقنية", en: "Technical Services" },
    icon: "Wrench",
  },
  {
    key: "notes",
    route: "/notes",
    label: { ar: "الملاحظات", en: "Notes" },
    icon: "NotebookPen",
  },
  {
    key: "reports",
    route: "/reports",
    label: { ar: "التقارير", en: "Reports" },
    icon: "BarChart3",
  },
  {
    key: "notifications",
    route: "/notifications",
    label: { ar: "الإشعارات", en: "Notifications" },
    icon: "BellRing",
  },
  {
    key: "team",
    route: "/team",
    label: { ar: "الفريق", en: "Team" },
    icon: "Users",
  },
  {
    key: "settings",
    route: "/settings",
    label: { ar: "الإعدادات", en: "Settings" },
    icon: "Settings2",
  },
  {
    key: "ai-assistant",
    route: "/ai-assistant",
    label: { ar: "المساعد الذكي", en: "AI Assistant" },
    icon: "Bot",
  },
] as const;

export const defaultSettings: AppSettings = {
  systemName: {
    ar: "نظام المهام اليومية الذكية لتقنية المعلومات",
    en: "Smart IT Daily Tasks System",
  },
  universityName: {
    ar: "جامعة الملك عبدالعزيز",
    en: "King Abdulaziz University",
  },
  themeMode: "system",
  language: "ar",
  timezone: "Asia/Riyadh",
  primaryGreen: "#0F8A5F",
  primaryBlue: "#2563EB",
  accentSuccess: "#22C55E",
  accentWarning: "#F59E0B",
  accentDanger: "#EF4444",
  fontScale: 1,
  sidebarGlass: true,
  roundedActions: true,
  openAiModel: "gpt-4.1-mini",
  openAiEnabled: true,
  googleSheetId: "1MxeqjMMeA1gUEXGp8iMuuyKPhtCqsktQ4JGm9G07Qm8",
  googleAppsScriptUrl: "https://script.google.com/macros/s/AKfycbyWh-8zFhcySBrx5gnSE38IdbbRd0Fy8D8YctHo4Aqb-g04F0Qx25UMOPLdCAoqUKJFjA/exec",
  googleSheetsEnabled: true,
  supabaseUrl: "https://hwgkbumwhvfvsquwlwto.supabase.co",
  supabaseEnabled: true,
  logoDataUrl: "",
  printHeaderColor: "#ffffff",
  printFooterColor: "#f8fafc",
  showPrintLogo: true,
  showPrintFooter: true,
  printedFields: [
    "title",
    "service",
    "description",
    "priority",
    "status",
    "createdDate",
    "executionDate",
    "location",
    "finalResolution",
    "actionsTaken",
  ],
  primaryColor1: "#0F8A5F",
  primaryColor2: "#2563EB",
  successColor: "#22C55E",
  warningColor: "#F59E0B",
  dangerColor: "#EF4444",
  bgColor: "#F8FAFC",
  cardColor: "#FFFFFF",
  headerColor: "#FFFFFF",
  sidebarColor: "#FFFFFF",
  tableColor: "#FFFFFF",
  gradientEnabled: true,
  gradientType: "green-blue",
  gradientAngle: 135,
  fontArabic: "system-ui",
  fontEnglish: "Inter, system-ui, sans-serif",
  fontSize: "medium",
  fontSizeCustom: 16,
  fontSizeSystem: 24,
  fontSizePage: 20,
  fontSizeCard: 18,
  fontSizeTable: 14,
  fontSizeMenu: 14,
  fontSizeButton: 14,
  fontSizeModal: 18,
  fontSizeReport: 16,
  fontSizePrint: 14,
  printHeaderBg: "#ffffff",
  printFooterBg: "#f8fafc",
  printTitleColor: "#0F8A5F",
  printTableColor: "#f8fafc",
  printBorderColor: "#e2e8f0",
  printTextColor: "#0f172a",
  printFontArabic: "system-ui",
  printFontEnglish: "system-ui, sans-serif",
  printTitleSize: 20,
  printTableSize: 12,
  printFooterSize: 11,
  orgLogoUrl: "",
  showOrgLogo: false,
  logoSize: "medium",
  logoPosition: "right",
  showHeaderUni: true,
  showHeaderSystem: true,
  showHeaderOrg: false,
  showHeaderDate: false,
  showHeaderTime: false,
  showHeaderPage: false,
  showFooter: true,
  footerText: {
    ar: "جامعة الملك عبدالعزيز | نظام المهام اليومية الذكية لتقنية المعلومات",
    en: "King Abdulaziz University | Smart IT Daily Tasks System",
  },
  footerColor: "#f8fafc",
  footerLogo: false,
};

export const defaultDepartments: Department[] = [
  { id: "DEP-001", name: { ar: "مكتب العميد", en: "Dean's Office" }, code: "DEAN-OFF", enabled: true, order: 1 },
  { id: "DEP-002", name: { ar: "مكتب وكيل العمادة لشؤون الطلاب للخدمات المساندة", en: "Office of the Vice-Dean of Student Affairs for Support Services" }, code: "VDSS", enabled: true, order: 2 },
  { id: "DEP-003", name: { ar: "مكتب وكيل العمادة لشؤون الطلاب للأنشطة والمهارات", en: "Office of the Vice-Dean of Student Affairs for Activities & Skills" }, code: "VDAS", enabled: true, order: 3 },
  { id: "DEP-004", name: { ar: "مكتب وكيلة العمادة لشؤون الطلاب بشطر الطالبات", en: "Office of the Vice-Dean of Student Affairs for Female Student Section" }, code: "VDFS", enabled: true, order: 4 },
  { id: "DEP-005", name: { ar: "إدارة صندوق الطلاب", en: "Students Fund Administration" }, code: "STDFUND", enabled: true, order: 5 },
  { id: "DEP-006", name: { ar: "إدارة العلاقات العامة والإعلام", en: "Public Relations & Media Administration" }, code: "PRMEDIA", enabled: true, order: 6 },
  { id: "DEP-007", name: { ar: "إدارة التوريدات والخدمات اللوجستية", en: "Supplies & Logistics Services Administration" }, code: "LOGISTIC", enabled: true, order: 7 },
  { id: "DEP-008", name: { ar: "إدارة التحقيقات الطلابية", en: "Student Investigations Administration" }, code: "INVEST", enabled: true, order: 8 },
  { id: "DEP-009", name: { ar: "إدارة المكافآت", en: "Rewards & Allowances Administration" }, code: "REWARDS", enabled: true, order: 9 },
  { id: "DEP-010", name: { ar: "وحدة التطوير والجودة", en: "Development & Quality Unit" }, code: "DQUNIT", enabled: true, order: 10 },
  { id: "DEP-011", name: { ar: "إدارة الصندوق الخيري", en: "Charity Fund Administration" }, code: "CHARITY", enabled: true, order: 11 },
  { id: "DEP-012", name: { ar: "إدارة الشراكات والاتفاقيات الإستراتيجية", en: "Strategic Partnerships & Agreements Administration" }, code: "PARTNER", enabled: true, order: 12 },
  { id: "DEP-013", name: { ar: "إدارة الأندية الطلابية", en: "Student Clubs Administration" }, code: "CLUBS", enabled: true, order: 13 },
  { id: "DEP-014", name: { ar: "إدارة البرامج والأنشطة", en: "Programs & Activities Administration" }, code: "PROGRAMS", enabled: true, order: 14 },
  { id: "DEP-015", name: { ar: "إدارة الشؤون الرياضية", en: "Sports Affairs Administration" }, code: "SPORTS", enabled: true, order: 15 },
  { id: "DEP-016", name: { ar: "إدارة الجوالة", en: "Scout (Jawala) Administration" }, code: "JAWALA", enabled: true, order: 16 },
  { id: "DEP-017", name: { ar: "إدارة الأعمال التطوعية", en: "Volunteer Work Administration" }, code: "VOLUNTEER", enabled: true, order: 17 },
  { id: "DEP-018", name: { ar: "إدارة الإرشاد الجامعي", en: "Academic & University Counseling Administration" }, code: "COUNSEL", enabled: true, order: 18 },
  { id: "DEP-019", name: { ar: "إدارة الموهبة والابتكار", en: "Talent & Innovation Administration" }, code: "INNOVATE", enabled: true, order: 19 },
  { id: "DEP-020", name: { ar: "إدارة الأشخاص ذوي الإعاقة", en: "Persons with Disabilities Administration" }, code: "PWD", enabled: true, order: 20 },
  { id: "DEP-021", name: { ar: "إدارة الخدمات الإشرافية", en: "Supervisory Services Administration" }, code: "SUPSERV", enabled: true, order: 21 },
  { id: "DEP-022", name: { ar: "إدارة خدمة الطلبة", en: "Student Services Administration" }, code: "STUSERV", enabled: true, order: 22 },
  { id: "DEP-023", name: { ar: "إدارة الإسكان", en: "Housing Administration" }, code: "HOUSING", enabled: true, order: 23 },
  { id: "DEP-024", name: { ar: "إدارة التغذية", en: "Nutrition & Catering Administration" }, code: "NUTRITION", enabled: true, order: 24 },
  { id: "DEP-025", name: { ar: "إدارة النقل", en: "Transportation Administration" }, code: "TRANSPORT", enabled: true, order: 25 },
  { id: "DEP-026", name: { ar: "إدارة المنح الدراسية", en: "Scholarships Administration" }, code: "SCHOLAR", enabled: true, order: 26 },
  { id: "DEP-027", name: { ar: "إدارة عمادة شؤون الطلاب بفرع رابغ", en: "Administration of Student Affairs - Rabigh Branch" }, code: "RABIGH", enabled: true, order: 27 },
  { id: "DEP-028", name: { ar: "وحدة الأنشطة والمهارات", en: "Activities & Skills Unit" }, code: "ASUNIT", enabled: true, order: 28 },
  { id: "DEP-029", name: { ar: "وحدة الخدمات المساندة", en: "Support Services Unit" }, code: "SSUNIT", enabled: true, order: 29 },
  { id: "DEP-030", name: { ar: "وحدة الخدمات الإشرافية", en: "Supervisory Services Unit" }, code: "SVUNIT", enabled: true, order: 30 },
  { id: "DEP-031", name: { ar: "إدارة العمادة", en: "Deanship Administration" }, code: "DEANADM", enabled: true, order: 31 },
  { id: "DEP-032", name: { ar: "وحدة الاتصالات الإدارية", en: "Administrative Communications Unit" }, code: "ADCOM", enabled: true, order: 32 },
  { id: "DEP-033", name: { ar: "وحدة الدعم الفني", en: "Technical Support Unit" }, code: "TECHSUP", enabled: true, order: 33 },
  { id: "DEP-034", name: { ar: "وحدة الإمداد", en: "Logistics & Supply Unit" }, code: "SUPPLY", enabled: true, order: 34 },
];

export const defaultTeamMembers: TeamMember[] = [
  { id: "TM-001", employeeCode: "EMP-1001", name: { ar: "محمد السمن", en: "Mohammed Al-Samman" }, email: "m.alsamman@kau.edu.sa", mobile: "0501234567", jobTitle: { ar: "مدير النظام", en: "System Manager" }, departmentId: "DEP-033", role: "admin", photo: "", enabled: true, createdAt: "2024-01-15T08:00:00Z" },
  { id: "TM-002", employeeCode: "EMP-1002", name: { ar: "سارة الغامدي", en: "Sarah Al-Ghamdi" }, email: "s.alghamdi@kau.edu.sa", mobile: "0509876543", jobTitle: { ar: "مشرفة دعم فني", en: "IT Support Supervisor" }, departmentId: "DEP-033", role: "supervisor", photo: "", enabled: true, createdAt: "2024-02-01T08:00:00Z" },
  { id: "TM-003", employeeCode: "EMP-1003", name: { ar: "عمر القحطاني", en: "Omar Al-Qahtani" }, email: "o.alqahtani@kau.edu.sa", mobile: "0551112233", jobTitle: { ar: "فني شبكات", en: "Network Technician" }, departmentId: "DEP-033", role: "technician", photo: "", enabled: true, createdAt: "2024-03-10T08:00:00Z" },
  { id: "TM-004", employeeCode: "EMP-1004", name: { ar: "عائشة الحربي", en: "Aisha Al-Harbi" }, email: "a.alharbi@kau.edu.sa", mobile: "0554445566", jobTitle: { ar: "فنية دعم فني", en: "Support Technician" }, departmentId: "DEP-033", role: "technician", photo: "", enabled: true, createdAt: "2024-04-05T08:00:00Z" },
  { id: "TM-005", employeeCode: "EMP-1005", name: { ar: "فهد المطيري", en: "Fahad Al-Mutairi" }, email: "f.almutairi@kau.edu.sa", mobile: "0567778899", jobTitle: { ar: "فني قاعات ذكية", en: "Smart Classrooms Technician" }, departmentId: "DEP-033", role: "technician", photo: "", enabled: true, createdAt: "2024-05-20T08:00:00Z" },
  { id: "TM-006", employeeCode: "EMP-1006", name: { ar: "نورة العتيبي", en: "Noura Al-Otaibi" }, email: "n.alotaibi@kau.edu.sa", mobile: "0512345678", jobTitle: { ar: "مشغلة أنظمة", en: "Systems Operator" }, departmentId: "DEP-033", role: "operator", photo: "", enabled: true, createdAt: "2024-06-01T08:00:00Z" },
  { id: "TM-007", employeeCode: "EMP-1007", name: { ar: "إياد العمري", en: "Eyad Al-Omari" }, email: "e.alomari@kau.edu.sa", mobile: "0533334444", jobTitle: { ar: "فني صيانة", en: "Maintenance Technician" }, departmentId: "DEP-033", role: "technician", photo: "", enabled: false, createdAt: "2024-07-15T08:00:00Z" },
  { id: "TM-008", employeeCode: "EMP-1008", name: { ar: "فيصل الشهري", en: "Faisal Al-Shahri" }, email: "f.alshahri@kau.edu.sa", mobile: "0599887766", jobTitle: { ar: "مدير تقنية المعلومات", en: "IT Manager" }, departmentId: "DEP-033", role: "it-manager", photo: "", enabled: true, createdAt: "2024-01-10T08:00:00Z" },
];

export const defaultDeviceTypes: DeviceType[] = [
  { id: "DT-001", name: { ar: "حاسب مكتبي", en: "Desktop Computer" }, code: "DESKTOP", iconData: { type: "emoji", value: "🖥️" }, enabled: true, order: 1 },
  { id: "DT-002", name: { ar: "حاسب محمول", en: "Laptop" }, code: "LAPTOP", iconData: { type: "emoji", value: "💻" }, enabled: true, order: 2 },
  { id: "DT-003", name: { ar: "طابعة", en: "Printer" }, code: "PRINTER", iconData: { type: "emoji", value: "🖨️" }, enabled: true, order: 3 },
  { id: "DT-004", name: { ar: "ماسح ضوئي", en: "Scanner" }, code: "SCANNER", iconData: { type: "emoji", value: "📠" }, enabled: true, order: 4 },
  { id: "DT-005", name: { ar: "شاشة تفاعلية", en: "Interactive Display" }, code: "DISPLAY", iconData: { type: "emoji", value: "📺" }, enabled: true, order: 5 },
  { id: "DT-006", name: { ar: "بروجكتر", en: "Projector" }, code: "PROJECTOR", iconData: { type: "emoji", value: "📽️" }, enabled: true, order: 6 },
  { id: "DT-007", name: { ar: "هاتف IP", en: "IP Phone" }, code: "IPPHONE", iconData: { type: "emoji", value: "📞" }, enabled: true, order: 7 },
  { id: "DT-008", name: { ar: "نقطة وصول لاسلكية", en: "Wireless Access Point" }, code: "WAP", iconData: { type: "emoji", value: "📡" }, enabled: true, order: 8 },
  { id: "DT-009", name: { ar: "مبدل شبكة", en: "Network Switch" }, code: "SWITCH", iconData: { type: "emoji", value: "🔌" }, enabled: true, order: 9 },
  { id: "DT-010", name: { ar: "جدار حماية", en: "Firewall" }, code: "FIREWALL", iconData: { type: "emoji", value: "🛡️" }, enabled: true, order: 10 },
  { id: "DT-011", name: { ar: "كاميرا مراقبة", en: "Security Camera" }, code: "CAMERA", iconData: { type: "emoji", value: "📷" }, enabled: true, order: 11 },
  { id: "DT-012", name: { ar: "نظام اجتماعات", en: "Meeting System" }, code: "MEETING", iconData: { type: "emoji", value: "🎤" }, enabled: true, order: 12 },
  { id: "DT-013", name: { ar: "جهاز لوحي", en: "Tablet" }, code: "TABLET", iconData: { type: "emoji", value: "📱" }, enabled: true, order: 13 },
  { id: "DT-014", name: { ar: "خادم", en: "Server" }, code: "SERVER", iconData: { type: "emoji", value: "🖧" }, enabled: true, order: 14 },
  { id: "DT-015", name: { ar: "أجهزة الحاسب", en: "Computer" }, code: "COMPUTER", iconData: { type: "emoji", value: "🖥️" }, enabled: true, order: 15 },
  { id: "DT-016", name: { ar: "أخرى", en: "Other" }, code: "OTHER", iconData: { type: "emoji", value: "🔧" }, enabled: true, order: 16 },
];

export const defaultServices: Service[] = [
  {
    id: "computer-support",
    name: { ar: "دعم أجهزة الحاسب", en: "Computer Support" },
    category: { ar: "الدعم الفني", en: "Support" },
    description: {
      ar: "صيانة الأجهزة الطرفية والمكتبية ودعم المستخدمين اليومي.",
      en: "Daily endpoint maintenance, deskside support, and user assistance.",
    },
    iconData: { type: "lucide", value: "MonitorSmartphone" },
    enabled: true,
    tickets: 0,
    color: "#2563EB",
    subServices: [
      { ar: "دعم الأجهزة", en: "Hardware Support" },
      { ar: "صيانة الأجهزة", en: "Device Maintenance" },
      { ar: "دعم المستخدمين", en: "User Support" },
    ],
  },
  {
    id: "networks",
    name: { ar: "الشبكات", en: "Networks" },
    category: { ar: "البنية التحتية", en: "Infrastructure" },
    description: {
      ar: "إدارة الشبكات السلكية واللاسلكية ونقاط الوصول.",
      en: "Manage wired and wireless networks plus access points.",
    },
    iconData: { type: "lucide", value: "Globe" },
    enabled: true,
    tickets: 0,
    color: "#0F8A5F",
    subServices: [
      { ar: "الشبكات السلكية", en: "Wired Networks" },
      { ar: "الشبكات اللاسلكية", en: "Wireless Networks" },
      { ar: "نقاط الوصول", en: "Access Points" },
    ],
  },
  {
    id: "printers",
    name: { ar: "الطابعات", en: "Printers" },
    category: { ar: "الأجهزة المكتبية", en: "Office Devices" },
    description: {
      ar: "تركيب وإعداد وصيانة الطابعات في جميع المباني.",
      en: "Installation, configuration, and maintenance for campus printers.",
    },
    iconData: { type: "lucide", value: "Printer" },
    enabled: true,
    tickets: 0,
    color: "#8B5CF6",
    subServices: [
      { ar: "التركيب", en: "Installation" },
      { ar: "إعداد", en: "Configuration" },
      { ar: "الصيانة", en: "Maintenance" },
    ],
  },
  {
    id: "scanner",
    name: { ar: "الماسح الضوئي", en: "Scanner" },
    category: { ar: "الأجهزة المكتبية", en: "Office Devices" },
    description: {
      ar: "إدارة الماسحات الضوئية المركزية والمكتبية مع الدعم الوقائي.",
      en: "Manage central and desktop scanners with preventive support.",
    },
    iconData: { type: "lucide", value: "ScanLine" },
    enabled: true,
    tickets: 0,
    color: "#06B6D4",
    subServices: [
      { ar: "التركيب", en: "Installation" },
      { ar: "إعداد", en: "Configuration" },
      { ar: "الصيانة", en: "Maintenance" },
    ],
  },
  {
    id: "email",
    name: { ar: "البريد الإلكتروني", en: "Email" },
    category: { ar: "الخدمات المؤسسية", en: "Enterprise Services" },
    description: {
      ar: "إدارة Outlook وExchange وحسابات المستخدمين.",
      en: "Support Outlook, Exchange, and user account administration.",
    },
    iconData: { type: "lucide", value: "Mail" },
    enabled: true,
    tickets: 0,
    color: "#F59E0B",
    subServices: [
      { ar: "Outlook", en: "Outlook" },
      { ar: "Exchange", en: "Exchange" },
      { ar: "حسابات المستخدمين", en: "User Accounts" },
    ],
  },
  {
    id: "software",
    name: { ar: "البرامج", en: "Software" },
    category: { ar: "التطبيقات", en: "Applications" },
    description: {
      ar: "تركيب البرامج وتحديثها وإدارة التراخيص المؤسسية.",
      en: "Software installation, updates, and enterprise license management.",
    },
    iconData: { type: "lucide", value: "Settings" },
    enabled: true,
    tickets: 0,
    color: "#14B8A6",
    subServices: [
      { ar: "التركيب", en: "Installation" },
      { ar: "التحديثات", en: "Updates" },
      { ar: "التراخيص", en: "Licensing" },
    ],
  },
  {
    id: "operating-systems",
    name: { ar: "أنظمة التشغيل", en: "Operating Systems" },
    category: { ar: "الأنظمة", en: "Systems" },
    description: {
      ar: "إدارة Windows وmacOS وLinux وتهيئة الصور القياسية.",
      en: "Manage Windows, macOS, Linux, and standard device imaging.",
    },
    iconData: { type: "lucide", value: "MonitorCog" },
    enabled: true,
    tickets: 0,
    color: "#3B82F6",
    subServices: [
      { ar: "Windows", en: "Windows" },
      { ar: "macOS", en: "macOS" },
      { ar: "Linux", en: "Linux" },
    ],
  },
  {
    id: "smart-classrooms",
    name: { ar: "القاعات الذكية", en: "Smart Classrooms" },
    category: { ar: "التقنيات التعليمية", en: "EdTech" },
    description: {
      ar: "إدارة الشاشات التفاعلية والبروجكتورات والصوتيات والكاميرات وأنظمة الاجتماعات.",
      en: "Manage displays, projectors, audio, cameras, and meeting systems.",
    },
    iconData: { type: "lucide", value: "Presentation" },
    enabled: true,
    tickets: 0,
    color: "#EC4899",
    subServices: [
      { ar: "الشاشات التفاعلية", en: "Interactive Displays" },
      { ar: "أجهزة العرض", en: "Projectors" },
      { ar: "الصوتيات", en: "Audio Systems" },
      { ar: "الكاميرات", en: "Cameras" },
      { ar: "أنظمة الاجتماعات", en: "Meeting Systems" },
    ],
  },
];

export const defaultTasks: Task[] = [];
export const defaultNotes: Note[] = [];
export const defaultNotifications: NotificationItem[] = [];
export const defaultMeetings: MeetingTool[] = [];
export const defaultReports: ReportItem[] = [];
export const defaultMessages: MessageItem[] = [];
export const weeklyPerformanceData: any[] = [];
export const monthlyPerformanceData: any[] = [];
export const productivityAnalysisData: any[] = [];
export const yearHeatmapData: any[] = [];
export const recentActivities: any[] = [];
