import { supabase } from "./integrations";
import { googleSheetsService, isGoogleSheetsEnabled } from "./google-sheets-service";
import type {
  Task,
  Department,
  Service,
  DeviceType,
  TeamMember,
  Note,
  AppSettings,
} from "./platform-data";

// Backup to Google Sheets after every successful Supabase write
async function syncToSheets(sheet: string, action: string, payload: any) {
  if (!isGoogleSheetsEnabled()) return;
  try {
    if (action === "create" || action === "upsert") {
      await googleSheetsService.upsert(sheet, payload);
    } else if (action === "delete") {
      await googleSheetsService.remove(sheet, payload);
    } else if (action === "update") {
      await googleSheetsService.update(sheet, payload?.id, payload);
    }
  } catch (e) {
    console.warn("[syncToSheets] Google Sheets backup failed:", e);
  }
}

// ══════════════════════════════════════════════════════════════
// Supabase table schema matches YOUR actual database:
//
// tasks:        id UUID, task_number TEXT, title TEXT, description TEXT,
//               department TEXT, employee_name TEXT, service TEXT,
//               device_type TEXT, priority TEXT, status TEXT,
//               technician_name TEXT, created_date, execution_date,
//               notes TEXT, created_by TEXT, updated_by TEXT
//
// departments:  id UUID, name TEXT, active BOOLEAN
// services:     id UUID, name TEXT, color TEXT, icon TEXT, active BOOLEAN
// device_types: id UUID, name TEXT, active BOOLEAN
// team_members: id UUID, employee_code TEXT, full_name TEXT, email TEXT,
//               mobile TEXT, role TEXT, department TEXT, active BOOLEAN
// ══════════════════════════════════════════════════════════════

export const supabaseService = {

  // ─── TASKS ───────────────────────────────────────────────

  async getTasks(): Promise<Task[]> {
    console.log("[supabase] getTasks...");
    const { data, error } = await supabase
      .from("tasks")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) {
      console.error("[supabase] getTasks FAILED:", error.message);
      throw error;
    }
    console.log("[supabase] getTasks OK:", data?.length, "rows");
    return (data || []).map((row: any) => ({
      id: row.id,
      title: { ar: row.title || "", en: row.title || "" },
      description: { ar: row.description || "", en: row.description || "" },
      serviceId: row.service || "",
      service: { ar: row.service || "", en: row.service || "" },
      priority: row.priority || "Medium",
      status: row.status || "New",
      startDate: row.created_date || row.created_at || "",
      dueDate: row.execution_date || row.created_at || "",
      timeLabel: "",
      attachments: [],
      notes: { ar: row.notes || "", en: row.notes || "" },
      comments: [],
      productivityScore: 0,
      assignee: row.technician_name || "",
      location: { ar: row.department || "", en: row.department || "" },
      department: row.department || "",
      employeeName: row.employee_name || "",
      deviceType: row.device_type || "",
      technicianName: row.technician_name || "",
      createdDate: row.created_date || row.created_at || "",
      executionDate: row.execution_date || "",
      actionsTaken: { ar: "", en: "" },
      finalResolution: { ar: "", en: "" },
      changeLog: [],
    })) as Task[];
  },

  async createTask(task: any) {
    const row = {
      task_number: task.id || `TASK-${Date.now()}`,
      title: task.title?.ar || task.title?.en || task.title || "",
      description: task.description?.ar || task.description?.en || task.description || "",
      department: task.department || task.location?.ar || "",
      employee_name: task.employeeName || task.employee_name || "",
      service: task.service?.ar || task.service?.en || task.serviceId || "",
      device_type: task.deviceType || task.device_type || "",
      priority: task.priority || "Medium",
      status: task.status || "New",
      technician_name: task.technicianName || task.technician_name || task.assignee || "",
      execution_date: task.executionDate || task.execution_date || null,
      notes: task.notes?.ar || task.notes?.en || task.notes || "",
      created_by: "Admin",
      updated_by: "Admin",
    };
    console.log("[supabase] createTask:", JSON.stringify(row).slice(0, 300));
    const { data, error } = await supabase.from("tasks").insert([row]).select();
    if (error) {
      console.error("[supabase] createTask FAILED:", error.message, error.code, error.details, error.hint);
      throw new Error(`INSERT failed: ${error.message} (${error.code})`);
    }
    console.log("[supabase] createTask SUCCESS:", data?.[0]?.id);
    syncToSheets("tasks", "create", data?.[0]);
    return data?.[0];
  },

  async updateTask(id: string, task: any) {
    const row: any = { updated_by: "Admin", updated_at: new Date().toISOString() };
    if (task.title) row.title = task.title?.ar || task.title?.en || task.title;
    if (task.description) row.description = task.description?.ar || task.description?.en || task.description;
    if (task.department) row.department = task.department;
    if (task.employeeName) row.employee_name = task.employeeName;
    if (task.service) row.service = task.service?.ar || task.service?.en || task.serviceId;
    if (task.deviceType) row.device_type = task.deviceType;
    if (task.priority) row.priority = task.priority;
    if (task.status) row.status = task.status;
    if (task.technicianName) row.technician_name = task.technicianName;
    if (task.executionDate) row.execution_date = task.executionDate;
    if (task.notes) row.notes = task.notes?.ar || task.notes?.en || task.notes;

    console.log("[supabase] updateTask:", id);
    const { data, error } = await supabase.from("tasks").update(row).eq("id", id).select();
    if (error) {
      console.error("[supabase] updateTask FAILED:", error.message);
      throw new Error(`UPDATE failed: ${error.message}`);
    }
    console.log("[supabase] updateTask SUCCESS");
    syncToSheets("tasks", "update", data?.[0]);
    return data?.[0];
  },

  async deleteTask(id: string) {
    console.log("[supabase] deleteTask:", id);
    const { error } = await supabase.from("tasks").delete().eq("id", id);
    if (error) {
      console.error("[supabase] deleteTask FAILED:", error.message);
      throw new Error(`DELETE failed: ${error.message}`);
    }
    console.log("[supabase] deleteTask SUCCESS");
    syncToSheets("tasks", "delete", id);
  },

  // ─── DEPARTMENTS ─────────────────────────────────────────

  async getDepartments(): Promise<Department[]> {
    const { data, error } = await supabase.from("departments").select("*").order("name");
    if (error) throw error;
    return (data || []).map((row: any) => ({
      id: row.id,
      name: { ar: row.name || "", en: row.name || "" },
      code: row.name?.slice(0, 6)?.toUpperCase() || "",
      enabled: row.active !== false,
      order: 0,
    })) as Department[];
  },

  async upsertDepartment(dep: any) {
    const row = {
      name: dep.name?.ar || dep.name?.en || dep.name || "",
      active: dep.enabled !== false,
    };
    // Try update first, then insert
    if (dep.id && typeof dep.id === "string" && dep.id.length > 10) {
      const { data, error } = await supabase.from("departments").update(row).eq("id", dep.id).select();
      if (!error && data?.length) { syncToSheets("departments", "upsert", data[0]); return data[0]; }
    }
    const { data, error } = await supabase.from("departments").insert([row]).select();
    if (error) throw new Error(`Department save failed: ${error.message}`);
    syncToSheets("departments", "upsert", data?.[0]);
    return data?.[0];
  },

  async deleteDepartment(id: string) {
    const { error } = await supabase.from("departments").delete().eq("id", id);
    if (error) throw new Error(`Department delete failed: ${error.message}`);
    syncToSheets("departments", "delete", id);
  },

  // ─── SERVICES ────────────────────────────────────────────

  async getServices(): Promise<Service[]> {
    const { data, error } = await supabase.from("services").select("*").order("name");
    if (error) throw error;
    return (data || []).map((row: any) => ({
      id: row.id,
      name: { ar: row.name || "", en: row.name || "" },
      category: { ar: "", en: "" },
      description: { ar: "", en: "" },
      emoji: row.icon || "⚙️",
      iconName: "Settings",
      enabled: row.active !== false,
      color: row.color || "#2563EB",
      tickets: 0,
      subServices: [],
    })) as unknown as Service[];
  },

  async upsertService(service: any) {
    const row = {
      name: service.name?.ar || service.name?.en || service.name || "",
      color: service.color || "#2563EB",
      icon: service.emoji || service.icon || "⚙️",
      active: service.enabled !== false,
    };
    if (service.id && typeof service.id === "string" && service.id.length > 10) {
      const { data, error } = await supabase.from("services").update(row).eq("id", service.id).select();
      if (!error && data?.length) { syncToSheets("services", "upsert", data[0]); return data[0]; }
    }
    const { data, error } = await supabase.from("services").insert([row]).select();
    if (error) throw new Error(`Service save failed: ${error.message}`);
    syncToSheets("services", "upsert", data?.[0]);
    return data?.[0];
  },

  async deleteService(id: string) {
    const { error } = await supabase.from("services").delete().eq("id", id);
    if (error) throw new Error(`Service delete failed: ${error.message}`);
    syncToSheets("services", "delete", id);
  },

  // ─── DEVICE TYPES ────────────────────────────────────────

  async getDeviceTypes(): Promise<DeviceType[]> {
    const { data, error } = await supabase.from("device_types").select("*").order("name");
    if (error) throw error;
    return (data || []).map((row: any) => ({
      id: row.id,
      name: { ar: row.name || "", en: row.name || "" },
      code: row.name?.slice(0, 8)?.toUpperCase() || "",
      icon: "🔧",
      enabled: row.active !== false,
      order: 0,
    })) as unknown as DeviceType[];
  },

  async upsertDeviceType(dt: any) {
    const row = {
      name: dt.name?.ar || dt.name?.en || dt.name || "",
      active: dt.enabled !== false,
    };
    if (dt.id && typeof dt.id === "string" && dt.id.length > 10) {
      const { data, error } = await supabase.from("device_types").update(row).eq("id", dt.id).select();
      if (!error && data?.length) { syncToSheets("device_types", "upsert", data[0]); return data[0]; }
    }
    const { data, error } = await supabase.from("device_types").insert([row]).select();
    if (error) throw new Error(`Device type save failed: ${error.message}`);
    syncToSheets("device_types", "upsert", data?.[0]);
    return data?.[0];
  },

  async deleteDeviceType(id: string) {
    const { error } = await supabase.from("device_types").delete().eq("id", id);
    if (error) throw new Error(`Device type delete failed: ${error.message}`);
    syncToSheets("device_types", "delete", id);
  },

  // ─── TEAM MEMBERS ────────────────────────────────────────

  async getTeam(): Promise<TeamMember[]> {
    const { data, error } = await supabase.from("team_members").select("*").order("created_at");
    if (error) throw error;
    return (data || []).map((row: any) => ({
      id: row.id,
      employeeCode: row.employee_code || "",
      name: { ar: row.full_name || "", en: row.full_name || "" },
      email: row.email || "",
      mobile: row.mobile || "",
      jobTitle: { ar: row.role || "", en: row.role || "" },
      departmentId: row.department || "",
      role: (row.role || "technician") as any,
      photo: "",
      enabled: row.active !== false,
      createdAt: row.created_at || "",
    })) as TeamMember[];
  },

  async upsertTeamMember(member: any) {
    const row = {
      employee_code: member.employeeCode || member.employee_code || `EMP-${Date.now()}`,
      full_name: member.name?.ar || member.name?.en || member.full_name || "",
      email: member.email || "",
      mobile: member.mobile || "",
      role: member.role || "technician",
      department: member.departmentId || member.department || "",
      active: member.enabled !== false,
    };
    if (member.id && typeof member.id === "string" && member.id.length > 10) {
      const { data, error } = await supabase.from("team_members").update(row).eq("id", member.id).select();
      if (!error && data?.length) { syncToSheets("team_members", "upsert", data[0]); return data[0]; }
    }
    const { data, error } = await supabase.from("team_members").insert([row]).select();
    if (error) throw new Error(`Team member save failed: ${error.message}`);
    syncToSheets("team_members", "upsert", data?.[0]);
    return data?.[0];
  },

  async deleteTeamMember(id: string) {
    const { error } = await supabase.from("team_members").delete().eq("id", id);
    if (error) throw new Error(`Team member delete failed: ${error.message}`);
    syncToSheets("team_members", "delete", id);
  },

  // ─── NOTES ───────────────────────────────────────────────

  async getNotes(): Promise<Note[]> {
    return [] as Note[];
  },

  async upsertNote(_note: any) {
    return _note;
  },

  async deleteNote(_id: string) {},

  // ─── SETTINGS ────────────────────────────────────────────

  async getSettings(): Promise<AppSettings | null> {
    const { data, error } = await supabase
      .from("settings")
      .select("*")
      .eq("setting_key", "app_settings")
      .maybeSingle();
    if (error) return null;
    return data?.setting_value as AppSettings | null;
  },

  async saveSettings(settings: AppSettings) {
    const { error } = await supabase.from("settings").upsert({
      setting_key: "app_settings",
      setting_value: settings,
    }, { onConflict: "setting_key" });
    if (error) throw new Error(`Settings save failed: ${error.message}`);
    syncToSheets("settings", "upsert", settings);
  },

  // ─── ACTIVITY LOGS ───────────────────────────────────────

  async getActivities() {
    const { data, error } = await supabase
      .from("activity_logs")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) return [];
    return data || [];
  },

  async logActivity(entry: any) {
    await supabase.from("activity_logs").insert([{
      action: entry.action || "",
      user_name: entry.user || "Admin",
      target_table: entry.target || "",
      target_id: entry.target_id || "",
    }]).then(() => {});
  },
};
