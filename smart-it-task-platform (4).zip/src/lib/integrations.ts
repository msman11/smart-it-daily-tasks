import { createClient } from "@supabase/supabase-js";

export const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "https://hwgkbumwhvfvsquwlwto.supabase.co";
export const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || "sb_publishable_iI-i_rBDpYWnAiJKmM3d3w_2Q5J0qGA";

// Debug: Log connection info at startup
console.log("[Supabase] URL:", supabaseUrl);
console.log("[Supabase] Key starts with:", supabaseAnonKey.slice(0, 20) + "...");
console.log("[Supabase] Key length:", supabaseAnonKey.length);
console.log("[Supabase] Key is JWT:", supabaseAnonKey.startsWith("eyJ"));

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false,
  },
  global: {
    headers: {
      'X-Client-Info': 'smart-it-daily-tasks',
    },
  },
});

export type IntegrationStatus = {
  id: "supabase" | "google-sheets" | "openai";
  name: string;
  description: string;
  readyLabel: string;
  features: string[];
};

export const integrationsCatalog: IntegrationStatus[] = [
  {
    id: "supabase",
    name: "Supabase",
    description: "Authentication, realtime database, storage, tasks, notes, services, and notifications.",
    readyLabel: "Realtime backend ready",
    features: ["Auth", "Realtime", "Storage", "Row Security"],
  },
  {
    id: "google-sheets",
    name: "Google Sheets",
    description: "Two-way sync, reporting sheets, import/export, and automatic operational backup.",
    readyLabel: "Spreadsheet sync configured",
    features: ["Tasks Sheet", "Services Sheet", "Reports Sheet", "Backup"],
  },
  {
    id: "openai",
    name: "OpenAI",
    description: "Task prioritization, delay detection, smart planning, and AI-generated summaries.",
    readyLabel: "AI workspace enabled",
    features: ["Prioritization", "Daily Summary", "Rescheduling", "Productivity Insights"],
  },
];
