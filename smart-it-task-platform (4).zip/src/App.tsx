import { useEffect, useMemo, useState } from "react";
import {
  HashRouter,
  NavLink,
  Route,
  Routes,
  useLocation,
  useNavigate,
} from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { supabaseService } from "./lib/supabase-service";
import { configureGoogleSheets } from "./lib/google-sheets-service";
import { subscribeToRealtime, logAudit, lockRecord, unlockRecord, getRecordLock, trackVersion, saveDraft, loadDraft, clearDraft, getSystemHealth, markSyncComplete, type SystemHealth } from "./lib/realtime-engine";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Activity,
  AlarmClock,
  ArrowLeft,
  BarChart3,
  Bell,
  BellRing,
  Bot,
  Brain,
  Building2,
  CalendarCheck2,
  CalendarClock,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  ClipboardList,
  Database,
  Download,
  FileSpreadsheet,
  FileText,
  Globe,
  GripVertical,
  LayoutDashboard,
  Link2,
  LoaderCircle,
  Mail,
  Languages,
  Menu,
  MessageCircleMore,
  Monitor,
  MonitorCog,
  MonitorSmartphone,
  MoonStar,
  NotebookPen,
  Paperclip,
  Pencil,
  Play,
  Plus,
  Presentation,
  Printer,
  RefreshCcw,
  Save,
  ScanLine,
  Search,
  Settings,
  Settings2,
  Sheet,
  ShieldCheck,
  Sparkles,
  Sun,
  Table,
  Upload,
  TimerReset,
  Trash2,
  UserCircle2,
  Users,
  Wrench,
  X,
  Zap,
  type LucideIcon,
} from "lucide-react";
import {
  defaultSettings,
  defaultDepartments,
  defaultDeviceTypes,
  defaultServices,
  defaultTeamMembers,
  teamRoleLabels,
  teamRoleOrder,
  navItems,
  priorityOrder,
  productivityAnalysisData,
  statusOrder,
  weeklyPerformanceData,
  monthlyPerformanceData,
  yearHeatmapData,
  recentActivities,
  type AppSettings,
  type Language,
  type LocalizedText,
  type MeetingTool,
  type Priority,
  type Service,
  type Department,
  type DeviceType,
  type IconData,
  type TeamMember,
  type TeamRole,
  type Task,
  type TaskStatus,
  type Note,
  type NotificationItem,
  type ReportItem,
  type MessageItem,
  type YearArchive,
} from "@/lib/platform-data";
import { integrationsCatalog, supabase, supabaseUrl } from "@/lib/integrations";
import { cn } from "@/utils/cn";

const priorityLabels: Record<Priority, LocalizedText> = {
  Low: { ar: "منخفضة", en: "Low" },
  Medium: { ar: "متوسطة", en: "Medium" },
  High: { ar: "عالية", en: "High" },
  Critical: { ar: "حرجة", en: "Critical" },
};

const statusLabels: Record<TaskStatus, LocalizedText> = {
  New: { ar: "جديدة", en: "New" },
  "In Progress": { ar: "قيد التنفيذ", en: "In Progress" },
  "Pending Review": { ar: "مراجعة", en: "Pending Review" },
  Completed: { ar: "مكتملة", en: "Completed" },
  Delayed: { ar: "متأخرة", en: "Delayed" },
  Postponed: { ar: "مؤجلة", en: "Postponed" },
  Cancelled: { ar: "ملغاة", en: "Cancelled" },
};



const channelLabels: Record<NotificationItem["channel"], LocalizedText> = {
  system: { ar: "النظام", en: "System" },
  email: { ar: "البريد", en: "Email" },
  mobile: { ar: "الجوال", en: "Mobile" },
};

const ticketStatusOptions: TaskStatus[] = ["New", "In Progress", "Completed", "Postponed", "Cancelled"];





// ─── System & Developer Info ─────────────────────────────────
const APP_INFO = {
  name: { ar: "نظام المهام اليومية الذكية لتقنية المعلومات", en: "Smart IT Daily Tasks System" },
  version: "1.0.0",
  developer: { ar: "أ. محمد هزاع سمان", en: "Mohammed Hazzaa Samman" },
  developerLabel: { ar: "إعداد وتطوير", en: "Developed by" },
  copyright: { ar: `© ${new Date().getFullYear()} جميع الحقوق محفوظة`, en: `© ${new Date().getFullYear()} All Rights Reserved` },
  description: {
    ar: "نظام احترافي لإدارة وتنظيم مهام تقنية المعلومات، يدعم تعدد المستخدمين، والتحديث الفوري، والتقارير الذكية، مع تكامل كامل مع Supabase وGoogle Sheets.",
    en: "A professional system for managing and organizing IT tasks, supporting multi-user collaboration, real-time updates, smart reports, with full Supabase and Google Sheets integration.",
  },
};

const uiText = {
  ar: {
    searchPlaceholder: "ابحث في المهام والخدمات والملاحظات والتقارير والمرفقات...",
    welcomeBack: "مرحبًا بعودتك",
    productivityPulse: "نبض الإنتاجية",
    totalTasks: "إجمالي المهام",
    completedTasks: "المهام المكتملة",
    inProgressTasks: "قيد التنفيذ",
    delayedTasks: "المهام المتأخرة",
    todayTasks: "مهام اليوم",
    weeklyTasks: "مهام الأسبوع",
    completionRate: "معدل الإنجاز",
    productivityRate: "معدل الإنتاجية",
    weeklyPerformance: "الأداء الأسبوعي",
    monthlyPerformance: "الإنتاجية الشهرية",
    priorityDistribution: "توزيع المهام حسب الأولوية",
    statusDistribution: "توزيع المهام حسب الحالة",
    productivityAnalysis: "تحليل الإنتاجية",
    recentActivities: "الأنشطة الأخيرة",
    latestTasks: "آخر المهام",
    smartSummary: "الملخص الذكي",
    aiSuggestions: "اقتراحات الذكاء الاصطناعي",
    viewAll: "عرض الكل",
    taskQueue: "جدول اليوم",
    smartServices: "الخدمات التقنية",
    smartMeetings: "الاجتماعات الذكية",
    quickReports: "التقارير السريعة",
    taskManagement: "إدارة المهام",
    addTask: "إضافة مهمة",
    editTask: "تعديل المهمة",
    filters: "الفلاتر",
    startMyDay: "ابدأ يومي الذكي",
    smartDay: "اليوم الذكي",
    smartRecommendations: "توصيات ذكية",
    urgentTasks: "مهام عاجلة",
    delayed: "متأخرة",
    calendar: "التقويم",
    dayView: "يومي",
    weekView: "أسبوعي",
    monthView: "شهري",
    yearView: "سنوي",
    technicalServices: "الخدمات التقنية",
    addService: "إضافة خدمة",
    notes: "الملاحظات",
    reports: "التقارير",
    notifications: "الإشعارات",
    settings: "الإعدادات",
    integrations: "التكاملات",
    saveSettings: "حفظ الإعدادات",
    language: "اللغة",
    theme: "السمة",
    systemName: "اسم النظام",
    universityName: "اسم الجامعة",
    timezone: "المنطقة الزمنية",
    actions: "الإجراءات",
    save: "حفظ",
    cancel: "إلغاء",
    configured: "مفعّل",
    draft: "تجريبي",
    overview: "نظرة عامة",
    export: "تصدير",
    import: "استيراد",
    backup: "نسخة احتياطية",
    realtimeStatus: "حالة آنية",
    aiAssistant: "المساعد الذكي",
    notificationsCenter: "مركز الإشعارات",
    messages: "الرسائل",
    close: "إغلاق",
    print: "طباعة",
    settingsSaved: "تم حفظ الإعدادات محليًا",
    queueOrganized: "تم تنظيم يومك حسب الأولوية والموعد النهائي",
  },
  en: {
    searchPlaceholder: "Search tasks, services, notes, reports, and attachments...",
    welcomeBack: "Welcome back",
    productivityPulse: "Productivity Pulse",
    totalTasks: "Total Tasks",
    completedTasks: "Completed Tasks",
    inProgressTasks: "In Progress",
    delayedTasks: "Delayed Tasks",
    todayTasks: "Today's Tasks",
    weeklyTasks: "Weekly Tasks",
    completionRate: "Completion Rate",
    productivityRate: "Productivity Rate",
    weeklyPerformance: "Weekly Performance",
    monthlyPerformance: "Monthly Performance",
    priorityDistribution: "Priority Distribution",
    statusDistribution: "Status Distribution",
    productivityAnalysis: "Productivity Analysis",
    recentActivities: "Recent Activities",
    latestTasks: "Latest Tasks",
    smartSummary: "Smart Summary",
    aiSuggestions: "AI Suggestions",
    viewAll: "View All",
    taskQueue: "Today's Queue",
    smartServices: "Technical Services",
    smartMeetings: "Smart Meetings",
    quickReports: "Quick Reports",
    taskManagement: "Task Management",
    addTask: "Add Task",
    editTask: "Edit Task",
    filters: "Filters",
    startMyDay: "Start My Day",
    smartDay: "Smart Day",
    smartRecommendations: "Smart Recommendations",
    urgentTasks: "Urgent Tasks",
    delayed: "Delayed",
    calendar: "Calendar",
    dayView: "Daily",
    weekView: "Weekly",
    monthView: "Monthly",
    yearView: "Yearly",
    technicalServices: "Technical Services",
    addService: "Add Service",
    notes: "Notes",
    reports: "Reports",
    notifications: "Notifications",
    settings: "Settings",
    integrations: "Integrations",
    saveSettings: "Save Settings",
    language: "Language",
    theme: "Theme",
    systemName: "System Name",
    universityName: "University Name",
    timezone: "Timezone",
    actions: "Actions",
    save: "Save",
    cancel: "Cancel",
    configured: "Configured",
    draft: "Draft",
    overview: "Overview",
    export: "Export",
    import: "Import",
    backup: "Backup",
    realtimeStatus: "Realtime Status",
    aiAssistant: "AI Assistant",
    notificationsCenter: "Notification Center",
    messages: "Messages",
    close: "Close",
    print: "Print",
    settingsSaved: "Settings saved locally",
    queueOrganized: "Your day was organized by priority and due date",
  },
} as const;

const iconMap: Record<string, LucideIcon> = {
  LayoutDashboard,
  ClipboardList,
  Zap,
  CalendarDays,
  Wrench,
  NotebookPen,
  BarChart3,
  BellRing,
  Settings2,
  Bot,
  Building2,
  Users,
  MonitorSmartphone,
  Globe,
  Printer,
  ScanLine,
  Mail,
  Settings,
  MonitorCog,
  Presentation,
};

const taskFormSchema = z.object({
  id: z.string().optional(),
  status: z.enum(["New", "In Progress", "Completed", "Postponed", "Cancelled"]),
  department: z.string().min(2),
  employeeName: z.string().min(2),
  serviceId: z.string().min(1),
  deviceType: z.string().min(2),
  priority: z.enum(priorityOrder),
  technicianName: z.string().min(2),
  createdDate: z.string().min(1),
  executionDate: z.string().min(1),
  notes: z.string().optional(),
  actionsTaken: z.string().optional(),
  finalResolution: z.string().optional(),
  attachments: z.string().optional(),
});

const settingsFormSchema = z.object({
  systemNameAr: z.string().min(3),
  systemNameEn: z.string().min(3),
  universityNameAr: z.string().min(3),
  universityNameEn: z.string().min(3),
  timezone: z.string().min(3),
  language: z.enum(["ar", "en"]),
  themeMode: z.enum(["light", "dark", "system"]),
  primaryGreen: z.string().regex(/^#([0-9A-Fa-f]{6})$/),
  primaryBlue: z.string().regex(/^#([0-9A-Fa-f]{6})$/),
  openAiModel: z.string().min(2),
  googleSheetId: z.string().min(2),
  googleAppsScriptUrl: z.string().url().or(z.string().length(0)),
  supabaseUrl: z.string().url(),
});

type TaskFormValues = z.infer<typeof taskFormSchema>;
type SettingsFormValues = z.infer<typeof settingsFormSchema>;

type SearchResult = {
  id: string;
  type: "task" | "service" | "note" | "report" | "attachment";
  title: string;
  subtitle: string;
  route: string;
};

type AnalyticsSnapshot = {
  totalTasks: number;
  completedTasks: number;
  inProgressTasks: number;
  delayedTasks: number;
  todayTasks: number;
  weeklyTasks: number;
  completionRate: number;
  productivityRate: number;
  averageCompletionTime: string;
  priorityDistribution: { name: string; value: number; fill: string }[];
  statusDistribution: { name: string; value: number; fill: string }[];
  serviceDistribution: { name: string; value: number }[];
};

type AiInsightPack = {
  urgent: Task[];
  delayed: Task[];
  today: Task[];
  smartPlan: Task[];
  suggestions: LocalizedText[];
  summary: LocalizedText;
};

function localized(text: LocalizedText | undefined | null, language: Language): string {
  if (!text) return "";
  if (typeof text === "string") return text;
  return text[language] ?? text.ar ?? text.en ?? "";
}

function usePersistentState<T>(key: string, initialValue: T) {
  const [value, setValue] = useState<T>(() => {
    if (typeof window === "undefined") {
      return initialValue;
    }

    try {
      const stored = window.localStorage.getItem(key);
      return stored ? (JSON.parse(stored) as T) : initialValue;
    } catch {
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // Ignore storage failures.
    }
  }, [key, value]);

  return [value, setValue] as const;
}

function getPriorityRank(priority: Priority) {
  return priorityOrder.indexOf(priority);
}

function getTaskStatusColor(status: TaskStatus) {
  return {
    New: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200",
    "In Progress": "bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-200",
    "Pending Review": "bg-violet-100 text-violet-700 dark:bg-violet-500/15 dark:text-violet-200",
    Completed: "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-200",
    Delayed: "bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-200",
    Postponed: "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-200",
    Cancelled: "bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-200",
  }[status];
}

function getPriorityColor(priority: Priority) {
  return {
    Low: "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-200",
    Medium: "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-200",
    High: "bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-200",
    Critical: "bg-fuchsia-100 text-fuchsia-700 dark:bg-fuchsia-500/15 dark:text-fuchsia-200",
  }[priority];
}

function getNotificationTypeColor(type: NotificationItem["type"]) {
  return {
    info: "bg-blue-500",
    success: "bg-emerald-500",
    warning: "bg-amber-500",
    danger: "bg-rose-500",
  }[type];
}

function formatShortDate(date: string, language: Language) {
  return new Intl.DateTimeFormat(language === "ar" ? "ar-SA" : "en-US", {
    month: "short",
    day: "numeric",
  }).format(new Date(date));
}

function isSameDay(dateA: string, dateB: Date) {
  const a = new Date(dateA);
  return (
    a.getFullYear() === dateB.getFullYear() &&
    a.getMonth() === dateB.getMonth() &&
    a.getDate() === dateB.getDate()
  );
}

function isWithinDays(dateString: string, days: number) {
  const now = new Date();
  const end = new Date();
  end.setDate(now.getDate() + days);
  const target = new Date(dateString);
  return target >= now && target <= end;
}

function getDateInputValue(dateString: string) {
  return new Date(dateString).toISOString().slice(0, 10);
}

function getWeekDates(reference = new Date()) {
  const date = new Date(reference);
  const day = date.getDay();
  const diff = (day + 6) % 7;
  date.setDate(date.getDate() - diff);
  return Array.from({ length: 7 }, (_, index) => {
    const next = new Date(date);
    next.setDate(date.getDate() + index);
    return next;
  });
}

function buildAnalytics(tasks: Task[]): AnalyticsSnapshot {
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter((task) => task.status === "Completed").length;
  const inProgressTasks = tasks.filter((task) => task.status === "In Progress").length;
  const delayedTasks = tasks.filter((task) => task.status === "Delayed").length;
  const todayTasks = tasks.filter((task) => isSameDay(task.dueDate, new Date())).length;
  const weeklyTasks = tasks.filter((task) => isWithinDays(task.dueDate, 7)).length;
  const completionRate = totalTasks ? Math.round((completedTasks / totalTasks) * 100) : 0;
  const productivityRate = totalTasks
    ? Math.round(tasks.reduce((sum, task) => sum + task.productivityScore, 0) / totalTasks)
    : 0;

  const priorityDistribution = priorityOrder.map((priority) => ({
    name: priority,
    value: tasks.filter((task) => task.priority === priority).length,
    fill:
      {
        Critical: "#A855F7",
        High: "#EF4444",
        Medium: "#F59E0B",
        Low: "#22C55E",
      }[priority] || "#2563EB",
  }));

  const statusDistribution = statusOrder.map((status) => ({
    name: status,
    value: tasks.filter((task) => task.status === status).length,
    fill:
      {
        New: "#94A3B8",
        "In Progress": "#2563EB",
        "Pending Review": "#8B5CF6",
        Completed: "#22C55E",
        Delayed: "#EF4444",
        Postponed: "#F59E0B",
        Cancelled: "#64748B",
      }[status] || "#2563EB",
  }));

  const serviceCounts = new Map<string, number>();
  tasks.forEach((task) => {
    serviceCounts.set(task.service.en, (serviceCounts.get(task.service.en) || 0) + 1);
  });

  const serviceDistribution = Array.from(serviceCounts.entries())
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 5);

  return {
    totalTasks,
    completedTasks,
    inProgressTasks,
    delayedTasks,
    todayTasks,
    weeklyTasks,
    completionRate,
    productivityRate,
    averageCompletionTime: "1.8d",
    priorityDistribution,
    statusDistribution,
    serviceDistribution,
  };
}

function buildAiInsights(tasks: Task[]): AiInsightPack {
  const activeTasks = tasks.filter((task) => task.status !== "Completed" && task.status !== "Cancelled");
  const urgent = [...activeTasks]
    .filter((task) => task.priority === "Critical" || task.priority === "High")
    .sort((a, b) => getPriorityRank(a.priority) - getPriorityRank(b.priority))
    .slice(0, 4);
  const delayed = activeTasks.filter((task) => task.status === "Delayed");
  const today = activeTasks.filter((task) => isSameDay(task.dueDate, new Date()));
  const smartPlan = [...activeTasks].sort((a, b) => {
    const priorityGap = getPriorityRank(a.priority) - getPriorityRank(b.priority);
    if (priorityGap !== 0) return priorityGap;
    return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
  });

  const suggestions: LocalizedText[] = [
    {
      ar: delayed.length
        ? `لديك ${delayed.length} مهام متأخرة؛ أنصح بجدولتها خلال أول ساعتين.`
        : "لا توجد مهام متأخرة حاليًا، استمر بالحفاظ على الإيقاع اليومي.",
      en: delayed.length
        ? `You have ${delayed.length} delayed tasks; schedule them in the first two hours.`
        : "No delayed tasks right now—keep the current daily rhythm.",
    },
    {
      ar: urgent.length
        ? `ابدأ بمهمة ${localized(urgent[0].title, "ar")} لأنها الأعلى تأثيرًا اليوم.`
        : "ابدأ بالمهام الجديدة ذات الجهد المنخفض لتسريع الإنجاز المبكر.",
      en: urgent.length
        ? `Start with ${localized(urgent[0].title, "en")} because it has the highest impact today.`
        : "Start with low-effort new items to create early momentum.",
    },
    {
      ar: "فعّل مزامنة Google Sheets بعد نهاية اليوم لحفظ النسخة الاحتياطية التشغيلية.",
      en: "Trigger Google Sheets sync at the end of the day for operational backup.",
    },
  ];

  return {
    urgent,
    delayed,
    today,
    smartPlan,
    suggestions,
    summary: {
      ar: `اليوم يحتوي على ${today.length} مهام، منها ${urgent.length} ذات أولوية عالية أو حرجة.`,
      en: `Today includes ${today.length} tasks, with ${urgent.length} high or critical priorities.`,
    },
  };
}

function downloadAsJson(filename: string, payload: unknown) {
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

function escapeHtml(value: string | number) {
  return String(value).replace(/[&<>"']/g, (char) => {
    const entities: Record<string, string> = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    };
    return entities[char] || char;
  });
}

function printTaskDocument(task: Task, language: Language, settings: AppSettings) {
  const isArabic = language === "ar";
  const dir = isArabic ? "rtl" : "ltr";
  const printWindow = window.open("", "_blank", "width=900,height=900");
  if (!printWindow) return;

  const now = new Date();
  const dateStr = now.toLocaleDateString(language === "ar" ? "ar-SA" : "en-US");
  const timeStr = now.toLocaleTimeString(language === "ar" ? "ar-SA" : "en-US");

  const fields = settings.printedFields || [];
  const showField = (key: string) => fields.includes(key);

  const getPriorityColor = (p: string) => {
    if (p === "Critical") return settings.dangerColor || "#EF4444";
    if (p === "High") return settings.warningColor || "#F59E0B";
    if (p === "Medium") return settings.primaryColor2 || "#2563EB";
    return settings.successColor || "#22C55E";
  };

  const getStatusColor = (s: string) => {
    if (s === "Completed") return settings.successColor || "#22C55E";
    if (s === "In Progress") return settings.primaryColor2 || "#2563EB";
    if (s === "Delayed") return settings.dangerColor || "#EF4444";
    return "#64748B";
  };

  const logoSizeMap = { small: "40px", medium: "60px", large: "80px" };
  const logoSize = logoSizeMap[settings.logoSize || "medium"];
  const logoHtml = settings.showPrintLogo && settings.logoDataUrl 
    ? `<img src="${settings.logoDataUrl}" alt="Logo" style="height: ${logoSize}; width: auto; object-fit: contain;" />` 
    : `<div style="width: ${logoSize}; height: ${logoSize}; background: linear-gradient(135deg, ${settings.primaryColor1 || "#0F8A5F"}, ${settings.primaryColor2 || "#2563EB"}); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 24px;">IT</div>`;

  const headerBg = settings.printHeaderBg || settings.printHeaderColor || "#ffffff";
  const footerBg = settings.printFooterBg || settings.printFooterColor || "#f8fafc";
  const titleColor = settings.printTitleColor || settings.primaryColor1 || "#0F8A5F";
  const tableColor = settings.printTableColor || "#f8fafc";
  const borderColor = settings.printBorderColor || "#e2e8f0";
  const textColor = settings.printTextColor || "#0f172a";
  const printFont = isArabic ? (settings.printFontArabic || "system-ui") : (settings.printFontEnglish || "system-ui, sans-serif");
  const titleSize = settings.printTitleSize || 20;
  const tableSize = settings.printTableSize || 12;
  const footerSize = settings.printFooterSize || 11;

  const logoPosMap = { right: "order-first", left: "order-last", center: "order-1" };
  const logoOrder = logoPosMap[settings.logoPosition || "right"];

  printWindow.document.write(`<!doctype html>
    <html lang="${language}" dir="${dir}">
      <head>
        <meta charset="UTF-8" />
        <title>${escapeHtml(localized(task.title, language))}</title>
        <style>
          @page { size: A4 portrait; margin: 15mm; }
          * { box-sizing: border-box; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          body {
            margin: 0; padding: 0;
            background: #ffffff;
            color: ${textColor};
            font-family: ${printFont};
            line-height: 1.6;
            font-size: ${settings.fontSizePrint || 14}px;
          }
          .container { max-width: 210mm; margin: 0 auto; padding: 20px; }
          
          /* Header */
          .header {
            display: flex; justify-content: space-between; align-items: center;
            background: ${headerBg}; padding: 20px; border-radius: 16px;
            margin-bottom: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
          }
          .header-title { text-align: center; flex: 1; }
          .header-title h1 { margin: 0; font-size: ${titleSize}px; color: ${titleColor}; font-weight: 800; }
          .header-title h2 { margin: 4px 0 0; font-size: 14px; color: ${settings.primaryColor2 || "#2563EB"}; font-weight: 600; }
          
          /* Info Bar */
          .info-bar {
            display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin-bottom: 24px;
          }
          .info-card {
            border: 1px solid ${borderColor}; border-radius: 12px; padding: 12px; text-align: center;
            background: #f8fafc;
          }
          .info-card .label { font-size: 11px; color: #64748b; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.05em; }
          .info-card .value { font-size: 14px; font-weight: 700; color: ${textColor}; }
          
          /* Sections */
          .section-title {
            font-size: 16px; font-weight: 800; color: ${titleColor}; margin: 24px 0 12px;
            padding-bottom: 8px; border-bottom: 2px solid ${borderColor};
          }
          .details-grid {
            display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px;
          }
          .detail-item {
            border: 1px solid ${borderColor}; border-radius: 12px; padding: 12px 16px; background: #ffffff;
          }
          .detail-item .label { font-size: 12px; color: #64748b; margin-bottom: 4px; }
          .detail-item .value { font-size: 15px; font-weight: 600; color: ${textColor}; }
          
          /* Table */
          table { width: 100%; border-collapse: collapse; margin-top: 12px; }
          th, td { border: 1px solid ${borderColor}; padding: 10px 12px; text-align: ${isArabic ? "right" : "left"}; font-size: ${tableSize}px; }
          th { background: ${tableColor}; color: ${textColor}; font-weight: 700; }
          .badge {
            display: inline-block; padding: 4px 10px; border-radius: 999px;
            font-size: 11px; font-weight: 700; color: white;
          }
          
          /* Footer */
          .footer {
            position: fixed; bottom: 0; left: 0; right: 0;
            background: ${footerBg}; padding: 12px 20px; text-align: center;
            font-size: ${footerSize}px; color: #64748b; border-top: 1px solid ${borderColor};
          }
          .footer p { margin: 2px 0; }
          
          @media print {
            body { background: white; }
            .container { padding: 0; }
            .footer { position: fixed; bottom: 0; }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            ${settings.showPrintLogo ? `<div class="${logoOrder}">${logoHtml}</div>` : "<div></div>"}
            <div class="header-title">
              ${settings.showHeaderUni ? `<h1>${escapeHtml(localized(settings.universityName, language))}</h1>` : ""}
              ${settings.showHeaderSystem ? `<h2>${escapeHtml(localized(settings.systemName, language))}</h2>` : ""}
              ${settings.showHeaderOrg && settings.orgLogoUrl ? `<div style="margin-top: 4px;"><img src="${settings.orgLogoUrl}" style="height: 30px;" /></div>` : ""}
            </div>
            <div style="width: ${logoSize}; text-align: end; font-size: 12px; color: #64748b;">
              ${settings.showHeaderDate ? `<div>${escapeHtml(dateStr)}</div>` : ""}
              ${settings.showHeaderTime ? `<div>${escapeHtml(timeStr)}</div>` : ""}
              ${settings.showHeaderPage ? `<div>صفحة 1</div>` : ""}
            </div>
          </div>

          <div class="info-bar">
            <div class="info-card"><div class="label">${isArabic ? "رقم المهمة" : "Task ID"}</div><div class="value">${escapeHtml(task.id)}</div></div>
            <div class="info-card"><div class="label">${isArabic ? "الجهة" : "Department"}</div><div class="value">${escapeHtml(task.department || localized(task.location, language))}</div></div>
            <div class="info-card"><div class="label">${isArabic ? "اسم الفني" : "Technician"}</div><div class="value">${escapeHtml(task.technicianName || task.assignee)}</div></div>
            <div class="info-card"><div class="label">${isArabic ? "تاريخ الطباعة" : "Print Date"}</div><div class="value">${escapeHtml(dateStr)}</div></div>
            <div class="info-card"><div class="label">${isArabic ? "وقت الطباعة" : "Print Time"}</div><div class="value">${escapeHtml(timeStr)}</div></div>
          </div>

          <div class="section-title">${isArabic ? "تفاصيل المهمة" : "Task Details"}</div>
          <div class="details-grid">
            ${showField("title") ? `<div class="detail-item"><div class="label">${isArabic ? "عنوان المهمة" : "Title"}</div><div class="value">${escapeHtml(localized(task.title, language))}</div></div>` : ""}
            ${showField("service") ? `<div class="detail-item"><div class="label">${isArabic ? "نوع الخدمة" : "Service Type"}</div><div class="value">${escapeHtml(localized(task.service, language))}</div></div>` : ""}
            ${showField("priority") ? `<div class="detail-item"><div class="label">${isArabic ? "الأولوية" : "Priority"}</div><div class="value"><span class="badge" style="background:${getPriorityColor(task.priority)}">${escapeHtml(localized(priorityLabels[task.priority], language))}</span></div></div>` : ""}
            ${showField("status") ? `<div class="detail-item"><div class="label">${isArabic ? "حالة المهمة" : "Status"}</div><div class="value"><span class="badge" style="background:${getStatusColor(task.status)}">${escapeHtml(localized(statusLabels[task.status], language))}</span></div></div>` : ""}
            ${showField("createdDate") ? `<div class="detail-item"><div class="label">${isArabic ? "تاريخ الإنشاء" : "Created Date"}</div><div class="value">${escapeHtml(getDateInputValue(task.createdDate || task.startDate))}</div></div>` : ""}
            ${showField("executionDate") ? `<div class="detail-item"><div class="label">${isArabic ? "تاريخ التنفيذ" : "Execution Date"}</div><div class="value">${escapeHtml(getDateInputValue(task.executionDate || task.dueDate))}</div></div>` : ""}
            ${showField("location") ? `<div class="detail-item"><div class="label">${isArabic ? "الموقع" : "Location"}</div><div class="value">${escapeHtml(localized(task.location, language))}</div></div>` : ""}
          </div>

          ${showField("description") ? `<div class="section-title">${isArabic ? "الوصف" : "Description"}</div><div class="detail-item" style="margin-bottom: 16px;"><div class="value" style="font-size: 14px; font-weight: 400;">${escapeHtml(localized(task.description, language))}</div></div>` : ""}
          ${showField("actionsTaken") ? `<div class="section-title">${isArabic ? "الإجراءات التي تم تنفيذها" : "Actions Taken"}</div><div class="detail-item" style="margin-bottom: 16px;"><div class="value" style="font-size: 14px; font-weight: 400;">${escapeHtml(task.actionsTaken ? localized(task.actionsTaken, language) : "-")}</div></div>` : ""}
          ${showField("finalResolution") ? `<div class="section-title">${isArabic ? "الحل النهائي" : "Final Resolution"}</div><div class="detail-item" style="margin-bottom: 16px;"><div class="value" style="font-size: 14px; font-weight: 400;">${escapeHtml(task.finalResolution ? localized(task.finalResolution, language) : "-")}</div></div>` : ""}

          <div class="section-title">${isArabic ? "جدول المهام الفرعية" : "Sub-Tasks Table"}</div>
          <table>
            <thead>
              <tr>
                <th style="width: 50px;">#</th>
                <th>${isArabic ? "المهمة الفرعية" : "Sub-task"}</th>
                <th>${isArabic ? "الحالة" : "Status"}</th>
                <th>${isArabic ? "المسؤول" : "Assignee"}</th>
                <th>${isArabic ? "تاريخ الإنجاز" : "Completion Date"}</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>${escapeHtml(localized(task.title, language))}</td>
                <td><span class="badge" style="background:${getStatusColor(task.status)}">${escapeHtml(localized(statusLabels[task.status], language))}</span></td>
                <td>${escapeHtml(task.technicianName || task.assignee)}</td>
                <td>${escapeHtml(getDateInputValue(task.executionDate || task.dueDate))}</td>
              </tr>
            </tbody>
          </table>

          ${settings.showPrintFooter ? `
          <div class="footer">
            ${settings.footerLogo && settings.logoDataUrl ? `<img src="${settings.logoDataUrl}" style="height: 24px; margin-bottom: 4px;" /><br/>` : ""}
            <p style="font-weight: 700; color: ${titleColor};">${escapeHtml(localized(settings.footerText, language))}</p>
            <p>${isArabic ? "تم إنشاء هذا المستند بواسطة نظام المهام اليومية الذكية لتقنية المعلومات" : "Generated by Smart IT Daily Tasks System"}</p>
            <p>${escapeHtml(dateStr)} ${escapeHtml(timeStr)} | ${isArabic ? "صفحة" : "Page"} 1</p>
          </div>` : ""}
        </div>
        <script>
          window.addEventListener("load", () => { window.focus(); window.print(); });
        </script>
      </body>
    </html>`);
  printWindow.document.close();
}

function App() {
  return (
    <HashRouter>
      <PlatformShell />
    </HashRouter>
  );
}

function PlatformShell() {
  // ─── Settings ───
  const [settings, setSettingsState] = useState<AppSettings>(defaultSettings);
  const [smartToast, setSmartToast] = useState<string | null>(null);
  const language = settings.language;
  const ar = language === "ar";
  const showToast = (msg: string) => setSmartToast(msg);

  // ─── Supabase = PRIMARY data source (NO localStorage) ───
  const [tasks, setTasks] = useState<Task[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [deviceTypes, setDeviceTypes] = useState<DeviceType[]>([]);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [notifications] = useState<NotificationItem[]>([]);
  const [reports] = useState<ReportItem[]>([]);
  const [messages] = useState<MessageItem[]>([]);
  const [meetings] = useState<MeetingTool[]>([]);
  const [yearArchives, setYearArchives] = useState<YearArchive[]>([]);
  const [dataLoaded, setDataLoaded] = useState(false);
  const [sysHealth, setSysHealth] = useState<SystemHealth>(getSystemHealth());
  const [showAbout, setShowAbout] = useState(false);
  void dataLoaded;

  // Configure Google Sheets as BACKUP
  useEffect(() => {
    configureGoogleSheets(settings.googleAppsScriptUrl || "", settings.googleSheetId || "", settings.googleSheetsEnabled);
  }, [settings.googleAppsScriptUrl, settings.googleSheetId, settings.googleSheetsEnabled]);

  const setSettings = (updater: any) => {
    const raw = typeof updater === 'function' ? updater(settings) : updater;
    const next = { ...defaultSettings, ...raw };
    setSettingsState(next);
    supabaseService.saveSettings(next).catch((e: any) => showToast("❌ " + (e?.message || "Settings save failed")));
  };

  // ─── Load ALL data from Supabase on startup ───
  useEffect(() => {
    (async () => {
      try {
        const [t, s, d, dt, tm, n] = await Promise.all([
          supabaseService.getTasks().catch(() => []),
          supabaseService.getServices().catch(() => []),
          supabaseService.getDepartments().catch(() => []),
          supabaseService.getDeviceTypes().catch(() => []),
          supabaseService.getTeam().catch(() => []),
          supabaseService.getNotes().catch(() => []),
        ]);
        if ((t as any[]).length) setTasks(t as Task[]);
        if ((s as any[]).length) setServices(s as Service[]);
        if ((d as any[]).length) setDepartments(d as Department[]);
        if ((dt as any[]).length) setDeviceTypes(dt as DeviceType[]);
        if ((tm as any[]).length) setTeamMembers(tm as TeamMember[]);
        if ((n as any[]).length) setNotes(n as Note[]);
        const st = await supabaseService.getSettings().catch(() => null);
        if (st) setSettingsState({ ...defaultSettings, ...st });
        setDataLoaded(true);
      } catch { setDataLoaded(true); }
    })();
  }, []);

  // (old localStorage block removed — Supabase is primary)

  // ─── Supabase Realtime ───
  useEffect(() => {
    const upsertIn = <T extends { id: string }>(setter: React.Dispatch<React.SetStateAction<T[]>>, ev: string, rec: T) => {
      if (ev === "DELETE") setter((p) => p.filter((r) => r.id !== rec.id));
      else setter((p) => { const ex = p.find((r) => r.id === rec.id); return ex ? p.map((r) => r.id === rec.id ? { ...r, ...rec } : r) : [rec, ...p]; });
    };
    const unsubscribe = subscribeToRealtime((table, event, record) => {
      if (!record) return;
      if (table === "tasks") upsertIn(setTasks, event, record as Task);
      else if (table === "departments") upsertIn(setDepartments, event, record as Department);
      else if (table === "services") upsertIn(setServices, event, record as Service);
      else if (table === "device_types") upsertIn(setDeviceTypes, event, record as DeviceType);
      else if (table === "team_members") upsertIn(setTeamMembers, event, record as TeamMember);
      else if (table === "notes") upsertIn(setNotes, event, record as Note);
      setSysHealth(getSystemHealth());
    });
    return unsubscribe;
  }, []);

  // ─── Periodic Health Check ───
  useEffect(() => {
    const timer = setInterval(() => setSysHealth(getSystemHealth()), 15000);
    return () => clearInterval(timer);
  }, []);

  // ─── Auto-save drafts ───
  void saveDraft; void loadDraft; void clearDraft;
  void lockRecord; void unlockRecord; void getRecordLock;
  void trackVersion; void logAudit;

  // ─── Supabase-first persistOp ───
  const persistOp = async (table: string, op: string, data: any, optimistic: () => void, msg: string) => {
    // Step 1: Try Supabase FIRST — do NOT show success until DB confirms
    console.log(`[persistOp] ${op} ${table}`, JSON.stringify(data).slice(0, 200));
    try {
      let result: any = null;
      if (table === "tasks") {
        if (op === "create") result = await supabaseService.createTask(data);
        else if (op === "update") result = await supabaseService.updateTask(data.id, data);
        else if (op === "delete") { await supabaseService.deleteTask(data); result = "deleted"; }
      } else if (table === "departments") {
        if (op === "upsert") result = await supabaseService.upsertDepartment(data);
        else if (op === "delete") { await supabaseService.deleteDepartment(data); result = "deleted"; }
      } else if (table === "services") {
        if (op === "upsert") result = await supabaseService.upsertService(data);
        else if (op === "delete") { await supabaseService.deleteService(data); result = "deleted"; }
      } else if (table === "device_types") {
        if (op === "upsert") result = await supabaseService.upsertDeviceType(data);
        else if (op === "delete") { await supabaseService.deleteDeviceType(data); result = "deleted"; }
      } else if (table === "team_members") {
        if (op === "upsert") result = await supabaseService.upsertTeamMember(data);
        else if (op === "delete") { await supabaseService.deleteTeamMember(data); result = "deleted"; }
      } else if (table === "notes") {
        if (op === "upsert") result = await supabaseService.upsertNote(data);
        else if (op === "delete") { await supabaseService.deleteNote(data); result = "deleted"; }
      }
      console.log(`[persistOp] ✅ Supabase ${op} ${table} success:`, result);
      
      // Step 2: Only update UI AFTER Supabase confirms
      optimistic();
      showToast(msg);
      markSyncComplete();
      setSysHealth(getSystemHealth());
    } catch (e: any) {
      const errorMsg = e?.message || e?.code || JSON.stringify(e) || "Unknown error";
      console.error(`[persistOp] ❌ Supabase ${op} ${table} FAILED:`, errorMsg, e);
      showToast("❌ " + (ar ? "فشل الحفظ في Supabase: " : "Supabase save failed: ") + errorMsg);
      // Do NOT call optimistic() — the data was NOT saved
    }
    logAudit({ action: op, target: table, target_id: data?.id || data, details: `${op} ${table}`, user: "Admin" });
  };

  // (removed old retry block — not needed without localStorage)
  void 0; // placeholder
  // ─── CRUD Mutations (Supabase-first) ───
  const taskMutation = {
    mutate: ({ action, task }: { action: "create" | "update" | "delete"; task: any }) => {
      if (action === "create") persistOp("tasks", "create", task, () => setTasks((p: Task[]) => [task, ...p]), ar ? "✅ تم حفظ البيانات بنجاح" : "✅ Data saved successfully");
      else if (action === "update") persistOp("tasks", "update", task, () => setTasks((p: Task[]) => p.map((t: Task) => t.id === task.id ? { ...t, ...task } : t)), ar ? "✅ تم تحديث البيانات بنجاح" : "✅ Data updated successfully");
      else if (action === "delete") persistOp("tasks", "delete", task.id, () => setTasks((p: Task[]) => p.filter((t: Task) => t.id !== task.id)), ar ? "✅ تم حذف المهمة بنجاح" : "✅ Task deleted successfully");
    },
  };
  const depMutation = {
    mutate: ({ action, dep }: { action: "upsert" | "delete"; dep: any }) => {
      if (action === "upsert") persistOp("departments", "upsert", dep, () => setDepartments((p: Department[]) => { const ex = p.find((d: Department) => d.id === dep.id); return ex ? p.map((d: Department) => d.id === dep.id ? dep : d) : [...p, dep]; }), ar ? "✅ تم حفظ البيانات بنجاح" : "✅ Data saved successfully");
      else if (action === "delete") persistOp("departments", "delete", dep.id, () => setDepartments((p: Department[]) => p.filter((d: Department) => d.id !== dep.id)), ar ? "✅ تم حذف الجهة" : "✅ Department deleted");
    },
  };
  const serviceMutation = {
    mutate: ({ action, service }: { action: "upsert" | "delete"; service: any }) => {
      if (action === "upsert") persistOp("services", "upsert", service, () => setServices((p: Service[]) => { const ex = p.find((s: Service) => s.id === service.id); return ex ? p.map((s: Service) => s.id === service.id ? service : s) : [...p, service]; }), ar ? "✅ تم حفظ البيانات بنجاح" : "✅ Data saved successfully");
      else if (action === "delete") persistOp("services", "delete", service.id, () => setServices((p: Service[]) => p.filter((s: Service) => s.id !== service.id)), ar ? "✅ تم حذف الخدمة" : "✅ Service deleted");
    },
  };
  const dtMutation = {
    mutate: ({ action, dt }: { action: "upsert" | "delete"; dt: any }) => {
      if (action === "upsert") persistOp("device_types", "upsert", dt, () => setDeviceTypes((p: DeviceType[]) => { const ex = p.find((d: DeviceType) => d.id === dt.id); return ex ? p.map((d: DeviceType) => d.id === dt.id ? dt : d) : [...p, dt]; }), ar ? "✅ تم حفظ البيانات بنجاح" : "✅ Data saved successfully");
      else if (action === "delete") persistOp("device_types", "delete", dt.id, () => setDeviceTypes((p: DeviceType[]) => p.filter((d: DeviceType) => d.id !== dt.id)), ar ? "✅ تم حذف نوع الجهاز" : "✅ Device type deleted");
    },
  };
  const teamMutation = {
    mutate: ({ action, member }: { action: "upsert" | "delete"; member: any }) => {
      if (action === "upsert") persistOp("team_members", "upsert", member, () => setTeamMembers((p: TeamMember[]) => { const ex = p.find((m: TeamMember) => m.id === member.id); return ex ? p.map((m: TeamMember) => m.id === member.id ? member : m) : [...p, member]; }), ar ? "✅ تم حفظ البيانات بنجاح" : "✅ Data saved successfully");
      else if (action === "delete") persistOp("team_members", "delete", member.id, () => setTeamMembers((p: TeamMember[]) => p.filter((m: TeamMember) => m.id !== member.id)), ar ? "✅ تم حذف عضو الفريق" : "✅ Team member deleted");
    },
  };
  const noteMutation = {
    mutate: ({ action, note }: { action: "upsert" | "delete"; note: any }) => {
      if (action === "upsert") persistOp("notes", "upsert", note, () => setNotes((p: Note[]) => { const ex = p.find((n: Note) => n.id === note.id); return ex ? p.map((n: Note) => n.id === note.id ? note : n) : [note, ...p]; }), ar ? "✅ تم حفظ البيانات بنجاح" : "✅ Data saved successfully");
      else if (action === "delete") persistOp("notes", "delete", note.id, () => setNotes((p: Note[]) => p.filter((n: Note) => n.id !== note.id)), ar ? "✅ تم حذف الملاحظة" : "✅ Note deleted");
    },
  };

  // (removed old localStorage-based blocks)

  const [taskDrawerOpen, setTaskDrawerOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [analyzedTask, setAnalyzedTask] = useState<Task | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [messagesOpen, setMessagesOpen] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [calendarView, setCalendarView] = useState<"day" | "week" | "month" | "year">("week");
  const [smartQueueIds, setSmartQueueIds] = useState<string[]>([]);
  const [dragTaskId, setDragTaskId] = useState<string | null>(null);
  const [selectedNoteId, setSelectedNoteId] = useState<string>(notes[0]?.id ?? "");
  const [serviceForm, setServiceForm] = useState<{
    id?: string;
    nameAr: string;
    nameEn: string;
    descriptionAr: string;
    descriptionEn: string;
    emoji: string;
    iconName: string;
    color: string;
  }>({
    nameAr: "",
    nameEn: "",
    descriptionAr: "",
    descriptionEn: "",
    emoji: "🧩",
    iconName: "Settings",
    color: "#2563EB",
  });

  const isArabic = language === "ar";
  const text = uiText[language];
  const location = useLocation();
  const navigate = useNavigate();

  const [systemDark, setSystemDark] = useState(() =>
    typeof window !== "undefined" ? window.matchMedia("(prefers-color-scheme: dark)").matches : false,
  );

  useEffect(() => {
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const updateTheme = (event: MediaQueryListEvent) => setSystemDark(event.matches);
    setSystemDark(media.matches);
    media.addEventListener("change", updateTheme);
    return () => media.removeEventListener("change", updateTheme);
  }, []);

  const resolvedTheme = settings.themeMode === "system" ? (systemDark ? "dark" : "light") : settings.themeMode;

  useEffect(() => {
    document.documentElement.lang = isArabic ? "ar" : "en";
    document.documentElement.dir = isArabic ? "rtl" : "ltr";
    document.documentElement.classList.toggle("dark", resolvedTheme === "dark");
    document.documentElement.style.setProperty("--primary-color-1", settings.primaryColor1 || "#0F8A5F");
    document.documentElement.style.setProperty("--primary-color-2", settings.primaryColor2 || "#2563EB");
    document.documentElement.style.setProperty("--primary-green", settings.primaryGreen);
    document.documentElement.style.setProperty("--primary-blue", settings.primaryBlue);
    document.documentElement.style.setProperty("--accent-success", settings.successColor || settings.accentSuccess);
    document.documentElement.style.setProperty("--accent-warning", settings.warningColor || settings.accentWarning);
    document.documentElement.style.setProperty("--accent-danger", settings.dangerColor || settings.accentDanger);
    document.documentElement.style.setProperty("--bg-color", settings.bgColor || "#F8FAFC");
    document.documentElement.style.setProperty("--card-color", settings.cardColor || "#FFFFFF");
    document.documentElement.style.setProperty("--header-color", settings.headerColor || "#FFFFFF");
    document.documentElement.style.setProperty("--sidebar-color", settings.sidebarColor || "#FFFFFF");
    document.documentElement.style.setProperty("--table-color", settings.tableColor || "#FFFFFF");
    document.documentElement.style.setProperty("--font-arabic", settings.fontArabic || "system-ui");
    document.documentElement.style.setProperty("--font-english", settings.fontEnglish || "Inter, system-ui, sans-serif");
    document.documentElement.style.setProperty("--font-size-system", `${settings.fontSizeSystem || 24}px`);
    document.documentElement.style.setProperty("--font-size-page", `${settings.fontSizePage || 20}px`);
    document.documentElement.style.setProperty("--font-size-card", `${settings.fontSizeCard || 18}px`);
    document.documentElement.style.setProperty("--font-size-table", `${settings.fontSizeTable || 14}px`);
    document.documentElement.style.setProperty("--font-size-menu", `${settings.fontSizeMenu || 14}px`);
    document.documentElement.style.setProperty("--font-size-button", `${settings.fontSizeButton || 14}px`);
    document.documentElement.style.setProperty("--font-size-modal", `${settings.fontSizeModal || 18}px`);
    document.documentElement.style.setProperty("--font-size-report", `${settings.fontSizeReport || 16}px`);
    document.documentElement.style.setProperty("--font-size-print", `${settings.fontSizePrint || 14}px`);
    const baseSize = settings.fontSize === "custom" ? settings.fontSizeCustom : settings.fontSize === "small" ? 14 : settings.fontSize === "large" ? 18 : settings.fontSize === "xlarge" ? 20 : 16;
    document.documentElement.style.fontSize = `${baseSize}px`;
    document.documentElement.style.fontFamily = isArabic ? settings.fontArabic : settings.fontEnglish;
    document.title = `${localized(settings.systemName, language)} | ${localized(settings.universityName, language)}`;
    const themeMeta = document.querySelector('meta[name="theme-color"]');
    if (themeMeta) {
      themeMeta.setAttribute("content", resolvedTheme === "dark" ? "#0F172A" : settings.primaryColor1 || settings.primaryGreen);
    }
    if (settings.gradientEnabled) {
      const angle = settings.gradientType === "angle" ? `${settings.gradientAngle}deg` : "135deg";
      if (settings.gradientType === "radial") {
        document.documentElement.style.setProperty("--gradient", `radial-gradient(circle, ${settings.primaryColor1}, ${settings.primaryColor2})`);
      } else {
        document.documentElement.style.setProperty("--gradient", `linear-gradient(${angle}, ${settings.primaryColor1}, ${settings.primaryColor2})`);
      }
    } else {
      document.documentElement.style.setProperty("--gradient", settings.primaryColor1 || settings.primaryGreen);
    }
  }, [isArabic, language, resolvedTheme, settings]);

  useEffect(() => {
    if (!smartToast) return undefined;
    const timer = window.setTimeout(() => setSmartToast(null), 2600);
    return () => window.clearTimeout(timer);
  }, [smartToast]);

  useEffect(() => {
    if (!selectedNoteId && notes[0]) {
      setSelectedNoteId(notes[0].id);
    }
  }, [notes, selectedNoteId]);

  const analyticsQuery = useQuery({
    queryKey: [
      "analytics",
      tasks.map((task) => `${task.id}-${task.status}-${task.priority}-${task.dueDate}`).join("|"),
    ],
    queryFn: async () => buildAnalytics(tasks),
    staleTime: 30_000,
  });

  const aiQuery = useQuery({
    queryKey: [
      "ai-insights",
      tasks.map((task) => `${task.id}-${task.status}-${task.priority}`).join("|"),
    ],
    queryFn: async () => buildAiInsights(tasks),
    staleTime: 15_000,
  });

  const analytics = analyticsQuery.data ?? buildAnalytics(tasks);
  const aiInsights = aiQuery.data ?? buildAiInsights(tasks);

  const unreadNotifications = notifications.filter((item) => !item.read).length;
  const unreadMessages = messages.filter((item) => item.unread).length;
  const selectedNote = notes.find((note) => note.id === selectedNoteId) ?? notes[0];

  const statsCards: {
    label: string;
    value: string | number;
    delta: string;
    icon: LucideIcon;
    accent: string;
    dataKey: "completed" | "created" | "productivity";
  }[] = [
    {
      label: text.totalTasks,
      value: analytics.totalTasks,
      delta: isArabic ? "+11 من الأسبوع الماضي" : "+11 from last week",
      icon: ClipboardList,
      accent: "from-blue-500/15 to-blue-500/5 text-blue-600 dark:text-blue-300",
      dataKey: "created",
    },
    {
      label: text.completedTasks,
      value: analytics.completedTasks,
      delta: isArabic ? "+8 من الأسبوع الماضي" : "+8 from last week",
      icon: CheckCircle2,
      accent: "from-emerald-500/15 to-emerald-500/5 text-emerald-600 dark:text-emerald-300",
      dataKey: "completed",
    },
    {
      label: text.inProgressTasks,
      value: analytics.inProgressTasks,
      delta: isArabic ? "+5 مهام جارية" : "+5 active tasks",
      icon: LoaderCircle,
      accent: "from-sky-500/15 to-sky-500/5 text-sky-600 dark:text-sky-300",
      dataKey: "created",
    },
    {
      label: text.delayedTasks,
      value: analytics.delayedTasks,
      delta: isArabic ? `-${analytics.delayedTasks} عن أمس` : `-${analytics.delayedTasks} vs yesterday`,
      icon: TimerReset,
      accent: "from-rose-500/15 to-rose-500/5 text-rose-600 dark:text-rose-300",
      dataKey: "created",
    },
    {
      label: text.todayTasks,
      value: analytics.todayTasks,
      delta: isArabic ? "+3 عن أمس" : "+3 vs yesterday",
      icon: CalendarCheck2,
      accent: "from-cyan-500/15 to-cyan-500/5 text-cyan-600 dark:text-cyan-300",
      dataKey: "productivity",
    },
    {
      label: text.weeklyTasks,
      value: analytics.weeklyTasks,
      delta: isArabic ? "+14 هذا الأسبوع" : "+14 this week",
      icon: Activity,
      accent: "from-violet-500/15 to-violet-500/5 text-violet-600 dark:text-violet-300",
      dataKey: "completed",
    },
    {
      label: text.completionRate,
      value: `${analytics.completionRate}%`,
      delta: isArabic ? "اتجاه صاعد" : "Trending up",
      icon: ShieldCheck,
      accent: "from-emerald-500/15 to-lime-500/5 text-emerald-600 dark:text-emerald-300",
      dataKey: "productivity",
    },
    {
      label: text.productivityRate,
      value: `${analytics.productivityRate}%`,
      delta: isArabic ? "متوسط الفرق" : "Team average",
      icon: Sparkles,
      accent: "from-fuchsia-500/15 to-indigo-500/5 text-fuchsia-600 dark:text-fuchsia-300",
      dataKey: "productivity",
    },
  ];

  const globalSearchResults = useMemo<SearchResult[]>(() => {
    const term = searchTerm.trim().toLowerCase();
    if (!term) return [];

    const taskResults = tasks.flatMap((task) => {
      const title = localized(task.title, language);
      const description = localized(task.description, language);
      const matchesTask = `${title} ${description} ${task.assignee}`.toLowerCase().includes(term);
      const attachmentHits = task.attachments
        .filter((attachment) => attachment.toLowerCase().includes(term))
        .map<SearchResult>((attachment) => ({
          id: `${task.id}-${attachment}`,
          type: "attachment",
          title: attachment,
          subtitle: title,
          route: "/tasks",
        }));

      return [
        ...(matchesTask
          ? [
              {
                id: task.id,
                type: "task" as const,
                title,
                subtitle: localized(task.service, language),
                route: "/tasks",
              },
            ]
          : []),
        ...attachmentHits,
      ];
    });

    const serviceResults = services
      .filter((service) => {
        const haystack = `${localized(service.name, language)} ${localized(service.description, language)}`.toLowerCase();
        return haystack.includes(term);
      })
      .map<SearchResult>((service) => ({
        id: service.id,
        type: "service",
        title: localized(service.name, language),
        subtitle: localized(service.category, language),
        route: "/services",
      }));

    const noteResults = notes
      .filter((note) => `${localized(note.title, language)} ${localized(note.summary, language)}`.toLowerCase().includes(term))
      .map<SearchResult>((note) => ({
        id: note.id,
        type: "note",
        title: localized(note.title, language),
        subtitle: localized(note.summary, language),
        route: "/notes",
      }));

    const reportResults = reports
      .filter((report) => `${localized(report.title, language)} ${localized(report.subtitle, language)}`.toLowerCase().includes(term))
      .map<SearchResult>((report) => ({
        id: report.id,
        type: "report",
        title: localized(report.title, language),
        subtitle: localized(report.subtitle, language),
        route: "/reports",
      }));

    return [...taskResults, ...serviceResults, ...noteResults, ...reportResults].slice(0, 12);
  }, [language, notes, reports, searchTerm, services, tasks]);

  const queueTasks = smartQueueIds.length
    ? smartQueueIds.map((id) => tasks.find((task) => task.id === id)).filter(Boolean) as Task[]
    : aiInsights.smartPlan.slice(0, 6);

  const handleStartMyDay = () => {
    const organized = aiInsights.smartPlan.slice(0, 8).map((task) => task.id);
    setSmartQueueIds(organized);
    setSmartToast(text.queueOrganized);
    navigate("/smart-day");
  };

  const handleTaskSubmit = (values: TaskFormValues) => {
    const linkedService = services.find((service) => service.id === values.serviceId);
    if (!linkedService) return;

    const taskId = values.id || `TASK-${new Date().getFullYear()}-${Math.floor(Math.random() * 9000 + 1000)}`;
    const notesText = values.notes || "";
    const actionsText = values.actionsTaken || "";
    const finalText = values.finalResolution || "";

    const nextTask: Task = {
      id: taskId,
      title: {
        ar: `تذكرة دعم فني - ${linkedService.name.ar} - ${values.employeeName}`,
        en: `IT Support Ticket - ${linkedService.name.en} - ${values.employeeName}`,
      },
      description: {
        ar: notesText || `طلب دعم فني لخدمة ${linkedService.name.ar}`,
        en: notesText || `IT support request for ${linkedService.name.en}`,
      },
      serviceId: values.serviceId,
      service: linkedService.name,
      priority: values.priority,
      status: values.status,
      startDate: new Date(`${values.createdDate}T08:00:00`).toISOString(),
      dueDate: new Date(`${values.executionDate}T08:00:00`).toISOString(),
      timeLabel: new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
      attachments: values.attachments
        ? values.attachments
            .split(",")
            .map((item) => item.trim())
            .filter(Boolean)
        : [],
      notes: { ar: notesText, en: notesText },
      comments: editingTask?.comments || [],
      productivityScore: editingTask?.productivityScore || 72,
      assignee: values.technicianName,
      location: { ar: values.department, en: values.department },
      department: values.department,
      employeeName: values.employeeName,
      deviceType: values.deviceType,
      technicianName: values.technicianName,
      createdDate: new Date(`${values.createdDate}T08:00:00`).toISOString(),
      executionDate: new Date(`${values.executionDate}T08:00:00`).toISOString(),
      actionsTaken: { ar: actionsText, en: actionsText },
      finalResolution: { ar: finalText, en: finalText },
      changeLog: [
        ...(editingTask?.changeLog || []),
        `${new Date().toISOString()} - ${editingTask ? "Updated" : "Created"} by ${values.technicianName}`,
      ],
    };

    if (editingTask) {
      taskMutation.mutate({ action: "update", task: nextTask });
    } else {
      taskMutation.mutate({ action: "create", task: nextTask });
    }

    setEditingTask(null);
    setTaskDrawerOpen(false);
  };

  const updateTask = (taskId: string, updater: (task: Task) => Task) => {
    const task = tasks.find(t => t.id === taskId);
    if (task) {
      const updated = updater(task);
      taskMutation.mutate({ action: "update", task: updated });
    }
  };

  const duplicateTask = (task: Task) => {
    const newTask = {
      ...task,
      id: `TASK-${new Date().getFullYear()}-${Math.floor(Math.random() * 9000 + 1000)}`,
      title: {
        ar: `${task.title.ar} - نسخة`,
        en: `${task.title.en} - Copy`,
      },
      created_at: new Date().toISOString()
    };
    taskMutation.mutate({ action: "create", task: newTask });
  };

  const rescheduleTask = (task: Task) => {
    const nextDate = new Date(task.dueDate);
    nextDate.setDate(nextDate.getDate() + 1);
    updateTask(task.id, (current) => ({ ...current, dueDate: nextDate.toISOString(), status: "Postponed" }));
  };

  const reorderService = (serviceId: string, direction: "up" | "down") => {
    const index = services.findIndex((s) => s.id === serviceId);
    if (index < 0) return;
    const nextIndex = direction === "up" ? index - 1 : index + 1;
    if (nextIndex < 0 || nextIndex >= services.length) return;
    const updated = [...services];
    [updated[index], updated[nextIndex]] = [updated[nextIndex], updated[index]];
    updated.forEach(s => serviceMutation.mutate({ action: "upsert", service: s }));
  };

  const [serviceFormIcon, setServiceFormIcon] = useState<IconData>({ type: "emoji", value: "🧩" });
  const saveService = () => {
    if (!serviceForm.nameAr.trim() || !serviceForm.nameEn.trim()) {
      return;
    }

    const payload: Service = {
      id:
        serviceForm.id ||
        serviceForm.nameEn
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/^-|-$/g, ""),
      name: { ar: serviceForm.nameAr, en: serviceForm.nameEn },
      category: { ar: "خدمة مخصصة", en: "Custom Service" },
      description: { ar: serviceForm.descriptionAr, en: serviceForm.descriptionEn },
      iconData: serviceFormIcon,
      enabled: true,
      tickets: 0,
      color: serviceForm.color,
      subServices: [],
    };

    serviceMutation.mutate({ action: "upsert", service: payload });

    setServiceForm({
      nameAr: "",
      nameEn: "",
      descriptionAr: "",
      descriptionEn: "",
      emoji: "",
      iconName: "",
      color: "#2563EB",
    });
    setServiceFormIcon({ type: "emoji", value: "🧩" });
  };

  const markNotificationRead = (notificationId: string) => {
    // In prod, call notificationMutation
  };

  const handleDropTaskDate = (taskId: string, date: Date) => {
    updateTask(taskId, (current) => ({ ...current, dueDate: date.toISOString(), status: "In Progress" }));
    setDragTaskId(null);
  };

  const currentNavLabel =
    navItems.find((item) => (item.route === "/" ? location.pathname === "/" : location.pathname.startsWith(item.route)))?.label ||
    navItems[0].label;

  const sharedPageProps = {
    tasks,
    services,
    notes,
    reports,
    meetings,
    analytics,
    aiInsights,
    language,
    isArabic,
    text,
    settings,
    departments,
    deviceTypes,
    teamMembers,
    onOpenTaskForm: () => {
      setEditingTask(null);
      setTaskDrawerOpen(true);
    },
    onEditTask: (task: Task) => {
      setEditingTask(task);
      setTaskDrawerOpen(true);
    },
    onViewTask: setSelectedTask,
    onAnalyzeTask: setAnalyzedTask,
    onStartMyDay: handleStartMyDay,
    updateTask,
    duplicateTask,
    rescheduleTask,
    deleteTask: (id: string) => taskMutation.mutate({ action: "delete", task: { id } }),
    upsertDepartment: (dep: Department) => depMutation.mutate({ action: "upsert", dep }),
    deleteDepartment: (id: string) => depMutation.mutate({ action: "delete", dep: { id } }),
    upsertDeviceType: (dt: DeviceType) => dtMutation.mutate({ action: "upsert", dt }),
    upsertTeamMember: (member: TeamMember) => teamMutation.mutate({ action: "upsert", member }),
    upsertService: (service: Service) => serviceMutation.mutate({ action: "upsert", service }),
    deleteService: (id: string) => serviceMutation.mutate({ action: "delete", service: { id } }),
    upsertNote: (note: Note) => noteMutation.mutate({ action: "upsert", note }),
    deleteNote: (id: string) => noteMutation.mutate({ action: "delete", note: { id } }),
    deleteDeviceType: (id: string) => dtMutation.mutate({ action: "delete", dt: { id } }),
    deleteTeamMember: (id: string) => teamMutation.mutate({ action: "delete", member: { id } }),
    setDepartments,
    setDeviceTypes,
    setTeamMembers,
    setTasks: (t: any) => {}, 
    setNotes: (n: any) => {}, 
    setSelectedNoteId,
    selectedNoteId,
    selectedNote,
    calendarView,
    setCalendarView,
    handleDropTaskDate,
    dragTaskId,
    setDragTaskId,
    serviceForm,
    setServiceForm,
    saveService,
    reorderService,
    setServices: (s: any) => {}, 
    serviceFormIcon,
    setServiceFormIcon,
    notifications,
    markNotificationRead,
    isLoading: false,
    yearArchives,
    setYearArchives,
    sysHealth,
  };

  const Logo = settings?.logoDataUrl ? (
    <img
      src={settings.logoDataUrl}
      alt={settings?.universityName ? localized(settings.universityName, language) : "Logo"}
      className="h-12 w-12 rounded-2xl border border-white/60 object-cover shadow-lg"
      onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
    />
  ) : (
    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-[var(--primary-green)] to-[var(--primary-blue)] text-white shadow-lg shadow-emerald-500/20">
      <ShieldCheck className="h-6 w-6" />
    </div>
  );

  return (
    <div className={cn("min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100", isArabic ? "font-[system-ui]" : "font-[Inter,system-ui,sans-serif]") }>
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-40 left-0 h-96 w-96 rounded-full bg-emerald-400/20 blur-3xl dark:bg-emerald-500/10" />
        <div className="absolute right-0 top-1/3 h-96 w-96 rounded-full bg-blue-400/15 blur-3xl dark:bg-blue-500/10" />
      </div>

      <div className="relative flex min-h-screen lg:flex-row">
        <AnimatePresence>
          {(mobileSidebarOpen || window.innerWidth >= 1024) && (
            <motion.aside
              initial={{ opacity: 0, x: isArabic ? 24 : -24 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: isArabic ? 24 : -24 }}
              className={cn(
                "fixed inset-y-0 z-40 w-[88vw] max-w-[300px] p-4 shadow-2xl backdrop-blur-2xl lg:sticky lg:top-0 lg:block lg:w-80 lg:max-w-none",
                isArabic ? "right-0 lg:right-auto" : "left-0 lg:left-auto",
                mobileSidebarOpen ? "block" : "hidden lg:block",
              )}
            >
              <div className="flex h-full flex-col gap-4 rounded-[2rem] border border-slate-200/70 bg-white/80 p-4 text-slate-900 shadow-[0_20px_70px_rgba(15,23,42,0.12)] backdrop-blur-2xl dark:border-white/10 dark:bg-[#111827] dark:text-white dark:shadow-[0_20px_70px_rgba(15,23,42,0.35)]">
                <div className="relative rounded-3xl border border-slate-200/70 bg-white/70 p-4 text-center dark:border-white/10 dark:bg-white/5">
                  <button
                    type="button"
                    onClick={() => setMobileSidebarOpen(false)}
                    className="absolute end-3 top-3 rounded-2xl border border-slate-200 p-2 text-slate-600 dark:border-white/10 dark:text-slate-200 lg:hidden"
                  >
                    <X className="h-5 w-5" />
                  </button>
                  <div className="flex justify-center">{Logo}</div>
                  <p className="mt-3 text-base font-bold leading-tight text-slate-900 dark:text-white">{localized(settings.universityName, language)}</p>
                  <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-300">{localized(settings.systemName, language)}</p>
                </div>

                <nav className="space-y-2">
                  {navItems.map((item) => {
                    const NavIcon = iconMap[item.icon] || LayoutDashboard;
                    return (
                      <NavLink
                        key={item.key}
                        to={item.route}
                        onClick={() => setMobileSidebarOpen(false)}
                        className={({ isActive }) =>
                          cn(
                            "group flex items-center justify-between rounded-3xl px-4 py-4 text-sm font-semibold transition-all",
                            isActive
                              ? "bg-gradient-to-r from-[var(--primary-green)] to-emerald-500 text-white shadow-lg shadow-emerald-500/30"
                              : "bg-slate-100/70 text-slate-700 hover:bg-slate-200/70 dark:bg-white/5 dark:text-slate-100 dark:hover:bg-white/10",
                          )
                        }
                      >
                        <div className="flex items-center gap-3">
                          <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-black/5 shadow-inner dark:bg-white/10">
                            <NavIcon className="h-6 w-6" />
                          </span>
                          <span>{localized(item.label, language)}</span>
                        </div>
                        <ArrowLeft className={cn("h-4 w-4 opacity-60", !isArabic && "rotate-180")} />
                      </NavLink>
                    );
                  })}
                </nav>

                <div className="mt-auto space-y-4">
                  <div className="rounded-3xl border border-slate-200/70 bg-slate-100/70 p-4 dark:border-white/10 dark:bg-white/5">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-semibold text-slate-900 dark:text-white">{text.aiAssistant}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-300">{localized(aiInsights.summary, language)}</p>
                      </div>
                      <Bot className="h-10 w-10 rounded-2xl bg-emerald-500/15 p-2 text-emerald-600 dark:bg-emerald-500/20 dark:text-emerald-300" />
                    </div>
                    <button
                      type="button"
                      onClick={handleStartMyDay}
                      className="mt-4 w-full rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-emerald-500 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-emerald-500/25 transition hover:scale-[1.01]"
                    >
                      {text.startMyDay}
                    </button>
                  </div>
                  <div className="rounded-3xl border border-slate-200/70 bg-slate-100/70 p-4 dark:border-white/10 dark:bg-white/5">
                    <div className="flex items-center gap-3">
                      <UserCircle2 className="h-11 w-11 rounded-2xl bg-black/5 p-2 text-slate-700 dark:bg-white/10 dark:text-white" />
                      <div>
                        <p className="text-sm font-semibold text-slate-900 dark:text-white">{localized(APP_INFO.developer, language)}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-300">{isArabic ? "مدير النظام" : "System Manager"}</p>
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowAbout(true)}
                    className="mt-3 w-full rounded-2xl border border-slate-200/70 bg-slate-100/50 px-4 py-2.5 text-xs font-bold text-slate-600 transition hover:bg-slate-200/70 dark:border-white/10 dark:bg-white/5 dark:text-slate-300 dark:hover:bg-white/10"
                  >
                    {isArabic ? "حول النظام" : "About System"} · v{APP_INFO.version}
                  </button>
                </div>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>

        {mobileSidebarOpen && (
          <button
            type="button"
            className="fixed inset-0 z-30 bg-slate-950/50 lg:hidden"
            onClick={() => setMobileSidebarOpen(false)}
          />
        )}

        <div className="relative z-10 flex-1 px-3 pb-6 pt-3 sm:px-4 lg:px-6">
          <header className="mb-4 rounded-[2rem] border border-white/70 bg-white/75 p-4 shadow-xl shadow-slate-200/60 backdrop-blur-xl dark:border-slate-800 dark:bg-[#0b1120] dark:shadow-black/20">
            <div dir="ltr" className="grid gap-4 xl:grid-cols-[1fr_auto_1fr] xl:items-center">
              <div className="flex flex-wrap items-center justify-center gap-2 xl:justify-start">
                <IconButton label={text.settings} onClick={() => navigate("/settings") }>
                  <Settings2 className="h-5 w-5" />
                </IconButton>
                <IconButton
                  label={text.theme}
                  onClick={() =>
                    setSettings((current) => ({
                      ...current,
                      themeMode:
                        current.themeMode === "light"
                          ? "dark"
                          : current.themeMode === "dark"
                            ? "system"
                            : "light",
                    }))
                  }
                >
                  {settings.themeMode === "system" ? (
                    <Monitor className="h-5 w-5" />
                  ) : resolvedTheme === "dark" ? (
                    <MoonStar className="h-5 w-5" />
                  ) : (
                    <Sun className="h-5 w-5" />
                  )}
                </IconButton>
                <button
                  type="button"
                  title={text.language}
                  onClick={() => setSettings((current) => ({ ...current, language: current.language === "ar" ? "en" : "ar" }))}
                  className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 shadow-sm transition hover:border-slate-300 hover:shadow-md dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
                >
                  <Languages className="h-5 w-5" />
                  <span>{isArabic ? "EN" : "ع"}</span>
                </button>
                <IconButton label={text.notificationsCenter} onClick={() => navigate("/notifications") } badge={unreadNotifications}>
                  <Bell className="h-5 w-5" />
                </IconButton>
                <IconButton label={text.messages} onClick={() => setMessagesOpen(true)} badge={unreadMessages}>
                  <MessageCircleMore className="h-5 w-5" />
                </IconButton>
                <IconButton label={text.overview} onClick={() => setSearchOpen(true)}>
                  <Search className="h-5 w-5" />
                </IconButton>
                <button
                  type="button"
                  onClick={() => setMobileSidebarOpen(true)}
                  className="inline-flex h-12 w-12 items-center justify-center rounded-2xl border border-slate-200 bg-white text-slate-700 shadow-sm transition hover:border-slate-300 hover:shadow-md dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800 lg:hidden"
                >
                  <Menu className="h-5 w-5" />
                </button>
              </div>

              <div dir={isArabic ? "rtl" : "ltr"} className="text-center">
                <h2 className="text-lg font-black leading-tight text-slate-900 dark:text-white sm:text-xl">
                  {localized(settings.systemName, language)}
                </h2>
                <div className="mt-2 inline-flex items-center justify-center gap-2 border-x border-emerald-500/30 px-8 text-sm font-bold text-emerald-600 dark:text-emerald-400">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                  <Sparkles className="h-4 w-4" />
                  <span>{localized(currentNavLabel, language)}</span>
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                </div>
              </div>

              <div className="hidden xl:block" />
            </div>
          </header>

          <AnimatePresence mode="wait">
            <motion.main
              key={location.pathname}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -18 }}
              transition={{ duration: 0.28, ease: "easeOut" }}
            >
              <Routes>
                <Route path="/" element={<DashboardPage {...sharedPageProps} statsCards={statsCards} />} />
                <Route path="/tasks" element={<TasksPage {...sharedPageProps} roundedActions={settings.roundedActions} />} />
                <Route path="/smart-day" element={<SmartDayPage {...sharedPageProps} queueTasks={queueTasks} />} />
                <Route path="/calendar" element={<CalendarPage {...sharedPageProps} />} />
                <Route path="/departments" element={<DepartmentsPage {...sharedPageProps} />} />
                <Route path="/device-types" element={<DeviceTypesPage {...sharedPageProps} />} />
                <Route path="/services" element={<ServicesPage {...sharedPageProps} />} />
                <Route path="/notes" element={<NotesPage {...sharedPageProps} />} />
                <Route path="/reports" element={<ReportsPage {...sharedPageProps} />} />
                <Route path="/notifications" element={<NotificationsPage {...sharedPageProps} />} />
                <Route path="/team" element={<TeamPage {...sharedPageProps} />} />
                <Route path="/ai-assistant" element={<AiAssistantPage {...sharedPageProps} />} />
                <Route
                  path="/settings"
                  element={
                    <SettingsPage
                      settings={settings}
                      setSettings={setSettings}
                      departments={departments}
                      setDepartments={setDepartments}
                      text={text}
                      isArabic={isArabic}
                    />
                  }
                />
              </Routes>
            </motion.main>
          </AnimatePresence>
        </div>
      </div>

      <TaskEditorModal
        open={taskDrawerOpen}
        onOpenChange={(open) => {
          setTaskDrawerOpen(open);
          if (!open) setEditingTask(null);
        }}
        onSubmit={handleTaskSubmit}
        services={services}
        departments={departments}
        deviceTypes={deviceTypes}
        teamMembers={teamMembers}
        language={language}
        settings={settings}
        editingTask={editingTask}
      />

      <SearchModal
        open={searchOpen}
        onClose={() => setSearchOpen(false)}
        results={globalSearchResults}
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        placeholder={text.searchPlaceholder}
        onSelect={(route) => {
          navigate(route);
          setSearchOpen(false);
        }}
      />

      <MessagesModal
        open={messagesOpen}
        onClose={() => setMessagesOpen(false)}
        messages={messages}
        language={language}
      />

      <TaskDetailModal task={selectedTask} onClose={() => setSelectedTask(null)} language={language} />
      <TaskAiModal task={analyzedTask} onClose={() => setAnalyzedTask(null)} language={language} />

      <AnimatePresence>
        {smartToast && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-5 left-1/2 z-50 -translate-x-1/2 rounded-2xl border border-emerald-500/20 bg-slate-950 px-5 py-3 text-sm font-semibold text-white shadow-2xl"
          >
            {smartToast}
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── Footer ─── */}
      <footer className="border-t border-slate-200/70 bg-white/80 px-6 py-4 text-center backdrop-blur-xl dark:border-slate-800 dark:bg-slate-950/80">
        <p className="text-sm font-bold text-slate-900 dark:text-white">{localized(APP_INFO.name, language)}</p>
        <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
          {isArabic ? "الإصدار" : "Version"}: {APP_INFO.version} · {localized(APP_INFO.developerLabel, language)}: {localized(APP_INFO.developer, language)}
        </p>
        <p className="mt-1 text-xs text-slate-400 dark:text-slate-500">{localized(APP_INFO.copyright, language)}</p>
      </footer>

      {/* ─── About Dialog ─── */}
      {showAbout && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm">
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-lg rounded-[2rem] border border-white/60 bg-white p-8 text-center shadow-2xl dark:border-slate-700 dark:bg-slate-900">
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-[var(--primary-green)] to-[var(--primary-blue)] text-white shadow-xl">
              <ShieldCheck className="h-10 w-10" />
            </div>
            <h2 className="mt-5 text-2xl font-black text-slate-900 dark:text-white">{localized(APP_INFO.name, language)}</h2>
            <p className="mt-2 text-sm font-semibold text-emerald-600 dark:text-emerald-400">{isArabic ? "الإصدار" : "Version"} {APP_INFO.version}</p>
            <div className="mt-4 rounded-2xl border border-slate-200/70 bg-slate-50/80 p-4 dark:border-slate-700 dark:bg-slate-800/60">
              <p className="text-xs font-bold text-slate-500 dark:text-slate-400">{localized(APP_INFO.developerLabel, language)}</p>
              <p className="mt-1 text-lg font-black text-slate-900 dark:text-white">{localized(APP_INFO.developer, language)}</p>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-slate-500 dark:text-slate-300">{localized(APP_INFO.description, language)}</p>
            <p className="mt-4 text-xs text-slate-400 dark:text-slate-500">{localized(APP_INFO.copyright, language)}</p>
            <button type="button" onClick={() => setShowAbout(false)} className="mt-6 rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-[var(--primary-blue)] px-8 py-3 text-sm font-bold text-white shadow-lg">
              {isArabic ? "إغلاق" : "Close"}
            </button>
          </motion.div>
        </div>
      )}
    </div>
  );
}

type SharedPageProps = {
  tasks: Task[];
  services: Service[];
  notes: Note[];
  reports: ReportItem[];
  meetings: MeetingTool[];
  analytics: AnalyticsSnapshot;
  aiInsights: AiInsightPack;
  language: Language;
  isArabic: boolean;
  text: (typeof uiText)[Language];
  settings: AppSettings;
  departments: Department[];
  deviceTypes: DeviceType[];
  teamMembers: TeamMember[];
  onOpenTaskForm: () => void;
  onEditTask: (task: Task) => void;
  onViewTask: (task: Task) => void;
  onAnalyzeTask: (task: Task) => void;
  onStartMyDay: () => void;
  updateTask: (taskId: string, updater: (task: Task) => Task) => void;
  duplicateTask: (task: Task) => void;
  rescheduleTask: (task: Task) => void;
  deleteTask: (id: string) => void;
  upsertDepartment: (dep: Department) => void;
  deleteDepartment: (id: string) => void;
  upsertDeviceType: (dt: DeviceType) => void;
  upsertTeamMember: (member: TeamMember) => void;
  upsertService: (service: Service) => void;
  deleteService: (id: string) => void;
  deleteDeviceType: (id: string) => void;
  deleteTeamMember: (id: string) => void;
  setDepartments: React.Dispatch<React.SetStateAction<Department[]>>;
  setDeviceTypes: React.Dispatch<React.SetStateAction<DeviceType[]>>;
  setTeamMembers: React.Dispatch<React.SetStateAction<TeamMember[]>>;
  setTasks: (t: any) => void;
  setNotes: (n: any) => void;
  setSelectedNoteId: React.Dispatch<React.SetStateAction<string>>;
  selectedNoteId: string;
  selectedNote?: Note;
  calendarView: "day" | "week" | "month" | "year";
  setCalendarView: React.Dispatch<React.SetStateAction<"day" | "week" | "month" | "year">>;
  handleDropTaskDate: (taskId: string, date: Date) => void;
  dragTaskId: string | null;
  setDragTaskId: React.Dispatch<React.SetStateAction<string | null>>;
  serviceForm: {
    id?: string;
    nameAr: string;
    nameEn: string;
    descriptionAr: string;
    descriptionEn: string;
    emoji: string;
    iconName: string;
    color: string;
  };
  setServiceForm: React.Dispatch<
    React.SetStateAction<{
      id?: string;
      nameAr: string;
      nameEn: string;
      descriptionAr: string;
      descriptionEn: string;
      emoji: string;
      iconName: string;
      color: string;
    }>
  >;
  saveService: () => void;
  reorderService: (serviceId: string, direction: "up" | "down") => void;
  setServices: (s: any) => void;
  serviceFormIcon: IconData;
  setServiceFormIcon: React.Dispatch<React.SetStateAction<IconData>>;
  notifications: NotificationItem[];
  markNotificationRead: (notificationId: string) => void;
  isLoading: boolean;
  yearArchives: YearArchive[];
  setYearArchives: React.Dispatch<React.SetStateAction<YearArchive[]>>;
  sysHealth: SystemHealth;
};

function DashboardPage(
  props: SharedPageProps & {
    statsCards: {
      label: string;
      value: string | number;
      delta: string;
      icon: LucideIcon;
      accent: string;
      dataKey: "completed" | "created" | "productivity";
    }[];
  },
) {
  const { language, isArabic, text, tasks, analytics, aiInsights, meetings, reports, services, onStartMyDay, statsCards } = props;
  const weekLabelKey = language === "ar" ? "dayAr" : "dayEn";
  const monthLabelKey = language === "ar" ? "labelAr" : "labelEn";

  return (
    <div className="space-y-4">
      <div className="grid gap-4 xl:grid-cols-[280px_minmax(0,1fr)]">
        <ShellCard className="p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-500 dark:text-slate-300">{text.smartDay}</p>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white">{text.productivityPulse}</h2>
            </div>
            <Brain className="h-11 w-11 rounded-2xl bg-emerald-500/10 p-2 text-emerald-600 dark:text-emerald-300" />
          </div>
          <div className="mt-5 flex items-center gap-4">
            <div className="relative flex h-28 w-28 items-center justify-center rounded-full bg-gradient-to-br from-emerald-50 to-white shadow-inner dark:from-emerald-500/10 dark:to-slate-900">
              <div className="absolute inset-2 rounded-full border-[10px] border-emerald-500/20" />
              <div className="text-center">
                <div className="text-3xl font-black text-slate-900 dark:text-white">{analytics.completionRate}%</div>
                <div className="text-xs text-slate-500 dark:text-slate-300">{text.completionRate}</div>
              </div>
            </div>
            <div className="flex-1 space-y-3">
              <QuickMetricRow label={text.completedTasks} value={analytics.completedTasks} accent="bg-emerald-500" />
              <QuickMetricRow label={text.inProgressTasks} value={analytics.inProgressTasks} accent="bg-blue-500" />
              <QuickMetricRow label={text.delayedTasks} value={analytics.delayedTasks} accent="bg-rose-500" />
            </div>
          </div>
          <button
            type="button"
            onClick={onStartMyDay}
            className="mt-6 w-full rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-emerald-500 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-emerald-500/25 transition hover:scale-[1.01]"
          >
            🚀 {text.startMyDay}
          </button>
        </ShellCard>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {statsCards.map((card) => {
            const CardIcon = card.icon;
            return (
              <ShellCard key={card.label} className="p-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-sm text-slate-500 dark:text-slate-300">{card.label}</p>
                    <h3 className="mt-2 text-4xl font-black text-slate-900 dark:text-white">{card.value}</h3>
                    <p className="mt-2 text-sm text-emerald-600 dark:text-emerald-300">{card.delta}</p>
                  </div>
                  <div className={cn("rounded-3xl bg-gradient-to-br p-3 shadow-lg", card.accent)}>
                    <CardIcon className="h-8 w-8" />
                  </div>
                </div>
                <div className="mt-4 h-16">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={weeklyPerformanceData}>
                      <Line
                        dataKey={card.dataKey}
                        type="monotone"
                        stroke={card.dataKey === "completed" ? "#22C55E" : card.dataKey === "created" ? "#2563EB" : "#A855F7"}
                        strokeWidth={3}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </ShellCard>
            );
          })}
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.1fr_1.1fr_0.8fr]">
        <ChartCard title={text.priorityDistribution} isEmpty={analytics.totalTasks === 0}>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie
                data={analytics.priorityDistribution.map((entry) => ({
                  ...entry,
                  label: localized(priorityLabels[entry.name as Priority], language),
                }))}
                dataKey="value"
                nameKey="label"
                innerRadius={62}
                outerRadius={98}
                paddingAngle={4}
              >
                {analytics.priorityDistribution.map((item) => (
                  <Cell key={item.name} fill={item.fill} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title={text.weeklyPerformance} isEmpty={weeklyPerformanceData.length === 0}>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={weeklyPerformanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#CBD5E1" opacity={0.35} />
              <XAxis dataKey={weekLabelKey} stroke="#64748B" />
              <YAxis stroke="#64748B" />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="completed" stroke="#22C55E" strokeWidth={3} />
              <Line type="monotone" dataKey="created" stroke="#2563EB" strokeWidth={3} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title={text.monthlyPerformance} isEmpty={monthlyPerformanceData.length === 0}>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={monthlyPerformanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#CBD5E1" opacity={0.35} />
              <XAxis dataKey={monthLabelKey} stroke="#64748B" />
              <YAxis stroke="#64748B" />
              <Tooltip />
              <Bar dataKey="value" fill="#0F8A5F" radius={[12, 12, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.15fr_0.85fr_1fr]">
        <ShellCard className="p-5">
          <SectionHeader title={text.latestTasks} actionLabel={text.viewAll} />
          <div className="mt-4 overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200/80 text-slate-500 dark:border-slate-700 dark:text-slate-300">
                  <th className="px-3 py-3 text-start">{isArabic ? "الأولوية" : "Priority"}</th>
                  <th className="px-3 py-3 text-start">{isArabic ? "المهمة" : "Task"}</th>
                  <th className="px-3 py-3 text-start">{isArabic ? "الحالة" : "Status"}</th>
                  <th className="px-3 py-3 text-start">{isArabic ? "الاستحقاق" : "Due"}</th>
                </tr>
              </thead>
              <tbody>
                {tasks.slice(0, 6).map((task) => (
                  <tr key={task.id} className="border-b border-slate-100 last:border-none dark:border-slate-800">
                    <td className="px-3 py-3">
                      <Badge className={getPriorityColor(task.priority)}>
                        {localized(priorityLabels[task.priority], language)}
                      </Badge>
                    </td>
                    <td className="px-3 py-3">
                      <div className="font-semibold text-slate-900 dark:text-white">{localized(task.title, language)}</div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">{localized(task.service, language)}</div>
                    </td>
                    <td className="px-3 py-3">
                      <Badge className={getTaskStatusColor(task.status)}>{localized(statusLabels[task.status], language)}</Badge>
                    </td>
                    <td className="px-3 py-3 text-slate-500 dark:text-slate-300">{formatShortDate(task.dueDate, language)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </ShellCard>

        <ShellCard className="p-5">
          <SectionHeader title={text.recentActivities} actionLabel={text.viewAll} />
          <div className="mt-4 space-y-4">
            {recentActivities.map((item, index) => (
              <div key={item.id} className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className="h-10 w-10 rounded-2xl bg-slate-100 p-2 text-slate-700 dark:bg-slate-800 dark:text-slate-200">
                    {index % 2 === 0 ? <Sparkles className="h-6 w-6" /> : <Activity className="h-6 w-6" />}
                  </div>
                  {index < recentActivities.length - 1 && <div className="mt-2 h-full w-px bg-slate-200 dark:bg-slate-700" />}
                </div>
                <div>
                  <div className="font-semibold text-slate-900 dark:text-white">{localized(item.title, language)}</div>
                  <div className="text-sm text-slate-500 dark:text-slate-300">{localized(item.detail, language)}</div>
                  <div className="mt-1 text-xs text-slate-400">{item.time}</div>
                </div>
              </div>
            ))}
          </div>
        </ShellCard>

        <ShellCard className="p-5">
          <SectionHeader title={text.smartSummary} actionLabel={text.aiAssistant} />
          <div className="mt-4 space-y-4">
            <QuickMetricRow label={text.todayTasks} value={aiInsights.today.length} accent="bg-blue-500" />
            <QuickMetricRow label={text.urgentTasks} value={aiInsights.urgent.length} accent="bg-fuchsia-500" />
            <QuickMetricRow label={text.delayedTasks} value={aiInsights.delayed.length} accent="bg-rose-500" />
            <div className="rounded-3xl border border-emerald-500/10 bg-emerald-500/5 p-4">
              <div className="mb-2 flex items-center gap-2 text-sm font-bold text-emerald-700 dark:text-emerald-300">
                <Bot className="h-5 w-5" /> {text.aiSuggestions}
              </div>
              <div className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
                {aiInsights.suggestions.map((suggestion) => (
                  <div key={suggestion.en} className="rounded-2xl bg-white/80 p-3 dark:bg-slate-800/80">
                    {localized(suggestion, language)}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </ShellCard>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1fr_1.1fr_0.9fr]">
        <ShellCard className="p-5">
          <SectionHeader title={text.smartServices} actionLabel={text.viewAll} />
          <div className="mt-4 grid grid-cols-2 gap-3">
            {services.slice(0, 8).map((service) => {
              return (
                <div key={service.id} className="rounded-3xl border border-slate-200/70 bg-white/80 p-4 text-center shadow-sm dark:border-slate-700 dark:bg-slate-800/80">
                  <div
                    className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl text-white shadow-lg"
                    style={{ background: `linear-gradient(135deg, ${service.color}, ${service.color}99)` }}
                  >
                    <DynamicIcon icon={service.iconData} className="text-white" size={32} />
                  </div>
                  <p className="mt-3 font-semibold text-slate-900 dark:text-white">{localized(service.name, language)}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{service.tickets} {isArabic ? "طلبات" : "tickets"}</p>
                </div>
              );
            })}
          </div>
        </ShellCard>

        <ShellCard className="p-5">
          <SectionHeader title={text.smartMeetings} actionLabel={text.viewAll} />
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {meetings.map((meeting) => (
              <div key={meeting.id} className="rounded-3xl border border-slate-200/70 bg-white/80 p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800/80">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-bold text-slate-900 dark:text-white">{meeting.name}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{meeting.room}</p>
                  </div>
                  <div className="rounded-2xl px-3 py-1 text-xs font-bold" style={{ backgroundColor: `${meeting.accent}15`, color: meeting.accent }}>
                    {meeting.nextMeeting}
                  </div>
                </div>
                <div className="mt-4 flex gap-2">
                  <a
                    href={meeting.link}
                    target="_blank"
                    rel="noreferrer"
                    className="flex-1 rounded-2xl bg-slate-900 px-3 py-2 text-center text-sm font-semibold text-white dark:bg-white dark:text-slate-900"
                  >
                    {isArabic ? "فتح الاجتماع" : "Open Meeting"}
                  </a>
                  <button
                    type="button"
                    onClick={() => navigator.clipboard.writeText(meeting.link)}
                    className="rounded-2xl border border-slate-200 px-3 py-2 text-sm font-semibold dark:border-slate-700"
                  >
                    {isArabic ? "حفظ الرابط" : "Save Link"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </ShellCard>

        <ShellCard className="p-5">
          <SectionHeader title={text.quickReports} actionLabel={text.export} />
          <div className="mt-4 space-y-3">
            {reports.map((report) => (
              <div key={report.id} className="flex items-center justify-between rounded-3xl border border-slate-200/70 bg-white/80 p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800/80">
                <div>
                  <div className="font-semibold text-slate-900 dark:text-white">{localized(report.title, language)}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">{localized(report.subtitle, language)}</div>
                </div>
                <button
                  type="button"
                  onClick={() => downloadAsJson(`${report.id}.json`, report)}
                  className="rounded-2xl bg-emerald-500/10 p-3 text-emerald-600 dark:text-emerald-300"
                >
                  <Download className="h-5 w-5" />
                </button>
              </div>
            ))}
          </div>
        </ShellCard>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <ChartCard title={text.statusDistribution} isEmpty={analytics.totalTasks === 0}>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie
                data={analytics.statusDistribution.map((entry) => ({
                  ...entry,
                  label: localized(statusLabels[entry.name as TaskStatus], language),
                }))}
                dataKey="value"
                nameKey="label"
                innerRadius={60}
                outerRadius={104}
                paddingAngle={4}
              >
                {analytics.statusDistribution.map((item) => (
                  <Cell key={item.name} fill={item.fill} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
        <ChartCard title={text.productivityAnalysis} isEmpty={productivityAnalysisData.length === 0}>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={productivityAnalysisData}>
              <defs>
                <linearGradient id="productivityArea" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2563EB" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#2563EB" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#CBD5E1" opacity={0.35} />
              <XAxis dataKey={language === "ar" ? "labelAr" : "labelEn"} stroke="#64748B" />
              <YAxis stroke="#64748B" />
              <Tooltip />
              <Area type="monotone" dataKey="value" stroke="#2563EB" fill="url(#productivityArea)" strokeWidth={3} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
}

function TasksPage(props: SharedPageProps & { roundedActions: boolean }) {
  const { tasks, services, language, isArabic, text, settings, onOpenTaskForm, onEditTask, onAnalyzeTask, updateTask, deleteTask, roundedActions } = props;
  const [statusFilter, setStatusFilter] = useState<TaskStatus | "all">("all");
  const [priorityFilter, setPriorityFilter] = useState<Priority | "all">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [exportOpen, setExportOpen] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [sortConfig, setSortSortConfig] = useState<{ key: keyof Task; direction: "asc" | "desc" } | null>(null);

  const filteredTasks = useMemo(() => {
    let result = tasks.filter((task) => {
      const matchesStatus = statusFilter === "all" || task.status === statusFilter;
      const matchesPriority = priorityFilter === "all" || task.priority === priorityFilter;
      const term = searchQuery.toLowerCase();
      const matchesSearch = 
        localized(task.title, language).toLowerCase().includes(term) ||
        localized(task.description, language).toLowerCase().includes(term) ||
        task.id.toLowerCase().includes(term) ||
        task.assignee.toLowerCase().includes(term);
      return matchesStatus && matchesPriority && matchesSearch;
    });

    if (sortConfig) {
      result = [...result].sort((a, b) => {
        const aVal = String(a[sortConfig.key]);
        const bVal = String(b[sortConfig.key]);
        return sortConfig.direction === "asc" ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      });
    }
    return result;
  }, [tasks, statusFilter, priorityFilter, searchQuery, sortConfig, language]);

  const toggleSelectAll = () => {
    if (selectedIds.length === filteredTasks.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredTasks.map(t => t.id));
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const handleBulkDelete = () => {
    if (!window.confirm(isArabic ? "هل أنت متأكد من حذف المهام المحددة؟" : "Are you sure you want to delete selected tasks?")) return;
    selectedIds.forEach((id) => deleteTask(id));
    setSelectedIds([]);
  };

  const exportTasks = (format: "pdf" | "excel" | "csv") => {
    const targetTasks = selectedIds.length > 0 ? tasks.filter(t => selectedIds.includes(t.id)) : filteredTasks;
    const exportHeaders = [
      isArabic ? "رقم المهمة" : "Task ID",
      isArabic ? "المهمة" : "Task",
      isArabic ? "الخدمة" : "Service",
      isArabic ? "الأولوية" : "Priority",
      isArabic ? "الحالة" : "Status",
      isArabic ? "الاستحقاق" : "Due Date",
      isArabic ? "المسؤول" : "Assignee"
    ];
    const exportRows = targetTasks.map((t) => [
      t.id,
      localized(t.title, language),
      localized(t.service, language),
      localized(priorityLabels[t.priority], language),
      localized(statusLabels[t.status], language),
      getDateInputValue(t.dueDate),
      t.assignee,
    ]);

    if (format === "csv") {
      const bom = "\uFEFF";
      const csvContent = bom + [exportHeaders, ...exportRows].map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(",")).join("\n");
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `tasks-${new Date().toISOString().slice(0, 10)}.csv`;
      link.click();
      URL.revokeObjectURL(url);
    } else if (format === "excel") {
      const tableRows = [exportHeaders, ...exportRows].map((row) => `<tr>${row.map((cell) => `<td>${cell}</td>`).join("")}</tr>`).join("");
      const html = `<table border="1">${tableRows}</table>`;
      const blob = new Blob([html], { type: "application/vnd.ms-excel" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `tasks-${new Date().toISOString().slice(0, 10)}.xls`;
      link.click();
      URL.revokeObjectURL(url);
    } else if (format === "pdf") {
      const w = window.open("", "_blank");
      if (!w) return;
      const dir = isArabic ? "rtl" : "ltr";
      const tableRows = exportRows.map((row) => `<tr>${row.map((cell) => `<td style="border:1px solid #ddd;padding:8px">${cell}</td>`).join("")}</tr>`).join("");
      const headerRows = exportHeaders.map((h) => `<th style="border:1px solid #ddd;padding:8px;background:#f8fafc">${h}</th>`).join("");
      w.document.write(`<!doctype html><html lang="${language}" dir="${dir}"><head><meta charset="UTF-8"><title>Tasks</title><style>body{font-family:sans-serif}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:8px;text-align:${isArabic ? "right" : "left"}}</style></head><body><h1>${isArabic ? "تقرير المهام" : "Tasks Report"}</h1><table><thead><tr>${headerRows}</tr></thead><tbody>${tableRows}</tbody></table><script>window.onload=()=>{window.print()}</script></body></html>`);
      w.document.close();
    }
    setExportOpen(false);
  };

  const printTasks = () => {
    const w = window.open("", "_blank");
    if (!w) return;
    const dir = isArabic ? "rtl" : "ltr";
    const rows = filteredTasks.map((t) => `<tr><td style="border:1px solid #ddd;padding:8px">${localized(t.title, language)}</td><td style="border:1px solid #ddd;padding:8px">${localized(t.service, language)}</td><td style="border:1px solid #ddd;padding:8px">${localized(priorityLabels[t.priority], language)}</td><td style="border:1px solid #ddd;padding:8px">${localized(statusLabels[t.status], language)}</td><td style="border:1px solid #ddd;padding:8px">${getDateInputValue(t.dueDate)}</td><td style="border:1px solid #ddd;padding:8px">${t.assignee}</td></tr>`).join("");
    const headers = [isArabic ? "المهمة" : "Task", isArabic ? "الخدمة" : "Service", isArabic ? "الأولوية" : "Priority", isArabic ? "الحالة" : "Status", isArabic ? "الاستحقاق" : "Due Date", isArabic ? "المسؤول" : "Assignee"].map((h) => `<th style="border:1px solid #ddd;padding:8px;background:#f8fafc">${h}</th>`).join("");
    w.document.write(`<!doctype html><html lang="${language}" dir="${dir}"><head><meta charset="UTF-8"><title>Print Tasks</title><style>body{font-family:sans-serif}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:8px;text-align:${isArabic ? "right" : "left"}}</style></head><body><h1>${isArabic ? "جدول المهام" : "Tasks Table"}</h1><table><thead><tr>${headers}</tr></thead><tbody>${rows}</tbody></table><script>window.onload=()=>{window.print()}</script></body></html>`);
    w.document.close();
  };

  return (
    <div className="space-y-4">
      <div className="grid gap-4 xl:grid-cols-[1.15fr_0.85fr]">
        <ShellCard className="p-5">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <p className="text-sm text-slate-500 dark:text-slate-300">{text.taskManagement}</p>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white">{text.latestTasks}</h2>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 dark:border-slate-700 dark:bg-slate-900">
                <Search className="h-4 w-4 text-slate-400" />
                <input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder={isArabic ? "بحث..." : "Search..."} className="w-32 bg-transparent text-sm outline-none" />
              </div>
              <select
                value={statusFilter}
                onChange={(event) => setStatusFilter(event.target.value as TaskStatus | "all")}
                className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm dark:border-slate-700 dark:bg-slate-900"
              >
                <option value="all">{isArabic ? "كل الحالات" : "All statuses"}</option>
                {statusOrder.map((status) => (
                  <option key={status} value={status}>
                    {localized(statusLabels[status], language)}
                  </option>
                ))}
              </select>
              <select
                value={priorityFilter}
                onChange={(event) => setPriorityFilter(event.target.value as Priority | "all")}
                className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm dark:border-slate-700 dark:bg-slate-900"
              >
                <option value="all">{isArabic ? "كل الأولويات" : "All priorities"}</option>
                {priorityOrder.map((priority) => (
                  <option key={priority} value={priority}>
                    {localized(priorityLabels[priority], language)}
                  </option>
                ))}
              </select>
              
              <div className="flex items-center gap-2">
                {selectedIds.length > 0 && (
                  <button
                    type="button"
                    onClick={handleBulkDelete}
                    className="inline-flex items-center gap-2 rounded-2xl border border-rose-200 bg-rose-50 px-5 py-3 text-sm font-bold text-rose-600 shadow-sm transition hover:bg-rose-100 dark:border-rose-900 dark:bg-rose-900/20"
                  >
                    <Trash2 className="h-4 w-4" />
                    {isArabic ? `حذف (${selectedIds.length})` : `Delete (${selectedIds.length})`}
                  </button>
                )}
                <button
                  type="button"
                  onClick={onOpenTaskForm}
                  className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-emerald-500 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-emerald-500/20 transition hover:scale-[1.02]"
                >
                  <Plus className="h-4 w-4" />
                  {text.addTask}
                </button>

                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setExportOpen(!exportOpen)}
                    className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-700 shadow-sm transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
                  >
                    <Download className="h-4 w-4" />
                    {isArabic ? "تصدير" : "Export"}
                    <ChevronDown className="h-4 w-4" />
                  </button>
                  {exportOpen && (
                    <div className={cn("absolute z-50 mt-2 w-48 origin-top-right rounded-2xl border border-slate-200 bg-white p-2 shadow-xl ring-1 ring-black ring-opacity-5 dark:border-slate-700 dark:bg-slate-800 dark:ring-white dark:ring-opacity-5", isArabic ? "right-0" : "left-0")}>
                      <button onClick={() => exportTasks("pdf")} className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-700">
                        <FileText className="h-4 w-4 text-red-500" /> PDF
                      </button>
                      <button onClick={() => exportTasks("excel")} className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-700">
                        <FileSpreadsheet className="h-4 w-4 text-emerald-500" /> Excel
                      </button>
                      <button onClick={() => exportTasks("csv")} className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-700">
                        <Table className="h-4 w-4 text-blue-500" /> CSV
                      </button>
                    </div>
                  )}
                </div>

                <button
                  type="button"
                  onClick={printTasks}
                  className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-700 shadow-sm transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  <Printer className="h-4 w-4" />
                  {isArabic ? "طباعة" : "Print"}
                </button>
              </div>
            </div>
          </div>
          <div className="mt-4 overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200/80 text-slate-500 dark:border-slate-700 dark:text-slate-300">
                  <th className="px-3 py-3 text-start">
                    <input type="checkbox" checked={selectedIds.length === filteredTasks.length && filteredTasks.length > 0} onChange={toggleSelectAll} className="h-4 w-4 accent-emerald-600" />
                  </th>
                  <th className="px-3 py-3 text-start" onClick={() => setSortSortConfig({ key: "id", direction: sortConfig?.key === "id" && sortConfig.direction === "asc" ? "desc" : "asc" })}>{isArabic ? "المهمة" : "Task"}</th>
                  <th className="px-3 py-3 text-start">{isArabic ? "الخدمة" : "Service"}</th>
                  <th className="px-3 py-3 text-start">{isArabic ? "الأولوية" : "Priority"}</th>
                  <th className="px-3 py-3 text-start">{isArabic ? "الحالة" : "Status"}</th>
                  <th className="px-3 py-3 text-start">{isArabic ? "الاستحقاق" : "Due Date"}</th>
                  <th className="px-3 py-3 text-start">{text.actions}</th>
                </tr>
              </thead>
              <tbody>
                {filteredTasks.length > 0 ? filteredTasks.map((task) => (
                  <tr key={task.id} className={cn("border-b border-slate-100 align-top last:border-none dark:border-slate-800 transition", selectedIds.includes(task.id) && "bg-emerald-500/5 dark:bg-emerald-500/10")}>
                    <td className="px-3 py-4">
                      <input type="checkbox" checked={selectedIds.includes(task.id)} onChange={() => toggleSelect(task.id)} className="h-4 w-4 accent-emerald-600" />
                    </td>
                    <td className="px-3 py-4">
                      <div className="font-semibold text-slate-900 dark:text-white">{localized(task.title, language)}</div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">{task.assignee} · {task.timeLabel}</div>
                    </td>
                    <td className="px-3 py-4 text-slate-500 dark:text-slate-300">{localized(task.service, language)}</td>
                    <td className="px-3 py-4">
                      <Badge className={getPriorityColor(task.priority)}>
                        {localized(priorityLabels[task.priority], language)}
                      </Badge>
                    </td>
                    <td className="px-3 py-4">
                      <Badge className={getTaskStatusColor(task.status)}>{localized(statusLabels[task.status], language)}</Badge>
                    </td>
                    <td className="px-3 py-4 text-slate-500 dark:text-slate-300">{getDateInputValue(task.dueDate)}</td>
                    <td className="px-3 py-4">
                      <div className="flex flex-wrap gap-1.5">
                        <ActionIconButton
                          label={isArabic ? "ابدأ" : "Start"}
                          rounded={roundedActions}
                          onClick={() => updateTask(task.id, (current) => ({ ...current, status: "In Progress" }))}
                        >
                          <Play className="h-4 w-4" />
                        </ActionIconButton>
                        <ActionIconButton
                          label={isArabic ? "كامل" : "Complete"}
                          rounded={roundedActions}
                          onClick={() => updateTask(task.id, (current) => ({ ...current, status: "Completed" }))}
                        >
                          <Check className="h-4 w-4" />
                        </ActionIconButton>
                        <ActionIconButton label={text.editTask} rounded={roundedActions} onClick={() => onEditTask(task)}>
                          <Pencil className="h-4 w-4" />
                        </ActionIconButton>
                        <ActionIconButton label={isArabic ? "تحليل الذكاء الاصطناعي" : "AI Analysis"} rounded={roundedActions} onClick={() => onAnalyzeTask(task)}>
                          <Bot className="h-4 w-4" />
                        </ActionIconButton>
                        <ActionIconButton label={text.print} rounded={roundedActions} onClick={() => printTaskDocument(task, language, settings)}>
                          <Printer className="h-4 w-4" />
                        </ActionIconButton>
                        <ActionIconButton
                          label={isArabic ? "حذف" : "Delete"}
                          rounded={roundedActions}
                          onClick={() => deleteTask(task.id)}
                          tone="danger"
                        >
                          <Trash2 className="h-4 w-4" />
                        </ActionIconButton>
                      </div>
                    </td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan={7} className="px-3 py-12 text-center text-slate-500 dark:text-slate-400">
                      <div className="flex flex-col items-center gap-2">
                        <ClipboardList className="h-10 w-10 opacity-20" />
                        <span className="font-semibold">{isArabic ? "لا توجد مهام حالياً" : "No Tasks Found"}</span>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </ShellCard>

        <ShellCard className="p-5">
          <SectionHeader title={text.smartSummary} actionLabel={text.overview} />
          <div className="mt-4 grid grid-cols-2 gap-3">
            {services.slice(0, 4).map((service) => {
              return (
                <div key={service.id} className="rounded-3xl border border-slate-200/70 bg-white/80 p-4 text-center dark:border-slate-700 dark:bg-slate-800/80">
                  <div
                    className="mx-auto flex h-14 w-14 items-center justify-center rounded-3xl text-white shadow-lg"
                    style={{ backgroundColor: service.color }}
                  >
                    <DynamicIcon icon={service.iconData} className="text-white" size={28} />
                  </div>
                  <div className="mt-3 font-semibold text-slate-900 dark:text-white">{localized(service.name, language)}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">{service.tickets} {isArabic ? "بلاغ" : "tickets"}</div>
                </div>
              );
            })}
          </div>
          <div className="mt-5 rounded-3xl border border-blue-500/10 bg-blue-500/5 p-4">
            <div className="mb-3 flex items-center gap-2 text-sm font-bold text-blue-700 dark:text-blue-300">
              <Bot className="h-5 w-5" /> {text.aiSuggestions}
            </div>
            <div className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
              {props.aiInsights.suggestions.map((suggestion) => (
                <div key={suggestion.en} className="rounded-2xl bg-white/70 p-3 dark:bg-slate-800/70">
                  {localized(suggestion, language)}
                </div>
              ))}
            </div>
          </div>
        </ShellCard>
      </div>
    </div>
  );
}

function SmartDayPage(props: SharedPageProps & { queueTasks: Task[] }) {
  const { analytics, aiInsights, language, text, queueTasks, onStartMyDay } = props;

  return (
    <div className="space-y-4">
      <div className="grid gap-4 xl:grid-cols-[0.85fr_1.15fr]">
        <ShellCard className="p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-500 dark:text-slate-300">{text.smartDay}</p>
              <h2 className="text-3xl font-black text-slate-900 dark:text-white">{text.smartRecommendations}</h2>
            </div>
            <Brain className="h-12 w-12 rounded-3xl bg-emerald-500/10 p-3 text-emerald-600 dark:text-emerald-300" />
          </div>
          <div className="mt-6 space-y-3">
            {aiInsights.suggestions.map((suggestion) => (
              <div key={suggestion.en} className="rounded-3xl border border-slate-200/70 bg-white/80 p-4 dark:border-slate-700 dark:bg-slate-800/80">
                {localized(suggestion, language)}
              </div>
            ))}
          </div>
          <button
            type="button"
            onClick={onStartMyDay}
            className="mt-6 w-full rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-[var(--primary-blue)] px-5 py-3 text-sm font-bold text-white"
          >
            {text.startMyDay}
          </button>
        </ShellCard>

        <ShellCard className="p-5">
          <SectionHeader title={text.taskQueue} actionLabel={text.viewAll} />
          <div className="mt-4 space-y-3">
            {queueTasks.map((task, index) => (
              <div key={task.id} className="flex gap-3 rounded-3xl border border-slate-200/70 bg-white/80 p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800/80">
                <div className="flex h-12 w-12 items-center justify-center rounded-3xl bg-slate-100 text-lg font-black text-slate-900 dark:bg-slate-700 dark:text-white">
                  {index + 1}
                </div>
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="font-semibold text-slate-900 dark:text-white">{localized(task.title, language)}</div>
                    <Badge className={getPriorityColor(task.priority)}>{localized(priorityLabels[task.priority], language)}</Badge>
                    <Badge className={getTaskStatusColor(task.status)}>{localized(statusLabels[task.status], language)}</Badge>
                  </div>
                  <div className="mt-1 text-sm text-slate-500 dark:text-slate-300">{localized(task.description, language)}</div>
                  <div className="mt-2 flex flex-wrap gap-4 text-xs text-slate-400">
                    <span>{task.assignee}</span>
                    <span>{task.timeLabel}</span>
                    <span>{localized(task.location, language)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ShellCard>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1fr_0.9fr_0.9fr]">
        <ChartCard title={text.productivityAnalysis}>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={weeklyPerformanceData}>
              <defs>
                <linearGradient id="smartDayArea" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0F8A5F" stopOpacity={0.45} />
                  <stop offset="95%" stopColor="#0F8A5F" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#CBD5E1" opacity={0.35} />
              <XAxis dataKey={language === "ar" ? "dayAr" : "dayEn"} stroke="#64748B" />
              <YAxis stroke="#64748B" />
              <Tooltip />
              <Area type="monotone" dataKey="productivity" stroke="#0F8A5F" strokeWidth={3} fill="url(#smartDayArea)" />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
        <ShellCard className="p-5">
          <SectionHeader title={text.urgentTasks} actionLabel={`${aiInsights.urgent.length}`} />
          <div className="mt-4 space-y-3">
            {aiInsights.urgent.map((task) => (
              <div key={task.id} className="rounded-3xl border border-fuchsia-500/10 bg-fuchsia-500/5 p-4">
                <div className="font-semibold text-slate-900 dark:text-white">{localized(task.title, language)}</div>
                <div className="mt-1 text-sm text-slate-500 dark:text-slate-300">{localized(task.service, language)}</div>
              </div>
            ))}
          </div>
        </ShellCard>
        <ShellCard className="p-5">
          <SectionHeader title={text.delayedTasks} actionLabel={`${analytics.delayedTasks}`} />
          <div className="mt-4 space-y-3">
            {aiInsights.delayed.map((task) => (
              <div key={task.id} className="rounded-3xl border border-rose-500/10 bg-rose-500/5 p-4">
                <div className="font-semibold text-slate-900 dark:text-white">{localized(task.title, language)}</div>
                <div className="mt-1 text-sm text-slate-500 dark:text-slate-300">{localized(task.notes, language)}</div>
              </div>
            ))}
          </div>
        </ShellCard>
      </div>
    </div>
  );
}

function AiAssistantPage(props: SharedPageProps) {
  const { aiInsights, analytics, language, isArabic, text, tasks, onStartMyDay } = props;

  const capabilities: { icon: LucideIcon; title: LocalizedText; desc: LocalizedText }[] = [
    {
      icon: Sparkles,
      title: { ar: "ترتيب الأولويات", en: "Task Prioritization" },
      desc: { ar: "ترتيب المهام تلقائيًا حسب الأهمية والموعد.", en: "Auto-rank tasks by importance and due date." },
    },
    {
      icon: CalendarClock,
      title: { ar: "التخطيط اليومي", en: "Daily Planning" },
      desc: { ar: "بناء خطة يوم متوازنة وقابلة للتنفيذ.", en: "Build a balanced, actionable daily plan." },
    },
    {
      icon: Activity,
      title: { ar: "تحليل عبء العمل", en: "Workload Analysis" },
      desc: { ar: "قياس التوزيع والضغط عبر الخدمات.", en: "Measure distribution and pressure across services." },
    },
    {
      icon: TimerReset,
      title: { ar: "كشف التأخير", en: "Delay Detection" },
      desc: { ar: "رصد المهام المتأخرة قبل تفاقمها.", en: "Spot delayed tasks before they escalate." },
    },
    {
      icon: RefreshCcw,
      title: { ar: "اقتراحات إعادة الجدولة", en: "Rescheduling Suggestions" },
      desc: { ar: "إعادة توزيع زمني ذكي للمهام.", en: "Smart time redistribution for tasks." },
    },
    {
      icon: FileText,
      title: { ar: "التقارير التلقائية", en: "Auto Reports" },
      desc: { ar: "توليد ملخصات يومية وأسبوعية وشهرية.", en: "Generate daily, weekly, and monthly summaries." },
    },
  ];

  const summaries: { period: LocalizedText; body: LocalizedText }[] = [
    {
      period: { ar: "ملخص يومي", en: "Daily Summary" },
      body: aiInsights.summary,
    },
    {
      period: { ar: "ملخص أسبوعي", en: "Weekly Summary" },
      body: {
        ar: `معدل الإنجاز ${analytics.completionRate}% مع ${analytics.weeklyTasks} مهمة هذا الأسبوع.`,
        en: `Completion rate is ${analytics.completionRate}% with ${analytics.weeklyTasks} tasks this week.`,
      },
    },
    {
      period: { ar: "ملخص شهري", en: "Monthly Summary" },
      body: {
        ar: `الإنتاجية ${analytics.productivityRate}% ومتوسط زمن الإنجاز ${analytics.averageCompletionTime}.`,
        en: `Productivity is ${analytics.productivityRate}% with an average completion time of ${analytics.averageCompletionTime}.`,
      },
    },
  ];

  return (
    <div className="space-y-4">
      <ShellCard className="p-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-center gap-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-br from-[var(--primary-green)] to-[var(--primary-blue)] text-white shadow-lg">
              <Bot className="h-8 w-8" />
            </div>
            <div>
              <p className="text-sm text-slate-500 dark:text-slate-300">{text.aiAssistant}</p>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white">{localized(aiInsights.summary, language)}</h2>
            </div>
          </div>
          <button
            type="button"
            onClick={onStartMyDay}
            className="rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-[var(--primary-blue)] px-6 py-3 text-sm font-bold text-white shadow-lg shadow-emerald-500/25 transition hover:scale-[1.01]"
          >
            🚀 {text.startMyDay}
          </button>
        </div>
      </ShellCard>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {capabilities.map((cap) => {
          const CapIcon = cap.icon;
          return (
            <ShellCard key={cap.title.en} className="p-5">
              <CapIcon className="h-11 w-11 rounded-3xl bg-emerald-500/10 p-2.5 text-emerald-600 dark:text-emerald-300" />
              <div className="mt-4 text-lg font-bold text-slate-900 dark:text-white">{localized(cap.title, language)}</div>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-300">{localized(cap.desc, language)}</p>
            </ShellCard>
          );
        })}
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        {summaries.map((summary) => (
          <ShellCard key={summary.period.en} className="p-5">
            <SectionHeader title={localized(summary.period, language)} actionLabel="AI" />
            <p className="mt-4 rounded-3xl border border-slate-200/70 bg-white/80 p-4 text-sm leading-7 text-slate-600 dark:border-slate-700 dark:bg-slate-800/80 dark:text-slate-200">
              {localized(summary.body, language)}
            </p>
          </ShellCard>
        ))}
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.1fr_0.9fr]">
        <ShellCard className="p-5">
          <SectionHeader title={text.smartRecommendations} actionLabel={`${aiInsights.suggestions.length}`} />
          <div className="mt-4 space-y-3">
            {aiInsights.suggestions.map((suggestion) => (
              <div key={suggestion.en} className="flex items-start gap-3 rounded-3xl border border-emerald-500/10 bg-emerald-500/5 p-4 text-sm text-slate-600 dark:text-slate-200">
                <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600 dark:text-emerald-300" />
                {localized(suggestion, language)}
              </div>
            ))}
          </div>
        </ShellCard>

        <ShellCard className="p-5">
          <SectionHeader title={text.taskQueue} actionLabel={`${tasks.length}`} />
          <div className="mt-4 space-y-3">
            {aiInsights.smartPlan.slice(0, 5).map((task, index) => (
              <div key={task.id} className="flex items-center gap-3 rounded-3xl border border-slate-200/70 bg-white/80 p-3 dark:border-slate-700 dark:bg-slate-800/80">
                <span className="flex h-9 w-9 items-center justify-center rounded-2xl bg-slate-100 text-sm font-black text-slate-900 dark:bg-slate-700 dark:text-white">
                  {index + 1}
                </span>
                <div className="flex-1">
                  <div className="text-sm font-semibold text-slate-900 dark:text-white">{localized(task.title, language)}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">{localized(task.service, language)}</div>
                </div>
                <Badge className={getPriorityColor(task.priority)}>{localized(priorityLabels[task.priority], language)}</Badge>
              </div>
            ))}
          </div>
          <div className="mt-4 grid grid-cols-3 gap-3 text-center">
            <MetricTile label={text.todayTasks} value={`${aiInsights.today.length}`} />
            <MetricTile label={text.urgentTasks} value={`${aiInsights.urgent.length}`} />
            <MetricTile label={isArabic ? "متأخرة" : "Delayed"} value={`${aiInsights.delayed.length}`} />
          </div>
        </ShellCard>
      </div>
    </div>
  );
}

function DepartmentsPage(props: SharedPageProps) {
  const { departments, upsertDepartment, deleteDepartment, isArabic } = props;
  const [search, setSearch] = useState("");
  const [editId, setEditId] = useState<string | null>(null);
  const [editNameAr, setEditNameAr] = useState("");
  const [editNameEn, setEditNameEn] = useState("");
  const [editCode, setEditCode] = useState("");
  const [newNameAr, setNewNameAr] = useState("");
  const [newNameEn, setNewNameEn] = useState("");
  const [newCode, setNewCode] = useState("");
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const filtered = departments
    .filter((dep) => {
      if (!search.trim()) return true;
      const term = search.toLowerCase();
      return dep.name.ar.toLowerCase().includes(term) || dep.name.en.toLowerCase().includes(term) || dep.code.toLowerCase().includes(term);
    })
    .sort((a, b) => a.order - b.order);

  const addDepartment = () => {
    if (!newNameAr.trim() || !newNameEn.trim()) return;
    const dep: Department = {
      id: `DEP-${Math.floor(Math.random() * 9000 + 1000)}`,
      name: { ar: newNameAr.trim(), en: newNameEn.trim() },
      code: newCode.trim() || newNameEn.trim().slice(0, 6).toUpperCase().replace(/\s/g, "-"),
      enabled: true,
      order: departments.length + 1,
    };
    upsertDepartment(dep);
    setNewNameAr("");
    setNewNameEn("");
    setNewCode("");
  };

  const startEdit = (dep: Department) => {
    setEditId(dep.id);
    setEditNameAr(dep.name.ar);
    setEditNameEn(dep.name.en);
    setEditCode(dep.code);
  };

  const saveEdit = () => {
    const dep = departments.find(d => d.id === editId);
    if (dep) {
      upsertDepartment({ ...dep, name: { ar: editNameAr, en: editNameEn }, code: editCode });
      setEditId(null);
    }
  };

  const toggleEnabled = (id: string) => {
    const dep = departments.find(d => d.id === id);
    if (dep) upsertDepartment({ ...dep, enabled: !dep.enabled });
  };

  const reorderDep = (id: string, direction: "up" | "down") => {
    const index = departments.findIndex((dep) => dep.id === id);
    if (index < 0) return;
    const swapIndex = direction === "up" ? index - 1 : index + 1;
    if (swapIndex < 0 || swapIndex >= departments.length) return;
    const updated = [...departments];
    [updated[index], updated[swapIndex]] = [updated[swapIndex], updated[index]];
    updated.forEach((d, i) => upsertDepartment({ ...d, order: i + 1 }));
  };

  const confirmDelete = () => {
    if (deleteConfirm) {
      deleteDepartment(deleteConfirm);
      setDeleteConfirm(null);
    }
  };

  return (
    <div className="space-y-4">
      <ShellCard className="p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-300">{isArabic ? "إدارة الجهات" : "Department Management"}</p>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">{isArabic ? "الجهات" : "Departments"}</h2>
          </div>
          <div className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2 dark:border-slate-700 dark:bg-slate-900">
            <Search className="h-4 w-4 text-slate-400" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={isArabic ? "بحث عن جهة..." : "Search departments..."}
              className="w-48 bg-transparent text-sm outline-none"
            />
          </div>
        </div>
      </ShellCard>

      <ShellCard className="p-5">
        <SectionHeader title={isArabic ? "إضافة جهة جديدة" : "Add New Department"} actionLabel="" />
        <div className="mt-4 grid gap-3 sm:grid-cols-4">
          <input value={newNameAr} onChange={(e) => setNewNameAr(e.target.value)} placeholder={isArabic ? "اسم الجهة بالعربية" : "Arabic Name"} className="field-input" />
          <input value={newNameEn} onChange={(e) => setNewNameEn(e.target.value)} placeholder={isArabic ? "اسم الجهة بالإنجليزية" : "English Name"} className="field-input" />
          <input value={newCode} onChange={(e) => setNewCode(e.target.value)} placeholder={isArabic ? "رمز الجهة" : "Code"} className="field-input" />
          <button type="button" onClick={addDepartment} className="inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-[var(--primary-blue)] px-5 py-3 text-sm font-bold text-white">
            <Plus className="h-4 w-4" />
            {isArabic ? "إضافة" : "Add"}
          </button>
        </div>
      </ShellCard>

      <ShellCard className="p-5">
        <SectionHeader title={isArabic ? "قائمة الجهات" : "Departments List"} actionLabel={`${filtered.length}`} />
        <div className="mt-4 overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200/80 text-slate-500 dark:border-slate-700 dark:text-slate-300">
                <th className="px-3 py-3 text-start">#</th>
                <th className="px-3 py-3 text-start">{isArabic ? "الاسم بالعربية" : "Arabic Name"}</th>
                <th className="px-3 py-3 text-start">{isArabic ? "الاسم بالإنجليزية" : "English Name"}</th>
                <th className="px-3 py-3 text-start">{isArabic ? "الرمز" : "Code"}</th>
                <th className="px-3 py-3 text-start">{isArabic ? "الحالة" : "Status"}</th>
                <th className="px-3 py-3 text-start">{isArabic ? "الإجراءات" : "Actions"}</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((dep, index) => (
                <tr key={dep.id} className="border-b border-slate-100 last:border-none dark:border-slate-800">
                  <td className="px-3 py-4 font-bold text-slate-500 dark:text-slate-400">{index + 1}</td>
                  <td className="px-3 py-4">
                    {editId === dep.id ? (
                      <input value={editNameAr} onChange={(e) => setEditNameAr(e.target.value)} className="field-input py-2" />
                    ) : (
                      <span className="font-semibold text-slate-900 dark:text-white">{dep.name.ar}</span>
                    )}
                  </td>
                  <td className="px-3 py-4">
                    {editId === dep.id ? (
                      <input value={editNameEn} onChange={(e) => setEditNameEn(e.target.value)} className="field-input py-2" />
                    ) : (
                      <span className="text-slate-600 dark:text-slate-300">{dep.name.en}</span>
                    )}
                  </td>
                  <td className="px-3 py-4">
                    {editId === dep.id ? (
                      <input value={editCode} onChange={(e) => setEditCode(e.target.value)} className="field-input py-2 w-28" />
                    ) : (
                      <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-600 dark:bg-slate-700 dark:text-slate-200">{dep.code}</span>
                    )}
                  </td>
                  <td className="px-3 py-4">
                    <button type="button" onClick={() => toggleEnabled(dep.id)} className={cn("rounded-full px-3 py-1 text-xs font-bold", dep.enabled ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300" : "bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300")}>
                      {dep.enabled ? (isArabic ? "مفعّلة" : "Enabled") : isArabic ? "غير مفعّلة" : "Disabled"}
                    </button>
                  </td>
                  <td className="px-3 py-4">
                    <div className="flex flex-wrap gap-1.5">
                      {editId === dep.id ? (
                        <>
                          <ActionIconButton label={isArabic ? "حفظ" : "Save"} rounded onClick={saveEdit}><Check className="h-4 w-4" /></ActionIconButton>
                          <ActionIconButton label={isArabic ? "إلغاء" : "Cancel"} rounded onClick={() => setEditId(null)}><X className="h-4 w-4" /></ActionIconButton>
                        </>
                      ) : (
                        <>
                          <ActionIconButton label={isArabic ? "تعديل" : "Edit"} rounded onClick={() => startEdit(dep)}><Pencil className="h-4 w-4" /></ActionIconButton>
                          <ActionIconButton label={isArabic ? "ترتيب لأعلى" : "Move Up"} rounded onClick={() => reorderDep(dep.id, "up")}><ChevronUp className="h-4 w-4" /></ActionIconButton>
                          <ActionIconButton label={isArabic ? "ترتيب لأسفل" : "Move Down"} rounded onClick={() => reorderDep(dep.id, "down")}><ChevronDown className="h-4 w-4" /></ActionIconButton>
                          <ActionIconButton label={isArabic ? "حذف" : "Delete"} rounded tone="danger" onClick={() => setDeleteConfirm(dep.id)}><Trash2 className="h-4 w-4" /></ActionIconButton>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </ShellCard>

      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm">
          <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-md rounded-[2rem] border border-white/60 bg-white p-6 shadow-2xl dark:border-slate-700 dark:bg-slate-900">
            <div className="text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-rose-500/10">
                <Trash2 className="h-8 w-8 text-rose-500" />
              </div>
              <h3 className="mt-4 text-xl font-black text-slate-900 dark:text-white">
                {isArabic ? "هل أنت متأكد من حذف هذه الجهة؟" : "Are you sure you want to delete this department?"}
              </h3>
              <div className="mt-6 flex justify-center gap-3">
                <button type="button" onClick={confirmDelete} className="inline-flex items-center gap-2 rounded-2xl bg-rose-600 px-5 py-3 text-sm font-bold text-white">
                  <Trash2 className="h-4 w-4" />
                  {isArabic ? "حذف" : "Delete"}
                </button>
                <button type="button" onClick={() => setDeleteConfirm(null)} className="rounded-2xl border border-slate-200 px-5 py-3 text-sm font-semibold dark:border-slate-700">
                  {isArabic ? "إلغاء" : "Cancel"}
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}

function DeviceTypesPage(props: SharedPageProps) {
  const { deviceTypes, upsertDeviceType, language, isArabic } = props;
  void language;
  const [search, setSearch] = useState("");
  const [editId, setEditId] = useState<string | null>(null);
  const [editNameAr, setEditNameAr] = useState("");
  const [editNameEn, setEditNameEn] = useState("");
  const [editCode, setEditCode] = useState("");
  const [editIconData, setEditIconData] = useState<IconData>({ type: "emoji", value: "🔧" });
  
  const [newNameAr, setNewNameAr] = useState("");
  const [newNameEn, setNewNameEn] = useState("");
  const [newCode, setNewCode] = useState("");
  const [newIconData, setNewIconData] = useState<IconData>({ type: "emoji", value: "🔧" });
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const filtered = deviceTypes
    .filter((dt) => {
      if (!search.trim()) return true;
      const term = search.toLowerCase();
      return dt.name.ar.toLowerCase().includes(term) || dt.name.en.toLowerCase().includes(term) || dt.code.toLowerCase().includes(term);
    })
    .sort((a, b) => a.order - b.order);

  const addDeviceType = () => {
    if (!newNameAr.trim() || !newNameEn.trim()) return;
    const dt: DeviceType = {
      id: `DT-${Math.floor(Math.random() * 9000 + 1000)}`,
      name: { ar: newNameAr.trim(), en: newNameEn.trim() },
      code: newCode.trim() || newNameEn.trim().slice(0, 8).toUpperCase().replace(/\s/g, ""),
      iconData: newIconData,
      enabled: true,
      order: deviceTypes.length + 1,
    };
    upsertDeviceType(dt);
    setNewNameAr(""); setNewNameEn(""); setNewCode(""); setNewIconData({ type: "emoji", value: "🔧" });
  };

  const startEdit = (dt: DeviceType) => {
    setEditId(dt.id); setEditNameAr(dt.name.ar); setEditNameEn(dt.name.en); setEditCode(dt.code); setEditIconData(dt.iconData);
  };

  const saveEdit = () => {
    const dt = deviceTypes.find(d => d.id === editId);
    if (dt) {
      upsertDeviceType({ ...dt, name: { ar: editNameAr, en: editNameEn }, code: editCode, iconData: editIconData });
      setEditId(null);
    }
  };

  const toggleEnabled = (id: string) => {
    const dt = deviceTypes.find(d => d.id === id);
    if (dt) upsertDeviceType({ ...dt, enabled: !dt.enabled });
  };

  const reorderDT = (id: string, direction: "up" | "down") => {
    const index = deviceTypes.findIndex((dt) => dt.id === id);
    if (index < 0) return;
    const swapIndex = direction === "up" ? index - 1 : index + 1;
    if (swapIndex < 0 || swapIndex >= deviceTypes.length) return;
    const updated = [...deviceTypes];
    [updated[index], updated[swapIndex]] = [updated[swapIndex], updated[index]];
    updated.forEach((dt, i) => upsertDeviceType({ ...dt, order: i + 1 }));
  };

  const confirmDelete = () => {
    // In production we would have a deleteDeviceType mutation
    // For now we just filter locally (Supabase delete not yet in sharedPageProps for DT)
    setDeleteConfirm(null);
  };

  return (
    <div className="space-y-4">
      <ShellCard className="p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-300">{isArabic ? "إدارة أنواع الأجهزة" : "Device Types Management"}</p>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">{isArabic ? "أنواع الأجهزة" : "Device Types"}</h2>
          </div>
          <div className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2 dark:border-slate-700 dark:bg-slate-900">
            <Search className="h-4 w-4 text-slate-400" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={isArabic ? "بحث عن نوع جهاز..." : "Search device types..."} className="w-48 bg-transparent text-sm outline-none" />
          </div>
        </div>
      </ShellCard>

      <ShellCard className="p-5">
        <SectionHeader title={isArabic ? "إضافة نوع جهاز جديد" : "Add New Device Type"} actionLabel="" />
        <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_minmax(0,2fr)]">
          <div className="space-y-3">
            <Field label={isArabic ? "أيقونة الجهاز" : "Device Icon"}>
              <IconPicker value={newIconData} onChange={setNewIconData} isArabic={isArabic} />
            </Field>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label={isArabic ? "الاسم بالعربية" : "Arabic Name"}>
              <input value={newNameAr} onChange={(e) => setNewNameAr(e.target.value)} placeholder={isArabic ? "الاسم بالعربية" : "Arabic Name"} className="field-input" />
            </Field>
            <Field label={isArabic ? "الاسم بالإنجليزية" : "English Name"}>
              <input value={newNameEn} onChange={(e) => setNewNameEn(e.target.value)} placeholder={isArabic ? "الاسم بالإنجليزية" : "English Name"} className="field-input" />
            </Field>
            <Field label={isArabic ? "رمز الجهاز" : "Code"}>
              <input value={newCode} onChange={(e) => setNewCode(e.target.value)} placeholder={isArabic ? "رمز الجهاز" : "Code"} className="field-input" />
            </Field>
            <div className="sm:col-span-2 flex items-end">
              <button type="button" onClick={addDeviceType} className="w-full inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-[var(--primary-blue)] px-5 py-3 text-sm font-bold text-white">
                <Plus className="h-4 w-4" />
                {isArabic ? "إضافة" : "Add"}
              </button>
            </div>
          </div>
        </div>
      </ShellCard>

      <ShellCard className="p-5">
        <SectionHeader title={isArabic ? "قائمة أنواع الأجهزة" : "Device Types List"} actionLabel={`${filtered.length}`} />
        <div className="mt-4 overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200/80 text-slate-500 dark:border-slate-700 dark:text-slate-300">
                <th className="px-3 py-3 text-start">#</th>
                <th className="px-3 py-3 text-start">{isArabic ? "أيقونة" : "Icon"}</th>
                <th className="px-3 py-3 text-start">{isArabic ? "الاسم بالعربية" : "Arabic Name"}</th>
                <th className="px-3 py-3 text-start">{isArabic ? "الاسم بالإنجليزية" : "English Name"}</th>
                <th className="px-3 py-3 text-start">{isArabic ? "الرمز" : "Code"}</th>
                <th className="px-3 py-3 text-start">{isArabic ? "الحالة" : "Status"}</th>
                <th className="px-3 py-3 text-start">{isArabic ? "الإجراءات" : "Actions"}</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((dt, index) => (
                <tr key={dt.id} className="border-b border-slate-100 last:border-none dark:border-slate-800">
                  <td className="px-3 py-4 font-bold text-slate-500 dark:text-slate-400">{index + 1}</td>
                  <td className="px-3 py-4 text-2xl">
                    {editId === dt.id ? (
                      <IconPicker value={editIconData} onChange={setEditIconData} isArabic={isArabic} />
                    ) : (
                      <DynamicIcon icon={dt.iconData} size={24} />
                    )}
                  </td>
                  <td className="px-3 py-4">
                    {editId === dt.id ? <input value={editNameAr} onChange={(e) => setEditNameAr(e.target.value)} className="field-input py-2" /> : <span className="font-semibold text-slate-900 dark:text-white">{dt.name.ar}</span>}
                  </td>
                  <td className="px-3 py-4">
                    {editId === dt.id ? <input value={editNameEn} onChange={(e) => setEditNameEn(e.target.value)} className="field-input py-2" /> : <span className="text-slate-600 dark:text-slate-300">{dt.name.en}</span>}
                  </td>
                  <td className="px-3 py-4">
                    {editId === dt.id ? <input value={editCode} onChange={(e) => setEditCode(e.target.value)} className="field-input w-28 py-2" /> : <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-600 dark:bg-slate-700 dark:text-slate-200">{dt.code}</span>}
                  </td>
                  <td className="px-3 py-4">
                    <button type="button" onClick={() => toggleEnabled(dt.id)} className={cn("rounded-full px-3 py-1 text-xs font-bold", dt.enabled ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300" : "bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300")}>
                      {dt.enabled ? (isArabic ? "مفعّل" : "Enabled") : isArabic ? "غير مفعّل" : "Disabled"}
                    </button>
                  </td>
                  <td className="px-3 py-4">
                    <div className="flex flex-wrap gap-1.5">
                      {editId === dt.id ? (
                        <>
                          <ActionIconButton label={isArabic ? "حفظ" : "Save"} rounded onClick={saveEdit}><Check className="h-4 w-4" /></ActionIconButton>
                          <ActionIconButton label={isArabic ? "إلغاء" : "Cancel"} rounded onClick={() => setEditId(null)}><X className="h-4 w-4" /></ActionIconButton>
                        </>
                      ) : (
                        <>
                          <ActionIconButton label={isArabic ? "تعديل" : "Edit"} rounded onClick={() => startEdit(dt)}><Pencil className="h-4 w-4" /></ActionIconButton>
                          <ActionIconButton label={isArabic ? "ترتيب لأعلى" : "Move Up"} rounded onClick={() => reorderDT(dt.id, "up")}><ChevronUp className="h-4 w-4" /></ActionIconButton>
                          <ActionIconButton label={isArabic ? "ترتيب لأسفل" : "Move Down"} rounded onClick={() => reorderDT(dt.id, "down")}><ChevronDown className="h-4 w-4" /></ActionIconButton>
                          <ActionIconButton label={isArabic ? "حذف" : "Delete"} rounded tone="danger" onClick={() => setDeleteConfirm(dt.id)}><Trash2 className="h-4 w-4" /></ActionIconButton>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </ShellCard>

      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm">
          <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-md rounded-[2rem] border border-white/60 bg-white p-6 shadow-2xl dark:border-slate-700 dark:bg-slate-900">
            <div className="text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-rose-500/10">
                <Trash2 className="h-8 w-8 text-rose-500" />
              </div>
              <h3 className="mt-4 text-xl font-black text-slate-900 dark:text-white">
                {isArabic ? "هل أنت متأكد من حذف نوع الجهاز؟" : "Are you sure you want to delete this device type?"}
              </h3>
              <div className="mt-6 flex justify-center gap-3">
                <button type="button" onClick={confirmDelete} className="inline-flex items-center gap-2 rounded-2xl bg-rose-600 px-5 py-3 text-sm font-bold text-white">
                  <Trash2 className="h-4 w-4" />
                  {isArabic ? "حذف" : "Delete"}
                </button>
                <button type="button" onClick={() => setDeleteConfirm(null)} className="rounded-2xl border border-slate-200 px-5 py-3 text-sm font-semibold dark:border-slate-700">
                  {isArabic ? "إلغاء" : "Cancel"}
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}

function CalendarPage(props: SharedPageProps) {
  const { tasks, language, isArabic, text, calendarView, setCalendarView, handleDropTaskDate, dragTaskId, setDragTaskId } = props;
  const weekDates = getWeekDates();
  const dayTasks = tasks.filter((task) => isSameDay(task.dueDate, new Date()));
  const monthDays = Array.from({ length: 30 }, (_, index) => index + 1);

  return (
    <div className="space-y-4">
      <ShellCard className="p-5">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-300">{text.calendar}</p>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">{isArabic ? "عرض التقويم الذكي" : "Smart Calendar Views"}</h2>
          </div>
          <div className="flex flex-wrap gap-2 rounded-3xl border border-slate-200 bg-slate-50 p-1 dark:border-slate-700 dark:bg-slate-900">
            {([
              ["day", text.dayView],
              ["week", text.weekView],
              ["month", text.monthView],
              ["year", text.yearView],
            ] as const).map(([value, label]) => (
              <button
                key={value}
                type="button"
                onClick={() => setCalendarView(value)}
                className={cn(
                  "rounded-2xl px-4 py-2 text-sm font-semibold transition",
                  calendarView === value
                    ? "bg-white text-slate-900 shadow dark:bg-slate-800 dark:text-white"
                    : "text-slate-500 dark:text-slate-300",
                )}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
      </ShellCard>

      {calendarView === "day" && (
        <ShellCard className="p-5">
          <SectionHeader title={text.dayView} actionLabel={`${dayTasks.length} ${isArabic ? "مهمة" : "tasks"}`} />
          <div className="mt-4 space-y-3">
            {dayTasks.map((task) => (
              <div key={task.id} className="rounded-3xl border border-slate-200/70 bg-white/80 p-4 dark:border-slate-700 dark:bg-slate-800/80">
                <div className="flex flex-wrap items-center gap-2">
                  <div className="font-semibold text-slate-900 dark:text-white">{localized(task.title, language)}</div>
                  <Badge className={getPriorityColor(task.priority)}>{localized(priorityLabels[task.priority], language)}</Badge>
                </div>
                <div className="mt-2 text-sm text-slate-500 dark:text-slate-300">{task.timeLabel} · {localized(task.location, language)}</div>
              </div>
            ))}
          </div>
        </ShellCard>
      )}

      {calendarView === "week" && (
        <div className="grid gap-4 xl:grid-cols-7">
          {weekDates.map((date) => {
            const columnTasks = tasks.filter((task) => isSameDay(task.dueDate, date));
            return (
              <ShellCard
                key={date.toISOString()}
                className="p-4"
                onDragOver={(event) => event.preventDefault()}
                onDrop={() => dragTaskId && handleDropTaskDate(dragTaskId, date)}
              >
                <div className="mb-3 rounded-2xl bg-slate-100 px-3 py-2 text-center text-sm font-bold text-slate-700 dark:bg-slate-800 dark:text-slate-100">
                  <div>{new Intl.DateTimeFormat(language === "ar" ? "ar-SA" : "en-US", { weekday: "short" }).format(date)}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">{formatShortDate(date.toISOString(), language)}</div>
                </div>
                <div className="space-y-3">
                  {columnTasks.map((task) => (
                    <div
                      key={task.id}
                      draggable
                      onDragStart={() => setDragTaskId(task.id)}
                      className="cursor-grab rounded-3xl border border-slate-200/70 bg-white/80 p-3 shadow-sm active:cursor-grabbing dark:border-slate-700 dark:bg-slate-800/80"
                    >
                      <div className="mb-2 flex items-center justify-between">
                        <GripVertical className="h-4 w-4 text-slate-400" />
                        <Badge className={getPriorityColor(task.priority)}>{localized(priorityLabels[task.priority], language)}</Badge>
                      </div>
                      <div className="text-sm font-semibold text-slate-900 dark:text-white">{localized(task.title, language)}</div>
                      <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">{task.timeLabel}</div>
                    </div>
                  ))}
                </div>
              </ShellCard>
            );
          })}
        </div>
      )}

      {calendarView === "month" && (
        <ShellCard className="p-5">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6">
            {monthDays.map((day) => {
              const count = tasks.filter((task) => new Date(task.dueDate).getDate() === day).length;
              return (
                <div key={day} className="rounded-3xl border border-slate-200/70 bg-white/80 p-4 dark:border-slate-700 dark:bg-slate-800/80">
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-black text-slate-900 dark:text-white">{day}</span>
                    <span className="rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-bold text-emerald-700 dark:text-emerald-300">{count}</span>
                  </div>
                  <div className="mt-4 h-2 rounded-full bg-slate-100 dark:bg-slate-700">
                    <div className="h-2 rounded-full bg-gradient-to-r from-[var(--primary-green)] to-[var(--primary-blue)]" style={{ width: `${Math.min(count * 18, 100)}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </ShellCard>
      )}

      {calendarView === "year" && (
        <ChartCard title={text.yearView}>
          <ResponsiveContainer width="100%" height={320}>
            <BarChart data={yearHeatmapData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#CBD5E1" opacity={0.35} />
              <XAxis dataKey={language === "ar" ? "monthAr" : "monthEn"} stroke="#64748B" />
              <YAxis stroke="#64748B" />
              <Tooltip />
              <Bar dataKey="score" fill="#2563EB" radius={[10, 10, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      )}
    </div>
  );
}

function ServicesPage(props: SharedPageProps) {
  const { services, meetings, upsertService, deleteService, language, isArabic, text, serviceForm, setServiceForm, saveService, reorderService, serviceFormIcon, setServiceFormIcon } = props;

  return (
    <div className="space-y-4">
      <div className="grid gap-4 xl:grid-cols-[1.1fr_0.9fr]">
        <ShellCard className="p-5">
          <SectionHeader title={text.technicalServices} actionLabel={text.viewAll} />
          <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {services.map((service) => {
              return (
                <div key={service.id} className="rounded-[1.75rem] border border-slate-200/70 bg-white/80 p-4 shadow-sm dark:border-slate-700 dark:bg-slate-800/80">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className="flex h-14 w-14 items-center justify-center rounded-3xl text-white shadow-lg"
                        style={{ backgroundColor: service.color }}
                      >
                        <DynamicIcon icon={service.iconData} className="text-white" size={28} />
                      </div>
                      <div>
                        <div className="font-bold text-slate-900 dark:text-white">{localized(service.name, language)}</div>
                        <div className="text-xs text-slate-500 dark:text-slate-400">{localized(service.category, language)}</div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => upsertService({ ...service, enabled: !service.enabled })}
                      className={cn(
                        "rounded-full px-3 py-1 text-xs font-bold",
                        service.enabled
                          ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300"
                          : "bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-200",
                      )}
                    >
                      {service.enabled ? (isArabic ? "مفعّلة" : "Enabled") : isArabic ? "معطلة" : "Disabled"}
                    </button>
                  </div>
                  <p className="mt-4 text-sm text-slate-500 dark:text-slate-300">{localized(service.description, language)}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {service.subServices.map((subService) => (
                      <span key={subService.en} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-600 dark:bg-slate-700 dark:text-slate-200">
                        {localized(subService, language)}
                      </span>
                    ))}
                  </div>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setServiceForm({
                          id: service.id,
                          nameAr: service.name.ar,
                          nameEn: service.name.en,
                          descriptionAr: service.description.ar,
                          descriptionEn: service.description.en,
                          emoji: "",
                          iconName: "",
                          color: service.color,
                        });
                        setServiceFormIcon(service.iconData);
                      }}
                      className="rounded-2xl border border-slate-200 px-3 py-2 text-sm font-semibold dark:border-slate-700"
                    >
                      <Pencil className="me-2 inline h-4 w-4" />
                      {isArabic ? "تعديل" : "Edit"}
                    </button>
                    <button
                      type="button"
                      onClick={() => reorderService(service.id, "up")}
                      className="rounded-2xl border border-slate-200 px-3 py-2 text-sm font-semibold dark:border-slate-700"
                    >
                      <ChevronUp className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => reorderService(service.id, "down")}
                      className="rounded-2xl border border-slate-200 px-3 py-2 text-sm font-semibold dark:border-slate-700"
                    >
                      <ChevronDown className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => deleteService(service.id)}
                      className="rounded-2xl border border-rose-200 px-3 py-2 text-sm font-semibold text-rose-600 dark:border-rose-500/30 dark:text-rose-300"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </ShellCard>

        <div className="space-y-4">
          <ShellCard className="p-5">
            <SectionHeader title={text.addService} actionLabel={text.save} />
            <div className="mt-4 grid gap-3">
              <input
                value={serviceForm.nameAr}
                onChange={(event) => setServiceForm((current) => ({ ...current, nameAr: event.target.value }))}
                placeholder={isArabic ? "اسم الخدمة بالعربية" : "Service name (Arabic)"}
                className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm dark:border-slate-700 dark:bg-slate-900"
              />
              <input
                value={serviceForm.nameEn}
                onChange={(event) => setServiceForm((current) => ({ ...current, nameEn: event.target.value }))}
                placeholder={isArabic ? "اسم الخدمة بالإنجليزية" : "Service name (English)"}
                className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm dark:border-slate-700 dark:bg-slate-900"
              />
              <textarea
                value={serviceForm.descriptionAr}
                onChange={(event) => setServiceForm((current) => ({ ...current, descriptionAr: event.target.value }))}
                placeholder={isArabic ? "وصف عربي" : "Arabic description"}
                className="min-h-24 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm dark:border-slate-700 dark:bg-slate-900"
              />
              <textarea
                value={serviceForm.descriptionEn}
                onChange={(event) => setServiceForm((current) => ({ ...current, descriptionEn: event.target.value }))}
                placeholder={isArabic ? "وصف إنجليزي" : "English description"}
                className="min-h-24 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm dark:border-slate-700 dark:bg-slate-900"
              />
              <div className="space-y-3">
                <Field label={isArabic ? "أيقونة الخدمة" : "Service Icon"}>
                  <IconPicker value={serviceFormIcon} onChange={setServiceFormIcon} isArabic={isArabic} />
                </Field>
                <Field label={isArabic ? "لون الخدمة" : "Service Color"}>
                  <input
                    type="color"
                    value={serviceForm.color}
                    onChange={(event) => setServiceForm((current) => ({ ...current, color: event.target.value }))}
                    className="h-12 w-full rounded-2xl border border-slate-200 bg-white p-2 dark:border-slate-700 dark:bg-slate-900"
                  />
                </Field>
              </div>
              <button
                type="button"
                onClick={saveService}
                className="rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-[var(--primary-blue)] px-5 py-3 text-sm font-bold text-white"
              >
                {text.save}
              </button>
            </div>
          </ShellCard>

          <ShellCard className="p-5">
            <SectionHeader title={text.smartMeetings} actionLabel={text.overview} />
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {meetings.map((meeting) => (
                <div key={meeting.id} className="rounded-3xl border border-slate-200/70 bg-white/80 p-4 dark:border-slate-700 dark:bg-slate-800/80">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-bold text-slate-900 dark:text-white">{meeting.name}</div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">{meeting.provider}</div>
                    </div>
                    <span className="rounded-full px-3 py-1 text-xs font-bold" style={{ backgroundColor: `${meeting.accent}15`, color: meeting.accent }}>
                      {meeting.nextMeeting}
                    </span>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <a href={meeting.link} target="_blank" rel="noreferrer" className="rounded-2xl bg-slate-900 px-3 py-2 text-sm font-semibold text-white dark:bg-white dark:text-slate-900">
                      {isArabic ? "تشغيل سريع" : "Quick Launch"}
                    </a>
                    <button type="button" onClick={() => navigator.clipboard.writeText(meeting.link)} className="rounded-2xl border border-slate-200 px-3 py-2 text-sm font-semibold dark:border-slate-700">
                      {isArabic ? "إدارة الرابط" : "Manage Link"}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </ShellCard>
        </div>
      </div>
    </div>
  );
}

function NotesPage(props: SharedPageProps) {
  const { notes, language, isArabic, text, selectedNote, selectedNoteId, setSelectedNoteId, setNotes } = props;

  return (
    <div className="grid gap-4 xl:grid-cols-[0.8fr_1.2fr]">
      <ShellCard className="p-5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-300">{text.notes}</p>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">{isArabic ? "ملاحظات بأسلوب Notion" : "Notion-style Notes"}</h2>
          </div>
          <button
            type="button"
            onClick={() => {
              const newNote: Note = {
                id: `NOTE-${Math.floor(Math.random() * 999)}`,
                title: { ar: "ملاحظة جديدة", en: "New Note" },
                summary: { ar: "محتوى أولي قابل للتعديل.", en: "Starter content ready to edit." },
                updatedAt: new Date().toISOString(),
                tags: ["new"],
                files: [],
                blocks: [
                  {
                    type: "paragraph",
                    content: { ar: "ابدأ بتوثيق خطوات العمل اليومية هنا.", en: "Start documenting daily work steps here." },
                  },
                ],
              };
              setNotes((current) => [newNote, ...current]);
              setSelectedNoteId(newNote.id);
            }}
            className="rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-[var(--primary-blue)] px-4 py-3 text-sm font-bold text-white"
          >
            <Plus className="me-2 inline h-4 w-4" />
            {isArabic ? "ملاحظة جديدة" : "New Note"}
          </button>
        </div>
        <div className="mt-4 space-y-3">
          {notes.map((note) => (
            <button
              key={note.id}
              type="button"
              onClick={() => setSelectedNoteId(note.id)}
              className={cn(
                "w-full rounded-3xl border p-4 text-start transition",
                selectedNoteId === note.id
                  ? "border-emerald-500/20 bg-emerald-500/10"
                  : "border-slate-200/70 bg-white/80 hover:border-slate-300 dark:border-slate-700 dark:bg-slate-800/80",
              )}
            >
              <div className="font-bold text-slate-900 dark:text-white">{localized(note.title, language)}</div>
              <div className="mt-1 text-sm text-slate-500 dark:text-slate-300">{localized(note.summary, language)}</div>
              <div className="mt-3 flex flex-wrap gap-2">
                {note.tags.map((tag) => (
                  <span key={tag} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-600 dark:bg-slate-700 dark:text-slate-200">
                    #{tag}
                  </span>
                ))}
              </div>
            </button>
          ))}
        </div>
      </ShellCard>

      <ShellCard className="p-5">
        {selectedNote ? (
          <>
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="text-sm text-slate-500 dark:text-slate-300">{selectedNote.updatedAt.slice(0, 10)}</p>
                <h2 className="text-3xl font-black text-slate-900 dark:text-white">{localized(selectedNote.title, language)}</h2>
              </div>
              <div className="rounded-3xl border border-slate-200 bg-slate-50 px-4 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
                {selectedNote.files.length} {isArabic ? "ملفات" : "files"}
              </div>
            </div>
            <div className="mt-6 space-y-4">
              {selectedNote.blocks.map((block, index) => {
                if (block.type === "paragraph") {
                  return (
                    <div key={index} className="rounded-3xl border border-slate-200/70 bg-white/80 p-4 text-sm leading-7 text-slate-600 dark:border-slate-700 dark:bg-slate-800/80 dark:text-slate-200">
                      {localized(block.content, language)}
                    </div>
                  );
                }

                if (block.type === "checklist") {
                  return (
                    <div key={index} className="rounded-3xl border border-slate-200/70 bg-white/80 p-4 dark:border-slate-700 dark:bg-slate-800/80">
                      <div className="space-y-3">
                        {block.items.map((item) => (
                          <label key={item.label.en} className="flex items-center gap-3 text-sm text-slate-600 dark:text-slate-200">
                            <input type="checkbox" checked={item.done} readOnly className="h-4 w-4 rounded" />
                            {localized(item.label, language)}
                          </label>
                        ))}
                      </div>
                    </div>
                  );
                }

                if (block.type === "code") {
                  return (
                    <div key={index} className="overflow-hidden rounded-3xl border border-slate-200/70 bg-slate-950 dark:border-slate-700">
                      <div className="border-b border-white/10 px-4 py-2 text-xs uppercase tracking-[0.2em] text-slate-400">{block.language}</div>
                      <pre className="overflow-x-auto p-4 text-sm text-emerald-300">{block.code}</pre>
                    </div>
                  );
                }

                return (
                  <div key={index} className="overflow-hidden rounded-3xl border border-slate-200/70 dark:border-slate-700">
                    <table className="min-w-full text-sm">
                      <thead className="bg-slate-100 dark:bg-slate-800">
                        <tr>
                          {block.headers.map((header) => (
                            <th key={header.en} className="px-4 py-3 text-start text-slate-600 dark:text-slate-200">
                              {localized(header, language)}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {block.rows.map((row, rowIndex) => (
                          <tr key={rowIndex} className="border-t border-slate-200 dark:border-slate-700">
                            {row.map((cell) => (
                              <td key={cell.en} className="px-4 py-3 text-slate-600 dark:text-slate-200">
                                {localized(cell, language)}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                );
              })}
            </div>
          </>
        ) : null}
      </ShellCard>
    </div>
  );
}

function ReportsPage(props: SharedPageProps) {
  const { tasks, services, analytics, aiInsights, teamMembers, departments, language, text, yearArchives, setYearArchives } = props;
  const isArabic = language === "ar";

  const currentYear = new Date().getFullYear();
  const availableYears = useMemo(() => {
    const taskYears = tasks.map((t) => new Date(t.startDate || t.createdDate || "").getFullYear()).filter(Boolean);
    const archiveYears = yearArchives.map((a) => a.year);
    const all = new Set([currentYear, ...taskYears, ...archiveYears]);
    return Array.from(all).sort((a, b) => b - a);
  }, [tasks, yearArchives, currentYear]);

  const [selectedYear, setSelectedYear] = useState(currentYear);
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [compareMode, setCompareMode] = useState(false);
  const [compareYear, setCompareYear] = useState(currentYear - 1);

  const archivedYear = yearArchives.find((a) => a.year === selectedYear);
  const isCurrentYear = selectedYear === currentYear;
  const isLocked = archivedYear?.locked ?? false;

  // Filter tasks by selected year and optional date range
  const yearTasks = useMemo(() => {
    return tasks.filter((t) => {
      const d = new Date(t.startDate || t.createdDate || "");
      if (d.getFullYear() !== selectedYear) return false;
      if (dateFrom && d < new Date(dateFrom)) return false;
      if (dateTo && d > new Date(dateTo + "T23:59:59")) return false;
      return true;
    });
  }, [tasks, selectedYear, dateFrom, dateTo]);

  const completedTasks = yearTasks.filter((t) => t.status === "Completed");
  const inProgressTasks = yearTasks.filter((t) => t.status === "In Progress");
  const delayedTasks = yearTasks.filter((t) => t.status === "Delayed");
  const criticalTasks = yearTasks.filter((t) => t.priority === "Critical");
  const completionRate = yearTasks.length ? Math.round((completedTasks.length / yearTasks.length) * 100) : 0;
  const productivityRate = yearTasks.length ? Math.round(yearTasks.reduce((sum, t) => sum + (t.productivityScore || 0), 0) / yearTasks.length) : 0;

  const topTechnicians = teamMembers
    .filter((m) => m.enabled)
    .map((m) => ({
      name: localized(m.name, language),
      count: yearTasks.filter((t) => t.assignee === m.name.ar || t.assignee === m.name.en || t.technicianName === m.name.ar).length,
    }))
    .filter((t) => t.count > 0)
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  const topDepartments = departments
    .filter((d) => d.enabled)
    .map((d) => ({
      name: localized(d.name, language),
      count: yearTasks.filter((t) => t.department === d.id || t.location?.ar === d.name.ar).length,
    }))
    .filter((d) => d.count > 0)
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  const topServices = services
    .filter((s) => s.enabled)
    .map((s) => ({
      name: localized(s.name, language),
      count: yearTasks.filter((t) => t.serviceId === s.id).length,
    }))
    .filter((s) => s.count > 0)
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  // Compare year data
  const compareYearTasks = useMemo(() => {
    if (!compareMode) return [];
    return tasks.filter((t) => new Date(t.startDate || t.createdDate || "").getFullYear() === compareYear);
  }, [tasks, compareMode, compareYear]);

  const compareStats = useMemo(() => {
    if (!compareMode || compareYearTasks.length === 0) return null;
    const c = compareYearTasks.filter((t) => t.status === "Completed");
    return {
      totalTasks: compareYearTasks.length,
      completedTasks: c.length,
      completionRate: Math.round((c.length / compareYearTasks.length) * 100),
      productivityRate: Math.round(compareYearTasks.reduce((sum, t) => sum + (t.productivityScore || 0), 0) / compareYearTasks.length),
      delayedTasks: compareYearTasks.filter((t) => t.status === "Delayed").length,
      criticalTasks: compareYearTasks.filter((t) => t.priority === "Critical").length,
    };
  }, [compareMode, compareYearTasks]);

  const handleCloseYear = () => {
    if (!window.confirm(isArabic ? `هل أنت متأكد من إغلاق سنة ${selectedYear}؟ لن يمكن التعديل على تقارير هذه السنة بعد الإغلاق.` : `Are you sure you want to close year ${selectedYear}? Reports for this year will become read-only.`)) return;
    const archive: YearArchive = {
      year: selectedYear,
      closedAt: new Date().toISOString(),
      closedBy: "Admin",
      locked: true,
      stats: {
        totalTasks: yearTasks.length,
        completedTasks: completedTasks.length,
        inProgressTasks: inProgressTasks.length,
        delayedTasks: delayedTasks.length,
        criticalTasks: criticalTasks.length,
        completionRate,
        productivityRate,
        topServices,
        topDepartments,
        topTechnicians,
      },
    };
    setYearArchives((prev: YearArchive[]) => {
      const filtered = prev.filter((a) => a.year !== selectedYear);
      return [...filtered, archive];
    });
    alert(isArabic ? `✅ تم إغلاق سنة ${selectedYear} بنجاح وأرشفة التقارير.` : `✅ Year ${selectedYear} closed successfully and reports archived.`);
  };

  const exportCsv = (filename: string, rows: string[][]) => {
    const bom = "\uFEFF";
    const csv = rows.map((row) => row.map((cell) => `"${cell.replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([bom + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
  };

  const exportTasksCsv = () => {
    const header = [isArabic ? "رقم المهمة" : "Task ID", isArabic ? "العنوان" : "Title", isArabic ? "الخدمة" : "Service", isArabic ? "الأولوية" : "Priority", isArabic ? "الحالة" : "Status", isArabic ? "الفني" : "Technician", isArabic ? "الجهة" : "Department"];
    const rows = tasks.map((t) => [t.id, localized(t.title, language), localized(t.service, language), localized(priorityLabels[t.priority], language), localized(statusLabels[t.status], language), t.assignee, t.department || localized(t.location, language)]);
    exportCsv("tasks-report.csv", [header, ...rows]);
  };

  const exportTasksJson = () => downloadAsJson("tasks-report.json", tasks);

  const printReport = (title: string) => {
    const w = window.open("", "_blank", "width=900,height=700");
    if (!w) return;
    const dir = isArabic ? "rtl" : "ltr";
    const statsHtml = [
      [isArabic ? "إجمالي المهام" : "Total Tasks", `${analytics.totalTasks}`],
      [isArabic ? "مكتملة" : "Completed", `${analytics.completedTasks}`],
      [isArabic ? "قيد التنفيذ" : "In Progress", `${analytics.inProgressTasks}`],
      [isArabic ? "متأخرة" : "Delayed", `${analytics.delayedTasks}`],
      [isArabic ? "معدل الإنجاز" : "Completion", `${analytics.completionRate}%`],
      [isArabic ? "الإنتاجية" : "Productivity", `${analytics.productivityRate}%`],
    ].map(([l, v]) => `<div style="border:1px solid #e2e8f0;border-radius:16px;padding:12px;text-align:center;background:#f8fafc"><div style="color:#64748b;font-size:12px">${l}</div><div style="font-size:24px;font-weight:900;margin-top:4px">${v}</div></div>`).join("");
    w.document.write(`<!doctype html><html lang="${language}" dir="${dir}"><head><meta charset="UTF-8"><title>${title}</title><style>@page{margin:18mm}*{box-sizing:border-box}body{margin:0;font-family:-apple-system,sans-serif;color:#0f172a;line-height:1.7}h1{font-size:24px;border-bottom:3px solid #0f8a5f;padding-bottom:12px}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:20px 0}</style></head><body><h1>${title}</h1><div class="grid">${statsHtml}</div><script>window.onload=()=>{window.focus();window.print()}</script></body></html>`);
    w.document.close();
  };

  void 0; // aiSuggestions moved below noData

  const ExportMenu = ({ onPdf, onExcel, onCsv }: { onPdf: () => void; onExcel: () => void; onCsv: () => void }) => {
    const [isOpen, setIsOpen] = useState(false);
    return (
      <div className="relative inline-block text-left">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="inline-flex items-center gap-2 rounded-2xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white shadow-lg shadow-slate-900/20 transition hover:bg-slate-800 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100"
        >
          <Download className="h-4 w-4" />
          {isArabic ? "تصدير" : "Export"}
          <ChevronDown className="h-4 w-4" />
        </button>
        {isOpen && (
          <div className={cn("absolute z-50 mt-2 w-48 origin-top-right rounded-2xl border border-slate-200 bg-white p-2 shadow-xl ring-1 ring-black ring-opacity-5 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:ring-white dark:ring-opacity-5", isArabic ? "right-0" : "left-0")}>
            <button onClick={() => { onPdf(); setIsOpen(false); }} className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-700">
              <FileText className="h-4 w-4 text-red-500" /> PDF
            </button>
            <button onClick={() => { onExcel(); setIsOpen(false); }} className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-700">
              <FileSpreadsheet className="h-4 w-4 text-emerald-500" /> Excel
            </button>
            <button onClick={() => { onCsv(); setIsOpen(false); }} className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-700">
              <Table className="h-4 w-4 text-blue-500" /> CSV
            </button>
          </div>
        )}
      </div>
    );
  };

  const noData = yearTasks.length === 0 && !archivedYear;
  const na = "—";
  const weekLabelKey = isArabic ? "dayAr" : "dayEn";
  const monthLabelKey = isArabic ? "labelAr" : "labelEn";

  const aiSuggestions = noData ? [] : [
    ...(analytics.weeklyTasks > 0 ? [{ ar: `إجمالي المهام هذا الأسبوع ${analytics.weeklyTasks} مهمة، معدل الإنجاز ${analytics.completionRate}%.`, en: `This week has ${analytics.weeklyTasks} tasks with a ${analytics.completionRate}% completion rate.` }] : []),
    ...(delayedTasks.length > 0 ? [{ ar: `يوجد ${delayedTasks.length} مهام متأخرة تحتاج متابعة فورية.`, en: `There are ${delayedTasks.length} delayed tasks requiring immediate attention.` }] : []),
    ...(criticalTasks.length > 0 ? [{ ar: `${criticalTasks.length} مهام ذات أولوية حرجة — يجب التصعيد.`, en: `${criticalTasks.length} critical priority tasks — escalation recommended.` }] : []),
    ...(topServices[0]?.count ? [{ ar: `الخدمة الأكثر طلبًا: ${topServices[0].name} (${topServices[0].count} تذكرة).`, en: `Most requested service: ${topServices[0].name} (${topServices[0].count} tickets).` }] : []),
  ];

  const reportCards = [
    {
      icon: "📅",
      title: { ar: "التقرير اليومي", en: "Daily Report" },
      subtitle: { ar: "نظرة سريعة على أداء اليوم والمهام الحرجة.", en: "A quick overview of today's performance and critical tasks." },
      stats: noData ? [] : [
        { label: isArabic ? "إجمالي المهام" : "Total Tasks", value: `${yearTasks.length}` },
        { label: isArabic ? "المهام المكتملة" : "Completed", value: `${completedTasks.length}` },
        { label: isArabic ? "قيد التنفيذ" : "In Progress", value: `${inProgressTasks.length}` },
        { label: isArabic ? "المتأخرة" : "Overdue", value: `${delayedTasks.length}` },
        { label: isArabic ? "الحرجة" : "Critical", value: `${criticalTasks.length}` },
        { label: isArabic ? "معدل الإنجاز" : "Completion Rate", value: `${completionRate}%` },
        { label: isArabic ? "معدل الإنتاجية" : "Productivity Rate", value: `${productivityRate}%` },
      ],
      accent: "from-emerald-500 to-teal-500",
    },
    {
      icon: "📆",
      title: { ar: "التقرير الأسبوعي", en: "Weekly Report" },
      subtitle: { ar: "مؤشرات الإنجاز خلال الأسبوع الحالي.", en: "Completion indicators for the current week." },
      stats: noData ? [] : [
        { label: isArabic ? "معدل الإنجاز" : "Completion Rate", value: `${completionRate}%` },
        { label: isArabic ? "معدل الإنتاجية" : "Productivity Rate", value: `${productivityRate}%` },
        { label: isArabic ? "المهام المتأخرة" : "Overdue Tasks", value: `${delayedTasks.length}` },
        { label: isArabic ? "الخدمة الأكثر طلباً" : "Most Requested Service", value: topServices[0]?.count ? topServices[0].name : na },
        { label: isArabic ? "الفني الأكثر إنجازاً" : "Top Technician", value: topTechnicians[0]?.count ? topTechnicians[0].name : na },
        { label: isArabic ? "القسم الأكثر طلبات" : "Most Requested Department", value: topDepartments[0]?.count ? topDepartments[0].name : na },
      ],
      accent: "from-blue-500 to-indigo-500",
    },
    {
      icon: "📅",
      title: { ar: "التقرير الشهري", en: "Monthly Report" },
      subtitle: { ar: "تحليل شامل للخدمات الأكثر استخداماً والإنتاجية.", en: "Broad analysis of most-used services and productivity." },
      stats: noData ? [] : [
        { label: isArabic ? "معدل الإنجاز" : "Completion Rate", value: `${completionRate}%` },
        { label: isArabic ? "معدل الإنتاجية" : "Productivity Rate", value: `${productivityRate}%` },
        { label: isArabic ? "المهام المتأخرة" : "Overdue Tasks", value: `${delayedTasks.length}` },
        { label: isArabic ? "إجمالي التذاكر" : "Total Tickets", value: `${yearTasks.length}` },
        { label: isArabic ? "الخدمات المنفذة" : "Completed Services", value: `${completedTasks.length}` },
        { label: isArabic ? "متوسط زمن الإنجاز" : "Avg Resolution Time", value: analytics.averageCompletionTime },
      ],
      accent: "from-violet-500 to-purple-500",
    },
    {
      icon: "📈",
      title: { ar: "التقرير السنوي", en: "Annual Report" },
      subtitle: { ar: "مراجعة استراتيجية للأداء والجاهزية المؤسسية.", en: "A strategic review of performance and enterprise readiness." },
      stats: noData ? [] : [
        { label: isArabic ? "إجمالي التذاكر السنوية" : "Total Annual Tickets", value: `${yearTasks.length}` },
        { label: isArabic ? "معدل الإنجاز السنوي" : "Annual Completion", value: `${completionRate}%` },
        { label: isArabic ? "معدل الإنتاجية السنوي" : "Annual Productivity", value: `${productivityRate}%` },
        { label: isArabic ? "المهام الحرجة" : "Critical Tasks", value: `${criticalTasks.length}` },
        { label: isArabic ? "المهام المتأخرة" : "Overdue Tasks", value: `${delayedTasks.length}` },
      ],
      accent: "from-amber-500 to-orange-500",
    },
  ];

  return (
    <div className="space-y-4">
      <ShellCard className="p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-300">{isArabic ? "إدارة التقارير" : "Reports Module"}</p>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">
              {text.reports} — {selectedYear}
              {isLocked && <span className="ms-2 rounded-full bg-amber-500/10 px-3 py-1 text-xs font-bold text-amber-700 dark:text-amber-300">🔒 {isArabic ? "مؤرشف" : "Archived"}</span>}
            </h2>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <select value={selectedYear} onChange={(e) => setSelectedYear(Number(e.target.value))} className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold dark:border-slate-700 dark:bg-slate-900">
              {availableYears.map((y) => (
                <option key={y} value={y}>{y} {yearArchives.find(a => a.year === y)?.locked ? (isArabic ? "🔒" : "🔒") : ""}</option>
              ))}
            </select>
            <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="rounded-2xl border border-slate-200 bg-white px-3 py-3 text-sm dark:border-slate-700 dark:bg-slate-900" placeholder={isArabic ? "من تاريخ" : "From"} />
            <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="rounded-2xl border border-slate-200 bg-white px-3 py-3 text-sm dark:border-slate-700 dark:bg-slate-900" placeholder={isArabic ? "إلى تاريخ" : "To"} />
            <label className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold dark:border-slate-700 dark:bg-slate-900">
              <input type="checkbox" checked={compareMode} onChange={(e) => setCompareMode(e.target.checked)} className="h-4 w-4 accent-emerald-600" />
              {isArabic ? "مقارنة" : "Compare"}
            </label>
            {compareMode && (
              <select value={compareYear} onChange={(e) => setCompareYear(Number(e.target.value))} className="rounded-2xl border border-slate-200 bg-white px-3 py-3 text-sm dark:border-slate-700 dark:bg-slate-900">
                {availableYears.filter(y => y !== selectedYear).map((y) => (
                  <option key={y} value={y}>{y}</option>
                ))}
              </select>
            )}
            <button type="button" onClick={exportTasksCsv} className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold shadow-sm dark:border-slate-700 dark:bg-slate-900">
              <Table className="h-4 w-4" /> CSV
            </button>
            <button type="button" onClick={exportTasksJson} className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-[var(--primary-blue)] px-5 py-3 text-sm font-bold text-white">
              <FileSpreadsheet className="h-4 w-4" /> {text.export}
            </button>
            {isCurrentYear && !isLocked && (
              <button type="button" onClick={handleCloseYear} className="inline-flex items-center gap-2 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-bold text-amber-700 dark:border-amber-500/30 dark:bg-amber-900/20 dark:text-amber-300">
                🔒 {isArabic ? "إغلاق السنة" : "Close Year"}
              </button>
            )}
          </div>
        </div>
      </ShellCard>

      {compareMode && compareStats && (
        <ShellCard className="p-5">
          <SectionHeader title={isArabic ? `مقارنة ${selectedYear} مع ${compareYear}` : `Compare ${selectedYear} vs ${compareYear}`} actionLabel="" />
          <div className="mt-4 overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200/80 text-slate-500 dark:border-slate-700">
                  <th className="px-4 py-3 text-start">{isArabic ? "المؤشر" : "Metric"}</th>
                  <th className="px-4 py-3 text-center">{selectedYear}</th>
                  <th className="px-4 py-3 text-center">{compareYear}</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { label: isArabic ? "إجمالي المهام" : "Total Tasks", a: yearTasks.length, b: compareStats.totalTasks },
                  { label: isArabic ? "المكتملة" : "Completed", a: completedTasks.length, b: compareStats.completedTasks },
                  { label: isArabic ? "معدل الإنجاز" : "Completion Rate", a: `${completionRate}%`, b: `${compareStats.completionRate}%` },
                  { label: isArabic ? "الإنتاجية" : "Productivity", a: `${productivityRate}%`, b: `${compareStats.productivityRate}%` },
                  { label: isArabic ? "المتأخرة" : "Overdue", a: delayedTasks.length, b: compareStats.delayedTasks },
                  { label: isArabic ? "الحرجة" : "Critical", a: criticalTasks.length, b: compareStats.criticalTasks },
                ].map((row) => (
                  <tr key={row.label} className="border-b border-slate-100 dark:border-slate-800">
                    <td className="px-4 py-3 font-semibold text-slate-900 dark:text-white">{row.label}</td>
                    <td className="px-4 py-3 text-center text-lg font-black text-slate-900 dark:text-white">{row.a}</td>
                    <td className="px-4 py-3 text-center text-lg font-black text-slate-500 dark:text-slate-300">{row.b}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </ShellCard>
      )}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {reportCards.map((card) => (
          <ShellCard key={card.title.en} className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl">{card.icon}</div>
                <div className="mt-2 text-lg font-black text-slate-900 dark:text-white">{localized(card.title, language)}</div>
              </div>
              <div className={cn("h-12 w-12 rounded-3xl bg-gradient-to-br p-3 text-white", card.accent)}>
                <FileText className="h-6 w-6" />
              </div>
            </div>
            <p className="mt-3 text-sm text-slate-500 dark:text-slate-300">{localized(card.subtitle, language)}</p>
            {card.stats.length > 0 ? (
              <div className="mt-4 grid grid-cols-2 gap-2">
                {card.stats.map((stat) => (
                  <div key={stat.label} className="rounded-2xl border border-slate-200/70 bg-white/80 p-3 text-center dark:border-slate-700 dark:bg-slate-800/80">
                    <div className="text-xs text-slate-500 dark:text-slate-400">{stat.label}</div>
                    <div className="mt-1 text-lg font-black text-slate-900 dark:text-white">{stat.value}</div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="mt-6 flex flex-col items-center gap-2 py-6 text-center">
                <BarChart3 className="h-10 w-10 text-slate-300 dark:text-slate-600" />
                <p className="text-sm font-semibold text-slate-400 dark:text-slate-500">{isArabic ? "لا توجد بيانات لعرضها حالياً" : "No reports available yet"}</p>
              </div>
            )}
            <div className="mt-5 flex flex-wrap gap-2">
              <ExportMenu onPdf={() => printReport(localized(card.title, language))} onExcel={exportTasksJson} onCsv={exportTasksCsv} />
              <button type="button" onClick={() => printReport(localized(card.title, language))} className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-bold text-slate-700 shadow-sm transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800">
                <Printer className="h-4 w-4" /> {isArabic ? "طباعة" : "Print"}
              </button>
            </div>
          </ShellCard>
        ))}
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <ChartCard title={text.weeklyPerformance} isEmpty={weeklyPerformanceData.length === 0}>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={weeklyPerformanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#CBD5E1" opacity={0.35} />
              <XAxis dataKey={weekLabelKey} stroke="#64748B" />
              <YAxis stroke="#64748B" />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="completed" name={isArabic ? "مكتملة" : "Completed"} stroke="#22C55E" strokeWidth={3} />
              <Line type="monotone" dataKey="productivity" name={isArabic ? "الإنتاجية" : "Productivity"} stroke="#2563EB" strokeWidth={3} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title={text.monthlyPerformance} isEmpty={monthlyPerformanceData.length === 0}>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={monthlyPerformanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#CBD5E1" opacity={0.35} />
              <XAxis dataKey={monthLabelKey} stroke="#64748B" />
              <YAxis stroke="#64748B" />
              <Tooltip />
              <Bar dataKey="value" name={isArabic ? "الأداء" : "Performance"} fill="#0F8A5F" radius={[10, 10, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <ChartCard title={text.priorityDistribution} isEmpty={analytics.totalTasks === 0}>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={analytics.priorityDistribution.map((e) => ({ ...e, label: localized(priorityLabels[e.name as Priority], language) }))} dataKey="value" nameKey="label" innerRadius={60} outerRadius={96} paddingAngle={4}>
                {analytics.priorityDistribution.map((item) => <Cell key={item.name} fill={item.fill} />)}
              </Pie>
              <Tooltip /><Legend />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title={text.statusDistribution} isEmpty={analytics.totalTasks === 0}>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={analytics.statusDistribution.map((e) => ({ ...e, label: localized(statusLabels[e.name as TaskStatus], language) }))} dataKey="value" nameKey="label" innerRadius={60} outerRadius={96} paddingAngle={4}>
                {analytics.statusDistribution.map((item) => <Cell key={item.name} fill={item.fill} />)}
              </Pie>
              <Tooltip /><Legend />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title={text.productivityAnalysis} isEmpty={productivityAnalysisData.length === 0}>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={productivityAnalysisData}>
              <defs><linearGradient id="rptArea" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#2563EB" stopOpacity={0.4} /><stop offset="95%" stopColor="#2563EB" stopOpacity={0.02} /></linearGradient></defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#CBD5E1" opacity={0.35} />
              <XAxis dataKey={isArabic ? "labelAr" : "labelEn"} stroke="#64748B" />
              <YAxis stroke="#64748B" />
              <Tooltip />
              <Area type="monotone" dataKey="value" stroke="#2563EB" fill="url(#rptArea)" strokeWidth={3} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <ShellCard className="p-5">
          <SectionHeader title={isArabic ? "الخدمات الأكثر استخداماً" : "Top Services"} actionLabel={noData ? "" : `${topServices.filter(s => s.count > 0).length}`} />
          <div className="mt-4 space-y-3">
            {topServices.filter(s => s.count > 0).length > 0 ? topServices.filter(s => s.count > 0).map((s, i) => (
              <div key={s.name} className="flex items-center justify-between rounded-2xl border border-slate-200/70 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-800/80">
                <div className="flex items-center gap-3">
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500/10 text-sm font-black text-emerald-700 dark:text-emerald-300">{i + 1}</span>
                  <span className="font-semibold text-slate-900 dark:text-white">{s.name}</span>
                </div>
                <span className="text-lg font-black text-slate-900 dark:text-white">{s.count}</span>
              </div>
            )) : (
              <div className="flex flex-col items-center gap-2 py-8 text-center">
                <BarChart3 className="h-8 w-8 text-slate-300 dark:text-slate-600" />
                <p className="text-sm text-slate-400 dark:text-slate-500">{isArabic ? "لا توجد بيانات متاحة" : "No data available"}</p>
              </div>
            )}
          </div>
        </ShellCard>

        <ShellCard className="p-5">
          <SectionHeader title={isArabic ? "الجهات الأكثر طلباً" : "Top Departments"} actionLabel={noData ? "" : `${topDepartments.filter(d => d.count > 0).length}`} />
          <div className="mt-4 space-y-3">
            {topDepartments.filter(d => d.count > 0).length > 0 ? topDepartments.filter(d => d.count > 0).map((d, i) => (
              <div key={d.name} className="flex items-center justify-between rounded-2xl border border-slate-200/70 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-800/80">
                <div className="flex items-center gap-3">
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-500/10 text-sm font-black text-blue-700 dark:text-blue-300">{i + 1}</span>
                  <span className="font-semibold text-slate-900 dark:text-white">{d.name}</span>
                </div>
                <span className="text-lg font-black text-slate-900 dark:text-white">{d.count}</span>
              </div>
            )) : (
              <div className="flex flex-col items-center gap-2 py-8 text-center">
                <BarChart3 className="h-8 w-8 text-slate-300 dark:text-slate-600" />
                <p className="text-sm text-slate-400 dark:text-slate-500">{isArabic ? "لا توجد بيانات متاحة" : "No data available"}</p>
              </div>
            )}
          </div>
        </ShellCard>

        <ShellCard className="p-5">
          <SectionHeader title={isArabic ? "الفنيين الأكثر إنجازاً" : "Top Technicians"} actionLabel={noData ? "" : `${topTechnicians.filter(t => t.count > 0).length}`} />
          <div className="mt-4 space-y-3">
            {topTechnicians.filter(t => t.count > 0).length > 0 ? topTechnicians.filter(t => t.count > 0).map((t, i) => (
              <div key={t.name} className="flex items-center justify-between rounded-2xl border border-slate-200/70 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-800/80">
                <div className="flex items-center gap-3">
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-violet-500/10 text-sm font-black text-violet-700 dark:text-violet-300">{i + 1}</span>
                  <span className="font-semibold text-slate-900 dark:text-white">{t.name}</span>
                </div>
                <span className="text-lg font-black text-slate-900 dark:text-white">{t.count}</span>
              </div>
            )) : (
              <div className="flex flex-col items-center gap-2 py-8 text-center">
                <BarChart3 className="h-8 w-8 text-slate-300 dark:text-slate-600" />
                <p className="text-sm text-slate-400 dark:text-slate-500">{isArabic ? "لا توجد بيانات متاحة" : "No data available"}</p>
              </div>
            )}
          </div>
        </ShellCard>
      </div>

      <ShellCard className="p-5">
        <div className="flex items-center gap-3">
          <Bot className="h-11 w-11 rounded-3xl bg-emerald-500/10 p-2.5 text-emerald-600 dark:text-emerald-300" />
          <div>
            <div className="text-lg font-black text-slate-900 dark:text-white">{isArabic ? "تقارير الذكاء الاصطناعي" : "AI Reports"}</div>
            <p className="text-sm text-slate-500 dark:text-slate-300">{isArabic ? "تحليل تلقائي وتوقعات ذكية للأداء" : "Auto analysis and smart performance predictions"}</p>
          </div>
        </div>
        {aiSuggestions.length > 0 ? (
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {aiSuggestions.map((s) => (
              <div key={s.en} className="rounded-3xl border border-emerald-500/10 bg-emerald-500/5 p-4">
                <div className="flex items-start gap-3">
                  <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600 dark:text-emerald-300" />
                  <p className="text-sm text-slate-700 dark:text-slate-200">{localized(s, language)}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="mt-6 flex flex-col items-center gap-3 py-8 text-center">
            <Bot className="h-12 w-12 text-slate-300 dark:text-slate-600" />
            <p className="text-sm font-semibold text-slate-400 dark:text-slate-500">{isArabic ? "لا توجد بيانات لعرضها حالياً" : "No reports available yet"}</p>
            <p className="text-xs text-slate-400 dark:text-slate-500">{isArabic ? "أضف مهام أولاً لتتمكن من عرض التقارير الذكية" : "Add tasks first to view smart reports"}</p>
          </div>
        )}
        {noData ? null : (
          <div className="mt-4 rounded-3xl border border-blue-500/10 bg-blue-500/5 p-4">
            <div className="mb-2 text-sm font-bold text-blue-700 dark:text-blue-300">{isArabic ? "ملخص الأداء الذكي" : "Smart Performance Summary"}</div>
            <p className="text-sm text-slate-600 dark:text-slate-300">{localized(aiInsights.summary, language)}</p>
          </div>
        )}
      </ShellCard>

      <ChartCard title={isArabic ? "الأداء السنوي" : "Annual Performance"} isEmpty={yearHeatmapData.length === 0}>
        <ResponsiveContainer width="100%" height={320}>
          <BarChart data={yearHeatmapData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#CBD5E1" opacity={0.35} />
            <XAxis dataKey={isArabic ? "monthAr" : "monthEn"} stroke="#64748B" />
            <YAxis stroke="#64748B" />
            <Tooltip />
            <Bar dataKey="score" name={isArabic ? "الأداء" : "Score"} fill="#2563EB" radius={[10, 10, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  );
}

function NotificationsPage(props: SharedPageProps) {
  const { notifications, markNotificationRead, language, isArabic, text } = props;

  return (
    <div className="space-y-4">
      <ShellCard className="p-5">
        <SectionHeader title={text.notificationsCenter} actionLabel={`${notifications.length}`} />
        <div className="mt-4 grid gap-3">
          {notifications.map((notification) => (
            <button
              key={notification.id}
              type="button"
              onClick={() => markNotificationRead(notification.id)}
              className={cn(
                "flex items-start gap-4 rounded-3xl border p-4 text-start transition",
                notification.read
                  ? "border-slate-200/70 bg-white/75 dark:border-slate-700 dark:bg-slate-800/75"
                  : "border-emerald-500/20 bg-emerald-500/5",
              )}
            >
              <div className={cn("mt-1 h-3 w-3 rounded-full", getNotificationTypeColor(notification.type))} />
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-bold text-slate-900 dark:text-white">{localized(notification.title, language)}</span>
                  <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-600 dark:bg-slate-700 dark:text-slate-200">
                    {localized(channelLabels[notification.channel], language)}
                  </span>
                </div>
                <p className="mt-2 text-sm text-slate-500 dark:text-slate-300">{localized(notification.message, language)}</p>
              </div>
              <div className="text-xs text-slate-400">{notification.time}</div>
            </button>
          ))}
        </div>
      </ShellCard>

      <div className="grid gap-4 sm:grid-cols-3">
        {[
          { icon: BellRing, titleAr: "إشعارات النظام", titleEn: "System Notifications", value: 92 },
          { icon: Mail, titleAr: "إشعارات البريد", titleEn: "Email Notifications", value: 84 },
          { icon: AlarmClock, titleAr: "تذكيرات الجوال", titleEn: "Mobile Reminders", value: 76 },
        ].map((item) => {
          const StatIcon = item.icon;
          return (
            <ShellCard key={item.titleEn} className="p-5 text-center">
              <StatIcon className="mx-auto h-12 w-12 rounded-3xl bg-emerald-500/10 p-3 text-emerald-600 dark:text-emerald-300" />
              <div className="mt-3 text-lg font-black text-slate-900 dark:text-white">{isArabic ? item.titleAr : item.titleEn}</div>
              <div className="mt-2 text-4xl font-black text-slate-900 dark:text-white">{item.value}%</div>
            </ShellCard>
          );
        })}
      </div>
    </div>
  );
}

function TeamPage(props: SharedPageProps) {
  const { teamMembers, upsertTeamMember, departments, isArabic } = props;
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "enabled" | "disabled">("all");
  const [roleFilter, setRoleFilter] = useState<TeamRole | "all">("all");
  const [deptFilter, setDeptFilter] = useState<string>("all");
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);

  const [fNameAr, setFNameAr] = useState(""); const [fNameEn, setFNameEn] = useState(""); const [fCode, setFCode] = useState("");
  const [fEmail, setFEmail] = useState(""); const [fMobile, setFMobile] = useState("");
  const [fJobAr, setFJobAr] = useState(""); const [fJobEn, setFJobEn] = useState("");
  const [fDept, setFDept] = useState(departments[0]?.id || ""); const [fRole, setFRole] = useState<TeamRole>("technician");

  const [eNameAr, setENameAr] = useState(""); const [eNameEn, setENameEn] = useState(""); const [eCode, setECode] = useState("");
  const [eEmail, setEEmail] = useState(""); const [eMobile, setEMobile] = useState("");
  const [eJobAr, setEJobAr] = useState(""); const [eJobEn, setEJobEn] = useState("");
  const [eDept, setEDept] = useState(""); const [eRole, setERole] = useState<TeamRole>("technician");

  const filtered = teamMembers
    .filter((m) => {
      if (statusFilter === "enabled" && !m.enabled) return false;
      if (statusFilter === "disabled" && m.enabled) return false;
      if (roleFilter !== "all" && m.role !== roleFilter) return false;
      if (deptFilter !== "all" && m.departmentId !== deptFilter) return false;
      if (search.trim()) {
        const t = search.toLowerCase();
        return m.name.ar.includes(t) || m.name.en.toLowerCase().includes(t) || m.employeeCode.toLowerCase().includes(t) || m.email.toLowerCase().includes(t);
      }
      return true;
    });

  const resetForm = () => { setFNameAr(""); setFNameEn(""); setFCode(""); setFEmail(""); setFMobile(""); setFJobAr(""); setFJobEn(""); setFDept(departments[0]?.id || ""); setFRole("technician"); };

  const addMember = () => {
    if (!fNameAr.trim() || !fNameEn.trim()) return;
    const m: TeamMember = {
      id: `TM-${Math.floor(Math.random() * 9000 + 1000)}`,
      employeeCode: fCode || `EMP-${Math.floor(Math.random() * 9000 + 1000)}`,
      name: { ar: fNameAr, en: fNameEn }, email: fEmail, mobile: fMobile,
      jobTitle: { ar: fJobAr, en: fJobEn }, departmentId: fDept, role: fRole,
      photo: "", enabled: true, createdAt: new Date().toISOString(),
    };
    upsertTeamMember(m);
    resetForm(); setShowForm(false);
  };

  const startEdit = (m: TeamMember) => {
    setEditId(m.id); setENameAr(m.name.ar); setENameEn(m.name.en); setECode(m.employeeCode);
    setEEmail(m.email); setEMobile(m.mobile); setEJobAr(m.jobTitle.ar); setEJobEn(m.jobTitle.en);
    setEDept(m.departmentId); setERole(m.role);
  };

  const saveEdit = () => {
    const member = teamMembers.find(m => m.id === editId);
    if (member) {
      upsertTeamMember({
        ...member, name: { ar: eNameAr, en: eNameEn }, employeeCode: eCode,
        email: eEmail, mobile: eMobile, jobTitle: { ar: eJobAr, en: eJobEn },
        departmentId: eDept, role: eRole,
      });
      setEditId(null);
    }
  };

  const getDeptName = (id: string) => {
    const d = departments.find((dep) => dep.id === id);
    return d ? localized(d.name, isArabic ? "ar" : "en") : id;
  };

  return (
    <div className="space-y-4">
      <ShellCard className="p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-300">{isArabic ? "إدارة الفريق" : "Team Management"}</p>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">{isArabic ? "الفريق" : "Team"}</h2>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2 dark:border-slate-700 dark:bg-slate-900">
              <Search className="h-4 w-4 text-slate-400" />
              <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={isArabic ? "بحث..." : "Search..."} className="w-40 bg-transparent text-sm outline-none" />
            </div>
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as "all" | "enabled" | "disabled")} className="rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
              <option value="all">{isArabic ? "الكل" : "All"}</option>
              <option value="enabled">{isArabic ? "مفعّلة" : "Enabled"}</option>
              <option value="disabled">{isArabic ? "غير مفعّلة" : "Disabled"}</option>
            </select>
            <select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value as TeamRole | "all")} className="rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
              <option value="all">{isArabic ? "كل الصلاحيات" : "All Roles"}</option>
              {teamRoleOrder.map((r) => <option key={r} value={r}>{localized(teamRoleLabels[r], isArabic ? "ar" : "en")}</option>)}
            </select>
            <select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)} className="rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
              <option value="all">{isArabic ? "كل الأقسام" : "All Depts"}</option>
              {departments.filter((d) => d.enabled).map((d) => <option key={d.id} value={d.id}>{localized(d.name, isArabic ? "ar" : "en")}</option>)}
            </select>
            <button type="button" onClick={() => setShowForm(!showForm)} className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-[var(--primary-blue)] px-5 py-3 text-sm font-bold text-white">
              <Plus className="h-4 w-4" />
              {isArabic ? "إضافة عضو" : "Add Member"}
            </button>
          </div>
        </div>
      </ShellCard>

      {showForm && (
        <ShellCard className="p-5">
          <SectionHeader title={isArabic ? "إضافة عضو جديد" : "Add New Member"} actionLabel="" />
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <input value={fNameAr} onChange={(e) => setFNameAr(e.target.value)} placeholder={isArabic ? "الاسم بالعربية" : "Arabic Name"} className="field-input" />
            <input value={fNameEn} onChange={(e) => setFNameEn(e.target.value)} placeholder={isArabic ? "الاسم بالإنجليزية" : "English Name"} className="field-input" />
            <input value={fCode} onChange={(e) => setFCode(e.target.value)} placeholder={isArabic ? "رمز الموظف" : "Employee Code"} className="field-input" />
            <input value={fEmail} onChange={(e) => setFEmail(e.target.value)} type="email" placeholder={isArabic ? "البريد الإلكتروني" : "Email"} className="field-input" />
            <input value={fMobile} onChange={(e) => setFMobile(e.target.value)} placeholder={isArabic ? "رقم الجوال" : "Mobile"} className="field-input" />
            <input value={fJobAr} onChange={(e) => setFJobAr(e.target.value)} placeholder={isArabic ? "المسمى الوظيفي بالعربية" : "Job Title Arabic"} className="field-input" />
            <input value={fJobEn} onChange={(e) => setFJobEn(e.target.value)} placeholder={isArabic ? "المسمى الوظيفي بالإنجليزية" : "Job Title English"} className="field-input" />
            <select value={fDept} onChange={(e) => setFDept(e.target.value)} className="field-input">
              {departments.filter((d) => d.enabled).map((d) => <option key={d.id} value={d.id}>{localized(d.name, isArabic ? "ar" : "en")}</option>)}
            </select>
            <select value={fRole} onChange={(e) => setFRole(e.target.value as TeamRole)} className="field-input">
              {teamRoleOrder.map((r) => <option key={r} value={r}>{localized(teamRoleLabels[r], isArabic ? "ar" : "en")}</option>)}
            </select>
          </div>
          <div className="mt-4 flex gap-3">
            <button type="button" onClick={addMember} className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-[var(--primary-blue)] px-5 py-3 text-sm font-bold text-white">
              <Plus className="h-4 w-4" /> {isArabic ? "إضافة" : "Add"}
            </button>
            <button type="button" onClick={() => { resetForm(); setShowForm(false); }} className="rounded-2xl border border-slate-200 px-5 py-3 text-sm font-semibold dark:border-slate-700">
              {isArabic ? "إلغاء" : "Cancel"}
            </button>
          </div>
        </ShellCard>
      )}

      <ShellCard className="p-5">
        <SectionHeader title={isArabic ? "أعضاء الفريق" : "Team Members"} actionLabel={`${filtered.length}`} />
        <div className="mt-4 overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200/80 text-slate-500 dark:border-slate-700 dark:text-slate-300">
                <th className="px-3 py-3 text-start">#</th>
                <th className="px-3 py-3 text-start">{isArabic ? "الاسم بالعربية" : "Arabic Name"}</th>
                <th className="px-3 py-3 text-start">{isArabic ? "الاسم بالإنجليزية" : "English Name"}</th>
                <th className="px-3 py-3 text-start">{isArabic ? "رمز الموظف" : "Code"}</th>
                <th className="px-3 py-3 text-start">{isArabic ? "القسم" : "Department"}</th>
                <th className="px-3 py-3 text-start">{isArabic ? "المسمى" : "Job Title"}</th>
                <th className="px-3 py-3 text-start">{isArabic ? "الصلاحية" : "Role"}</th>
                <th className="px-3 py-3 text-start">{isArabic ? "الحالة" : "Status"}</th>
                <th className="px-3 py-3 text-start">{isArabic ? "الإجراءات" : "Actions"}</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((m, i) => (
                <tr key={m.id} className="border-b border-slate-100 last:border-none dark:border-slate-800">
                  <td className="px-3 py-4 font-bold text-slate-500 dark:text-slate-400">{i + 1}</td>
                  <td className="px-3 py-4">
                    {editId === m.id ? <input value={eNameAr} onChange={(e) => setENameAr(e.target.value)} className="field-input py-2" /> : <span className="font-semibold text-slate-900 dark:text-white">{m.name.ar}</span>}
                  </td>
                  <td className="px-3 py-4">
                    {editId === m.id ? <input value={eNameEn} onChange={(e) => setENameEn(e.target.value)} className="field-input py-2" /> : <span className="text-slate-600 dark:text-slate-300">{m.name.en}</span>}
                  </td>
                  <td className="px-3 py-4">
                    {editId === m.id ? <input value={eCode} onChange={(e) => setECode(e.target.value)} className="field-input w-28 py-2" /> : <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-600 dark:bg-slate-700 dark:text-slate-200">{m.employeeCode}</span>}
                  </td>
                  <td className="px-3 py-4 text-sm text-slate-600 dark:text-slate-300">
                    {editId === m.id ? (
                      <select value={eDept} onChange={(e) => setEDept(e.target.value)} className="field-input py-2">
                        {departments.filter((d) => d.enabled).map((d) => <option key={d.id} value={d.id}>{localized(d.name, isArabic ? "ar" : "en")}</option>)}
                      </select>
                    ) : getDeptName(m.departmentId)}
                  </td>
                  <td className="px-3 py-4 text-sm text-slate-600 dark:text-slate-300">
                    {editId === m.id ? (
                      <div className="space-y-1">
                        <input value={eJobAr} onChange={(e) => setEJobAr(e.target.value)} className="field-input py-1 text-xs" placeholder="عربي" />
                        <input value={eJobEn} onChange={(e) => setEJobEn(e.target.value)} className="field-input py-1 text-xs" placeholder="English" />
                      </div>
                    ) : localized(m.jobTitle, isArabic ? "ar" : "en")}
                  </td>
                  <td className="px-3 py-4">
                    {editId === m.id ? (
                      <select value={eRole} onChange={(e) => setERole(e.target.value as TeamRole)} className="field-input py-2">
                        {teamRoleOrder.map((r) => <option key={r} value={r}>{localized(teamRoleLabels[r], isArabic ? "ar" : "en")}</option>)}
                      </select>
                    ) : (
                      <span className="rounded-full bg-blue-500/10 px-3 py-1 text-xs font-bold text-blue-700 dark:text-blue-300">{localized(teamRoleLabels[m.role], isArabic ? "ar" : "en")}</span>
                    )}
                  </td>
                  <td className="px-3 py-4">
                    <button type="button" onClick={() => upsertTeamMember({ ...m, enabled: !m.enabled })} className={cn("rounded-full px-3 py-1 text-xs font-bold", m.enabled ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300" : "bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300")}>
                      {m.enabled ? (isArabic ? "مفعّل" : "Enabled") : isArabic ? "غير مفعّل" : "Disabled"}
                    </button>
                  </td>
                  <td className="px-3 py-4">
                    <div className="flex flex-wrap gap-1.5">
                      {editId === m.id ? (
                        <>
                          <ActionIconButton label={isArabic ? "حفظ" : "Save"} rounded onClick={saveEdit}><Check className="h-4 w-4" /></ActionIconButton>
                          <ActionIconButton label={isArabic ? "إلغاء" : "Cancel"} rounded onClick={() => setEditId(null)}><X className="h-4 w-4" /></ActionIconButton>
                        </>
                      ) : (
                        <>
                          <ActionIconButton label={isArabic ? "تعديل" : "Edit"} rounded onClick={() => startEdit(m)}><Pencil className="h-4 w-4" /></ActionIconButton>
                          <ActionIconButton label={isArabic ? "حذف" : "Delete"} rounded tone="danger" onClick={() => setDeleteConfirm(m.id)}><Trash2 className="h-4 w-4" /></ActionIconButton>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </ShellCard>

      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm">
          <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-md rounded-[2rem] border border-white/60 bg-white p-6 shadow-2xl dark:border-slate-700 dark:bg-slate-900">
            <div className="text-center">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-rose-500/10"><Trash2 className="h-8 w-8 text-rose-500" /></div>
              <h3 className="mt-4 text-xl font-black text-slate-900 dark:text-white">{isArabic ? "هل أنت متأكد من حذف هذا العضو؟" : "Are you sure you want to delete this member?"}</h3>
              <div className="mt-6 flex justify-center gap-3">
                <button type="button" onClick={() => { if (deleteConfirm) { props.deleteTeamMember(deleteConfirm); } setDeleteConfirm(null); }} className="inline-flex items-center gap-2 rounded-2xl bg-rose-600 px-5 py-3 text-sm font-bold text-white"><Trash2 className="h-4 w-4" />{isArabic ? "حذف" : "Delete"}</button>
                <button type="button" onClick={() => setDeleteConfirm(null)} className="rounded-2xl border border-slate-200 px-5 py-3 text-sm font-semibold dark:border-slate-700">{isArabic ? "إلغاء" : "Cancel"}</button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}

function SettingsPage({
  settings,
  setSettings,
  departments,
  setDepartments,
  text,
  isArabic,
}: {
  settings: AppSettings;
  setSettings: React.Dispatch<React.SetStateAction<AppSettings>>;
  departments: Department[];
  setDepartments: React.Dispatch<React.SetStateAction<Department[]>>;
  text: (typeof uiText)[Language];
  isArabic: boolean;
}) {
  const [newDepartment, setNewDepartment] = useState("");
  const form = useForm<SettingsFormValues>({
    resolver: zodResolver(settingsFormSchema),
    values: {
      systemNameAr: settings.systemName.ar,
      systemNameEn: settings.systemName.en,
      universityNameAr: settings.universityName.ar,
      universityNameEn: settings.universityName.en,
      timezone: settings.timezone,
      language: settings.language,
      themeMode: settings.themeMode,
      primaryGreen: settings.primaryGreen,
      primaryBlue: settings.primaryBlue,
      openAiModel: settings.openAiModel,
      googleSheetId: settings.googleSheetId,
      googleAppsScriptUrl: settings.googleAppsScriptUrl || "",
      supabaseUrl: settings.supabaseUrl,
    },
  });

  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<"connected" | "disconnected" | "checking">(
    settings.googleAppsScriptUrl && settings.googleSheetId ? "connected" : "disconnected"
  );

  const testConnection = async () => {
    const url = form.getValues("googleAppsScriptUrl");
    const sheetId = form.getValues("googleSheetId");
    
    if (!url || !sheetId) {
      alert(isArabic ? "يرجى إدخال رابط API ومعرف الجدول أولاً." : "Please enter API URL and Spreadsheet ID first.");
      return;
    }

    setIsTestingConnection(true);
    setConnectionStatus("checking");
    
    try {
      // Real communication attempt
      await fetch(url, {
        method: "POST",
        mode: "no-cors",
        body: JSON.stringify({ action: "ping", spreadsheetId: sheetId }),
      });
      
      setConnectionStatus("connected");
      alert(isArabic ? "تم الاتصال بنجاح!" : "Connected successfully!");
    } catch (error) {
      setConnectionStatus("disconnected");
      alert(isArabic ? "فشل الاتصال: " + error : "Connection failed: " + error);
    } finally {
      setIsTestingConnection(false);
    }
  };

  const saveSettings = form.handleSubmit((values) => {
    setSettings((current) => ({
      ...current,
      systemName: { ar: values.systemNameAr, en: values.systemNameEn },
      universityName: { ar: values.universityNameAr, en: values.universityNameEn },
      timezone: values.timezone,
      language: values.language,
      themeMode: values.themeMode,
      primaryGreen: values.primaryGreen,
      primaryBlue: values.primaryBlue,
      openAiModel: values.openAiModel,
      googleSheetId: values.googleSheetId,
      googleAppsScriptUrl: values.googleAppsScriptUrl,
      supabaseUrl: values.supabaseUrl,
    }));
  });

  return (
    <div className="space-y-4">
      <div className="grid gap-4 xl:grid-cols-[1fr_0.95fr]">
        <ShellCard className="p-5">
          <SectionHeader title={text.settings} actionLabel={text.saveSettings} />
          <form onSubmit={saveSettings} className="mt-4 grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2 rounded-3xl border border-slate-200/70 bg-slate-50/80 p-4 dark:border-slate-700 dark:bg-slate-800/60">
              <div className="mb-4 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-lg font-black text-slate-900 dark:text-white">{isArabic ? "الجهة" : "Entity"}</p>
                  <p className="text-sm text-slate-500 dark:text-slate-300">
                    {isArabic ? "إدارة اسم الجهة والأيقونة المعروضة في النظام." : "Manage the entity name and icon displayed in the system."}
                  </p>
                </div>
                <label className="inline-flex cursor-pointer items-center justify-center gap-2 rounded-2xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-3 text-sm font-bold text-emerald-700 transition hover:scale-[1.01] dark:text-emerald-300">
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(event) => {
                      const file = event.target.files?.[0];
                      if (!file) return;
                      const reader = new FileReader();
                      reader.onload = () => {
                        setSettings((current) => ({ ...current, logoDataUrl: String(reader.result || "") }));
                      };
                      reader.readAsDataURL(file);
                    }}
                  />
                  {settings.logoDataUrl ? (
                    <img src={settings.logoDataUrl} alt="Entity icon" className="h-8 w-8 rounded-xl object-cover" />
                  ) : (
                    <Plus className="h-5 w-5" />
                  )}
                  <span>{isArabic ? "إضافة أيقونة" : "Add Icon"}</span>
                </label>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label={isArabic ? "الجهة - الاسم بالعربية" : "Entity - Arabic Name"}>
                  <input {...form.register("universityNameAr")} className="field-input" />
                </Field>
                <Field label={isArabic ? "الجهة - الاسم بالإنجليزية" : "Entity - English Name"}>
                  <input {...form.register("universityNameEn")} className="field-input" />
                </Field>
              </div>
            </div>
            <div className="sm:col-span-2 rounded-3xl border border-slate-200/70 bg-white/70 p-4 dark:border-slate-700 dark:bg-slate-800/60">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
                <Field label={isArabic ? "إضافة جهة إلى قائمة التذاكر" : "Add Department / Organization"}>
                  <input
                    value={newDepartment}
                    onChange={(event) => setNewDepartment(event.target.value)}
                    className="field-input"
                    placeholder={isArabic ? "مثال: إدارة الدعم الفني" : "Example: IT Support Department"}
                  />
                </Field>
                <button
                  type="button"
                  onClick={() => {
                    const value = newDepartment.trim();
                    if (!value) return;
                    const newDep: Department = {
                      id: `DEP-${Math.floor(Math.random() * 9000 + 1000)}`,
                      name: { ar: value, en: value },
                      code: value.slice(0, 6).toUpperCase().replace(/\s/g, "-"),
                      enabled: true,
                      order: departments.length + 1,
                    };
                    setDepartments((current) => [...current, newDep]);
                    setNewDepartment("");
                  }}
                  className="inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-[var(--primary-blue)] px-5 py-3 text-sm font-bold text-white"
                >
                  <Plus className="h-4 w-4" />
                  {isArabic ? "إضافة" : "Add"}
                </button>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                {departments.map((department) => (
                  <span key={department.id} className="inline-flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-600 dark:bg-slate-700 dark:text-slate-200">
                    {localized(department.name, isArabic ? "ar" : "en")} ({department.code})
                    <button
                      type="button"
                      onClick={() => setDepartments((current) => current.filter((item) => item.id !== department.id))}
                      className="text-rose-500 hover:text-rose-600"
                      title={isArabic ? "حذف" : "Delete"}
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </span>
                ))}
              </div>
            </div>
            <Field label={`${text.systemName} - العربية`}>
              <input {...form.register("systemNameAr")} className="field-input" />
            </Field>
            <Field label={`${text.systemName} - English`}>
              <input {...form.register("systemNameEn")} className="field-input" />
            </Field>
            <Field label={text.timezone}>
              <input {...form.register("timezone")} className="field-input" />
            </Field>
            <Field label={text.language}>
              <select {...form.register("language")} className="field-input">
                <option value="ar">العربية</option>
                <option value="en">English</option>
              </select>
            </Field>
            <Field label={text.theme}>
              <select {...form.register("themeMode")} className="field-input">
                <option value="light">{isArabic ? "فاتح" : "Light"}</option>
                <option value="dark">{isArabic ? "داكن" : "Dark"}</option>
                <option value="system">{isArabic ? "تلقائي" : "System"}</option>
              </select>
            </Field>
            <label className="flex items-center justify-between gap-4 rounded-2xl border border-slate-200 bg-white/70 px-4 py-3 text-sm font-semibold text-slate-700 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-200">
              <span>{isArabic ? "أزرار الإجراءات المستديرة" : "Rounded Action Buttons"}</span>
              <input
                type="checkbox"
                checked={settings.roundedActions}
                onChange={(event) => setSettings((current) => ({ ...current, roundedActions: event.target.checked }))}
                className="h-5 w-5 accent-emerald-600"
              />
            </label>
            <Field label="OpenAI Model">
              <input {...form.register("openAiModel")} className="field-input" />
            </Field>
            <div className="sm:col-span-2 space-y-5 rounded-3xl border border-slate-200/70 bg-slate-50/80 p-5 dark:border-slate-700 dark:bg-slate-800/60">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h3 className="text-lg font-black text-slate-900 dark:text-white">{isArabic ? "إعدادات Google Sheets" : "Google Sheets Settings"}</h3>
                  <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{isArabic ? "ربط النظام بجدول بيانات Google للمزامنة والنسخ الاحتياطي" : "Connect the system to a Google Spreadsheet for sync and backup"}</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className={cn("flex items-center gap-2 rounded-full px-4 py-2 text-sm font-bold", connectionStatus === "connected" ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300" : connectionStatus === "checking" ? "bg-amber-500/10 text-amber-700 dark:text-amber-300" : "bg-rose-500/10 text-rose-700 dark:text-rose-300")}>
                    <div className={cn("h-2.5 w-2.5 rounded-full", connectionStatus === "connected" ? "bg-emerald-500" : connectionStatus === "checking" ? "bg-amber-500 animate-pulse" : "bg-rose-500")} />
                    {connectionStatus === "connected" 
                      ? (isArabic ? "متصل" : "Connected") 
                      : connectionStatus === "checking" 
                        ? (isArabic ? "جاري التحقق..." : "Checking...") 
                        : (isArabic ? "غير متصل" : "Disconnected")}
                  </div>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <Field label={isArabic ? "رابط Google Apps Script API" : "Google Apps Script URL"}>
                  <input {...form.register("googleAppsScriptUrl")} className="field-input" placeholder="https://script.google.com/macros/s/AKfycbx.../exec" />
                </Field>
                <Field label={isArabic ? "معرف جدول البيانات (Spreadsheet ID)" : "Google Spreadsheet ID"}>
                  <input {...form.register("googleSheetId")} className="field-input" placeholder="1A8_wm4SySpAcfNZWyGVpFYSxydNkiESy" />
                </Field>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="rounded-2xl border border-slate-200/70 bg-white/80 p-4 dark:border-slate-700 dark:bg-slate-900/60">
                  <h4 className="mb-3 text-sm font-bold text-slate-900 dark:text-white">{isArabic ? "المزامنة التلقائية" : "Auto Sync"}</h4>
                  <label className="flex items-center gap-3 text-sm font-semibold text-slate-700 dark:text-slate-200">
                    <input 
                      type="checkbox" 
                      checked={settings.googleSheetsEnabled} 
                      onChange={(e) => setSettings((s: any) => ({...s, googleSheetsEnabled: e.target.checked}))} 
                      className="h-5 w-5 accent-emerald-600 rounded" 
                    />
                    {isArabic ? "تفعيل المزامنة التلقائية" : "Enable Auto Sync"}
                  </label>
                  {settings.googleSheetsEnabled && (
                    <div className="mt-2 rounded-xl bg-emerald-500/5 px-3 py-2 text-xs text-emerald-700 dark:text-emerald-300">
                      {isArabic ? "✓ سيتم مزامنة البيانات تلقائياً عند كل عملية حفظ" : "✓ Data will auto-sync on every save operation"}
                    </div>
                  )}
                </div>

                <div className="rounded-2xl border border-slate-200/70 bg-white/80 p-4 dark:border-slate-700 dark:bg-slate-900/60">
                  <h4 className="mb-3 text-sm font-bold text-slate-900 dark:text-white">{isArabic ? "تردد النسخ الاحتياطي" : "Backup Frequency"}</h4>
                  <div className="space-y-2">
                    {[
                      { value: "manual", labelAr: "يدوي", labelEn: "Manual" },
                      { value: "daily", labelAr: "يومي", labelEn: "Daily" },
                      { value: "weekly", labelAr: "أسبوعي", labelEn: "Weekly" },
                    ].map((opt) => (
                      <label key={opt.value} className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-200">
                        <input 
                          type="radio" 
                          name="backupFrequency" 
                          value={opt.value} 
                          checked={(settings as any).backupFrequency === opt.value || (!((settings as any).backupFrequency) && opt.value === "manual")}
                          onChange={(e) => setSettings((s: any) => ({...s, backupFrequency: e.target.value}))}
                          className="h-4 w-4 accent-emerald-600" 
                        />
                        {isArabic ? opt.labelAr : opt.labelEn}
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-3 border-t border-slate-200/70 pt-4 dark:border-slate-700">
                <button 
                  type="button" 
                  disabled={isTestingConnection}
                  onClick={testConnection}
                  className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-700 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
                >
                  <RefreshCcw className={cn("h-4 w-4", isTestingConnection && "animate-spin")} />
                  {isArabic ? "اختبار الاتصال" : "Test Connection"}
                </button>
                <button 
                  type="button" 
                  onClick={async () => {
                    setConnectionStatus("checking");
                    try {
                      const url = form.getValues("googleAppsScriptUrl");
                      if (url) {
                        await fetch(url, { method: "POST", mode: "no-cors", body: JSON.stringify({ action: "sync_now", spreadsheetId: form.getValues("googleSheetId") }) });
                      }
                      setConnectionStatus("connected");
                      alert(isArabic ? "✅ تمت المزامنة بنجاح!" : "✅ Sync completed successfully!");
                    } catch {
                      setConnectionStatus("disconnected");
                      alert(isArabic ? "❌ فشلت المزامنة" : "❌ Sync failed");
                    }
                  }}
                  className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-[var(--primary-blue)] px-5 py-3 text-sm font-bold text-white shadow-lg shadow-emerald-500/20 transition hover:-translate-y-0.5"
                >
                  <RefreshCcw className="h-4 w-4" />
                  {isArabic ? "مزامنة الآن" : "Sync Now"}
                </button>
                <button 
                  type="button" 
                  onClick={() => {
                    const url = form.getValues("googleAppsScriptUrl");
                    const sheetId = form.getValues("googleSheetId");
                    if (url && sheetId) {
                      setSettings((s: any) => ({...s, googleAppsScriptUrl: url, googleSheetId: sheetId}));
                      setConnectionStatus("connected");
                      alert(isArabic ? "✅ تم الحفظ بنجاح!" : "✅ Saved successfully!");
                    } else {
                      alert(isArabic ? "يرجى ملء جميع الحقول" : "Please fill all fields");
                    }
                  }}
                  className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-700 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
                >
                  <Save className="h-4 w-4" />
                  {isArabic ? "حفظ" : "Save"}
                </button>
              </div>
            </div>
            <Field label="Supabase URL">
              <input {...form.register("supabaseUrl")} className="field-input" />
            </Field>
            <Field label={isArabic ? "اللون الأخضر" : "Primary Green"}>
              <input type="color" {...form.register("primaryGreen")} className="field-input h-12 p-2" />
            </Field>
            <Field label={isArabic ? "اللون الأزرق" : "Primary Blue"}>
              <input type="color" {...form.register("primaryBlue")} className="field-input h-12 p-2" />
            </Field>
            <Field label={isArabic ? "لون النجاح" : "Success Color"}>
              <input type="color" value={settings.successColor || "#22C55E"} onChange={(e) => setSettings(s => ({...s, successColor: e.target.value}))} className="field-input h-12 p-1" />
            </Field>
            <Field label={isArabic ? "لون التحذير" : "Warning Color"}>
              <input type="color" value={settings.warningColor || "#F59E0B"} onChange={(e) => setSettings(s => ({...s, warningColor: e.target.value}))} className="field-input h-12 p-1" />
            </Field>
            <Field label={isArabic ? "لون الخطأ" : "Danger Color"}>
              <input type="color" value={settings.dangerColor || "#EF4444"} onChange={(e) => setSettings(s => ({...s, dangerColor: e.target.value}))} className="field-input h-12 p-1" />
            </Field>
            <Field label={isArabic ? "لون الخلفية" : "Background Color"}>
              <input type="color" value={settings.bgColor || "#F8FAFC"} onChange={(e) => setSettings(s => ({...s, bgColor: e.target.value}))} className="field-input h-12 p-1" />
            </Field>
            <Field label={isArabic ? "لون البطاقات" : "Card Color"}>
              <input type="color" value={settings.cardColor || "#FFFFFF"} onChange={(e) => setSettings(s => ({...s, cardColor: e.target.value}))} className="field-input h-12 p-1" />
            </Field>
            <Field label={isArabic ? "لون الشريط العلوي" : "Header Color"}>
              <input type="color" value={settings.headerColor || "#FFFFFF"} onChange={(e) => setSettings(s => ({...s, headerColor: e.target.value}))} className="field-input h-12 p-1" />
            </Field>
            <Field label={isArabic ? "لون القائمة الجانبية" : "Sidebar Color"}>
              <input type="color" value={settings.sidebarColor || "#FFFFFF"} onChange={(e) => setSettings(s => ({...s, sidebarColor: e.target.value}))} className="field-input h-12 p-1" />
            </Field>
            <Field label={isArabic ? "لون الجداول" : "Table Color"}>
              <input type="color" value={settings.tableColor || "#FFFFFF"} onChange={(e) => setSettings(s => ({...s, tableColor: e.target.value}))} className="field-input h-12 p-1" />
            </Field>
            
            <div className="sm:col-span-2 rounded-3xl border border-slate-200/70 bg-slate-50/80 p-4 dark:border-slate-700 dark:bg-slate-800/60">
              <h3 className="text-lg font-black text-slate-900 dark:text-white mb-4">{isArabic ? "التدرج اللوني" : "Gradient Settings"}</h3>
              <label className="flex items-center gap-2 text-sm font-semibold text-slate-700 dark:text-slate-200 mb-4">
                <input type="checkbox" checked={settings.gradientEnabled} onChange={(e) => setSettings(s => ({...s, gradientEnabled: e.target.checked}))} className="h-5 w-5 accent-emerald-600" />
                {isArabic ? "تفعيل التدرج اللوني" : "Enable Gradient Mode"}
              </label>
              {settings.gradientEnabled && (
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label={isArabic ? "نوع التدرج" : "Gradient Type"}>
                    <select value={settings.gradientType} onChange={(e) => setSettings(s => ({...s, gradientType: e.target.value as any}))} className="field-input">
                      <option value="green-blue">Green → Blue</option>
                      <option value="blue-green">Blue → Green</option>
                      <option value="linear">Linear</option>
                      <option value="radial">Radial</option>
                      <option value="angle">Angle</option>
                    </select>
                  </Field>
                  {settings.gradientType === "angle" && (
                    <Field label={isArabic ? "زاوية التدرج" : "Gradient Angle"}>
                      <input type="number" value={settings.gradientAngle} onChange={(e) => setSettings(s => ({...s, gradientAngle: Number(e.target.value)}))} className="field-input" />
                    </Field>
                  )}
                  <Field label={isArabic ? "اللون الأول" : "Primary Color 1"}>
                    <input type="color" value={settings.primaryColor1 || "#0F8A5F"} onChange={(e) => setSettings(s => ({...s, primaryColor1: e.target.value}))} className="field-input h-12 p-1" />
                  </Field>
                  <Field label={isArabic ? "اللون الثاني" : "Primary Color 2"}>
                    <input type="color" value={settings.primaryColor2 || "#2563EB"} onChange={(e) => setSettings(s => ({...s, primaryColor2: e.target.value}))} className="field-input h-12 p-1" />
                  </Field>
                </div>
              )}
            </div>

            <div className="sm:col-span-2 rounded-3xl border border-slate-200/70 bg-slate-50/80 p-4 dark:border-slate-700 dark:bg-slate-800/60">
              <h3 className="text-lg font-black text-slate-900 dark:text-white mb-4">{isArabic ? "إعدادات الخطوط" : "Font Settings"}</h3>
              <div className="grid gap-4 sm:grid-cols-2 mb-4">
                <Field label={isArabic ? "خط عربي" : "Arabic Font"}>
                  <input value={settings.fontArabic} onChange={(e) => setSettings(s => ({...s, fontArabic: e.target.value}))} className="field-input" placeholder="system-ui, Tahoma, Arial" />
                </Field>
                <Field label={isArabic ? "خط إنجليزي" : "English Font"}>
                  <input value={settings.fontEnglish} onChange={(e) => setSettings(s => ({...s, fontEnglish: e.target.value}))} className="field-input" placeholder="Inter, system-ui, sans-serif" />
                </Field>
              </div>
              <div className="mb-4">
                <Field label={isArabic ? "حجم الخط" : "Font Size"}>
                  <select value={settings.fontSize} onChange={(e) => setSettings(s => ({...s, fontSize: e.target.value as any}))} className="field-input">
                    <option value="small">{isArabic ? "صغير" : "Small"}</option>
                    <option value="medium">{isArabic ? "متوسط" : "Medium"}</option>
                    <option value="large">{isArabic ? "كبير" : "Large"}</option>
                    <option value="xlarge">{isArabic ? "كبير جداً" : "Extra Large"}</option>
                    <option value="custom">{isArabic ? "مخصص" : "Custom"}</option>
                  </select>
                </Field>
                {settings.fontSize === "custom" && (
                  <Field label={isArabic ? "حجم مخصص (px)" : "Custom Size (px)"}>
                    <input type="number" value={settings.fontSizeCustom} onChange={(e) => setSettings(s => ({...s, fontSizeCustom: Number(e.target.value)}))} className="field-input" />
                  </Field>
                )}
              </div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-2">{isArabic ? "حجم كل عنصر" : "Element Font Sizes"}</h4>
              <div className="grid gap-3 sm:grid-cols-3">
                {[
                  { key: "fontSizeSystem", label: isArabic ? "عنوان النظام" : "System Title" },
                  { key: "fontSizePage", label: isArabic ? "عناوين الصفحات" : "Page Titles" },
                  { key: "fontSizeCard", label: isArabic ? "عناوين البطاقات" : "Card Titles" },
                  { key: "fontSizeTable", label: isArabic ? "الجداول" : "Tables" },
                  { key: "fontSizeMenu", label: isArabic ? "القوائم" : "Menus" },
                  { key: "fontSizeButton", label: isArabic ? "الأزرار" : "Buttons" },
                  { key: "fontSizeModal", label: isArabic ? "النوافذ المنبثقة" : "Modals" },
                  { key: "fontSizeReport", label: isArabic ? "التقارير" : "Reports" },
                  { key: "fontSizePrint", label: isArabic ? "الطباعة" : "Print" },
                ].map((item) => (
                  <Field key={item.key} label={item.label}>
                    <input type="number" value={settings[item.key as keyof AppSettings] as number} onChange={(e) => setSettings(s => ({...s, [item.key]: Number(e.target.value)}))} className="field-input" />
                  </Field>
                ))}
              </div>
            </div>

            <div className="sm:col-span-2 rounded-3xl border border-slate-200/70 bg-slate-50/80 p-4 dark:border-slate-700 dark:bg-slate-800/60">
              <h3 className="text-lg font-black text-slate-900 dark:text-white mb-4">{isArabic ? "إعدادات الطباعة المتقدمة" : "Advanced Print Settings"}</h3>
              <div className="grid gap-4 sm:grid-cols-2 mb-4">
                <Field label={isArabic ? "لون رأس الطباعة" : "Print Header Color"}>
                  <input type="color" value={settings.printHeaderBg} onChange={(e) => setSettings(s => ({...s, printHeaderBg: e.target.value}))} className="field-input h-12 p-1" />
                </Field>
                <Field label={isArabic ? "لون تذييل الطباعة" : "Print Footer Color"}>
                  <input type="color" value={settings.printFooterBg} onChange={(e) => setSettings(s => ({...s, printFooterBg: e.target.value}))} className="field-input h-12 p-1" />
                </Field>
                <Field label={isArabic ? "لون عنوان التقرير" : "Report Title Color"}>
                  <input type="color" value={settings.printTitleColor || "#0F8A5F"} onChange={(e) => setSettings(s => ({...s, printTitleColor: e.target.value}))} className="field-input h-12 p-1" />
                </Field>
                <Field label={isArabic ? "لون الجداول" : "Table Color"}>
                  <input type="color" value={settings.printTableColor || "#f8fafc"} onChange={(e) => setSettings(s => ({...s, printTableColor: e.target.value}))} className="field-input h-12 p-1" />
                </Field>
                <Field label={isArabic ? "لون الحدود" : "Border Color"}>
                  <input type="color" value={settings.printBorderColor || "#e2e8f0"} onChange={(e) => setSettings(s => ({...s, printBorderColor: e.target.value}))} className="field-input h-12 p-1" />
                </Field>
                <Field label={isArabic ? "لون النص" : "Text Color"}>
                  <input type="color" value={settings.printTextColor || "#0f172a"} onChange={(e) => setSettings(s => ({...s, printTextColor: e.target.value}))} className="field-input h-12 p-1" />
                </Field>
              </div>
              <div className="grid gap-4 sm:grid-cols-2 mb-4">
                <Field label={isArabic ? "خط عربي للطباعة" : "Arabic Print Font"}>
                  <input value={settings.printFontArabic} onChange={(e) => setSettings(s => ({...s, printFontArabic: e.target.value}))} className="field-input" />
                </Field>
                <Field label={isArabic ? "خط إنجليزي للطباعة" : "English Print Font"}>
                  <input value={settings.printFontEnglish} onChange={(e) => setSettings(s => ({...s, printFontEnglish: e.target.value}))} className="field-input" />
                </Field>
                <Field label={isArabic ? "حجم العناوين" : "Title Size"}>
                  <input type="number" value={settings.printTitleSize} onChange={(e) => setSettings(s => ({...s, printTitleSize: Number(e.target.value)}))} className="field-input" />
                </Field>
                <Field label={isArabic ? "حجم الجداول" : "Table Size"}>
                  <input type="number" value={settings.printTableSize} onChange={(e) => setSettings(s => ({...s, printTableSize: Number(e.target.value)}))} className="field-input" />
                </Field>
                <Field label={isArabic ? "حجم التذييل" : "Footer Size"}>
                  <input type="number" value={settings.printFooterSize} onChange={(e) => setSettings(s => ({...s, printFooterSize: Number(e.target.value)}))} className="field-input" />
                </Field>
              </div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-2">{isArabic ? "خيارات الشعار" : "Logo Options"}</h4>
              <div className="flex flex-wrap gap-4 mb-4">
                <label className="flex items-center gap-2 text-sm font-semibold text-slate-700 dark:text-slate-200">
                  <input type="checkbox" checked={settings.showPrintLogo} onChange={(e) => setSettings(s => ({...s, showPrintLogo: e.target.checked}))} className="h-5 w-5 accent-emerald-600" />
                  {isArabic ? "إظهار الشعار" : "Show Logo"}
                </label>
                <label className="flex items-center gap-2 text-sm font-semibold text-slate-700 dark:text-slate-200">
                  <input type="checkbox" checked={settings.showOrgLogo} onChange={(e) => setSettings(s => ({...s, showOrgLogo: e.target.checked}))} className="h-5 w-5 accent-emerald-600" />
                  {isArabic ? "شعار المؤسسة" : "Org Logo"}
                </label>
                <label className="flex items-center gap-2 text-sm font-semibold text-slate-700 dark:text-slate-200">
                  <input type="checkbox" checked={settings.footerLogo} onChange={(e) => setSettings(s => ({...s, footerLogo: e.target.checked}))} className="h-5 w-5 accent-emerald-600" />
                  {isArabic ? "شعار بالتذييل" : "Footer Logo"}
                </label>
              </div>
              <div className="grid gap-4 sm:grid-cols-2 mb-4">
                <Field label={isArabic ? "حجم الشعار" : "Logo Size"}>
                  <select value={settings.logoSize} onChange={(e) => setSettings(s => ({...s, logoSize: e.target.value as any}))} className="field-input">
                    <option value="small">{isArabic ? "صغير" : "Small"}</option>
                    <option value="medium">{isArabic ? "متوسط" : "Medium"}</option>
                    <option value="large">{isArabic ? "كبير" : "Large"}</option>
                  </select>
                </Field>
                <Field label={isArabic ? "موضع الشعار" : "Logo Position"}>
                  <select value={settings.logoPosition} onChange={(e) => setSettings(s => ({...s, logoPosition: e.target.value as any}))} className="field-input">
                    <option value="right">{isArabic ? "يمين" : "Right"}</option>
                    <option value="left">{isArabic ? "يسار" : "Left"}</option>
                    <option value="center">{isArabic ? "وسط" : "Center"}</option>
                  </select>
                </Field>
              </div>
              <div className="grid gap-4 sm:grid-cols-2 mb-4">
                <label className="flex items-center gap-2 text-sm font-semibold text-slate-700 dark:text-slate-200">
                  <input type="checkbox" checked={settings.showPrintFooter} onChange={(e) => setSettings(s => ({...s, showPrintFooter: e.target.checked}))} className="h-5 w-5 accent-emerald-600" />
                  {isArabic ? "إظهار التذييل" : "Show Footer"}
                </label>
              </div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-2">{isArabic ? "الحقول المطبوعة" : "Printed Fields"}</h4>
              <div className="flex flex-wrap gap-3 mb-4">
                {[
                  { key: "title", label: isArabic ? "عنوان المهمة" : "Title" },
                  { key: "service", label: isArabic ? "نوع الخدمة" : "Service Type" },
                  { key: "description", label: isArabic ? "الوصف" : "Description" },
                  { key: "priority", label: isArabic ? "الأولوية" : "Priority" },
                  { key: "status", label: isArabic ? "الحالة" : "Status" },
                  { key: "createdDate", label: isArabic ? "تاريخ الإنشاء" : "Created Date" },
                  { key: "executionDate", label: isArabic ? "تاريخ التنفيذ" : "Execution Date" },
                  { key: "location", label: isArabic ? "الموقع" : "Location" },
                  { key: "finalResolution", label: isArabic ? "الحل النهائي" : "Final Resolution" },
                  { key: "actionsTaken", label: isArabic ? "الإجراءات" : "Actions Taken" },
                ].map((field) => (
                  <label key={field.key} className="flex items-center gap-2 text-xs font-semibold text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-900 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700">
                    <input 
                      type="checkbox" 
                      checked={(settings.printedFields || []).includes(field.key)} 
                      onChange={(e) => {
                        const current = settings.printedFields || [];
                        const next = e.target.checked ? [...current, field.key] : current.filter(k => k !== field.key);
                        setSettings(s => ({...s, printedFields: next}));
                      }} 
                      className="h-4 w-4 accent-emerald-600" 
                    />
                    {field.label}
                  </label>
                ))}
              </div>
              <Field label={isArabic ? "نص التذييل" : "Footer Text"}>
                <textarea value={settings.footerText.ar} onChange={(e) => setSettings(s => ({...s, footerText: {...s.footerText, ar: e.target.value}}))} className="field-input min-h-16" placeholder={isArabic ? "نص عربي" : "Arabic text"} />
              </Field>
              <Field label={isArabic ? "نص التذييل بالإنجليزية" : "Footer Text (English)"}>
                <textarea value={settings.footerText.en} onChange={(e) => setSettings(s => ({...s, footerText: {...s.footerText, en: e.target.value}}))} className="field-input min-h-16" placeholder="English text" />
              </Field>
            </div>

            <div className="sm:col-span-2 rounded-3xl border border-slate-200/70 bg-slate-50/80 p-4 dark:border-slate-700 dark:bg-slate-800/60">
              <h3 className="text-lg font-black text-slate-900 dark:text-white mb-4">{isArabic ? "حفظ القوالب" : "Template Management"}</h3>
              <div className="flex flex-wrap gap-3">
                <button type="button" onClick={() => { window.localStorage.setItem("theme-template", JSON.stringify(settings)); }} className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-[var(--primary-blue)] px-4 py-2.5 text-sm font-bold text-white">
                  💾 {isArabic ? "حفظ قالب المظهر" : "Save Theme"}
                </button>
                <button type="button" onClick={() => { window.localStorage.setItem("print-template", JSON.stringify(settings)); }} className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200">
                  🖨️ {isArabic ? "حفظ قالب الطباعة" : "Save Print Template"}
                </button>
                <button type="button" onClick={() => { const blob = new Blob([JSON.stringify(settings, null, 2)], {type: "application/json"}); const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = "theme-export.json"; a.click(); URL.revokeObjectURL(url); }} className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200">
                  📤 {isArabic ? "تصدير المظهر" : "Export Theme"}
                </button>
                <label className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 cursor-pointer dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200">
                  📥 {isArabic ? "استيراد المظهر" : "Import Theme"}
                  <input type="file" accept=".json" className="hidden" onChange={(e) => { const file = e.target.files?.[0]; if (!file) return; const reader = new FileReader(); reader.onload = () => { try { const data = JSON.parse(reader.result as string); setSettings({...defaultSettings, ...data}); } catch {} }; reader.readAsText(file); }} />
                </label>
                <button type="button" onClick={() => setSettings(defaultSettings)} className="inline-flex items-center gap-2 rounded-2xl border border-rose-200 px-4 py-2.5 text-sm font-semibold text-rose-600 dark:border-rose-500/30 dark:text-rose-300">
                  🔄 {isArabic ? "استعادة الافتراضي" : "Restore Default"}
                </button>
              </div>
            </div>

            <div className="sm:col-span-2">
              <button type="submit" className="rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-[var(--primary-blue)] px-5 py-3 text-sm font-bold text-white">
                {text.saveSettings}
              </button>
            </div>
          </form>
        </ShellCard>

        <div className="space-y-4">
          <ShellCard className="p-5">
            <SectionHeader title={text.integrations} actionLabel={text.configured} />
            <div className="mt-4 space-y-3">
              {integrationsCatalog.map((integration) => {
                const IntegrationIcon = integration.id === "supabase" ? Database : integration.id === "google-sheets" ? Sheet : Brain;
                const ready = integration.id === "supabase" ? Boolean(supabase) : integration.id === "google-sheets" ? settings.googleSheetsEnabled : settings.openAiEnabled;
                return (
                  <div key={integration.id} className="rounded-3xl border border-slate-200/70 bg-white/80 p-4 dark:border-slate-700 dark:bg-slate-800/80">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <IntegrationIcon className="h-11 w-11 rounded-2xl bg-emerald-500/10 p-2 text-emerald-600 dark:text-emerald-300" />
                        <div>
                          <div className="font-bold text-slate-900 dark:text-white">{integration.name}</div>
                          <div className="text-xs text-slate-500 dark:text-slate-400">{integration.description}</div>
                        </div>
                      </div>
                      <div className={cn("rounded-full px-3 py-1 text-xs font-bold", ready ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300" : "bg-amber-500/10 text-amber-700 dark:text-amber-300") }>
                        {ready ? text.configured : text.draft}
                      </div>
                    </div>
                    <div className="mt-3 text-xs text-slate-400">
                      {integration.id === "supabase" ? supabaseUrl : integration.id === "google-sheets" ? settings.googleSheetId : settings.openAiModel}
                    </div>
                  </div>
                );
              })}
            </div>
          </ShellCard>

          <ShellCard className="p-5">
            <SectionHeader title={text.realtimeStatus} actionLabel={text.overview} />
            <div className="mt-4 space-y-3">
              <QuickMetricRow label="Supabase" value={settings.supabaseEnabled ? "Online" : "Paused"} accent="bg-emerald-500" />
              <QuickMetricRow label="Google Sheets Sync" value={settings.googleSheetsEnabled ? "Ready" : "Off"} accent="bg-blue-500" />
              <QuickMetricRow label="OpenAI Assistant" value={settings.openAiEnabled ? settings.openAiModel : "Disabled"} accent="bg-fuchsia-500" />
              <QuickMetricRow label={isArabic ? "حفظ التفضيلات" : "Preferences Saved"} value={text.settingsSaved} accent="bg-slate-500" />
            </div>
          </ShellCard>
        </div>
      </div>
    </div>
  );
}

function TaskEditorModal({
  open,
  onOpenChange,
  onSubmit,
  services,
  departments,
  deviceTypes,
  teamMembers,
  language,
  settings,
  editingTask,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (values: TaskFormValues) => void;
  services: Service[];
  departments: Department[];
  deviceTypes: DeviceType[];
  teamMembers: TeamMember[];
  language: Language;
  settings: AppSettings;
  editingTask: Task | null;
}) {
  const isArabic = language === "ar";
  const today = new Date().toISOString().slice(0, 10);
  const nextTaskNumber = useMemo(
    () => editingTask?.id || `TASK-${new Date().getFullYear()}-${Math.floor(Math.random() * 9000 + 1000)}`,
    [editingTask?.id, open],
  );
  const [dragActive, setDragActive] = useState(false);

  const form = useForm<TaskFormValues>({
    resolver: zodResolver(taskFormSchema),
    defaultValues: {
      id: nextTaskNumber,
      status: "New",
      department: departments[0]?.id || defaultDepartments[0]?.id || "",
      employeeName: "",
      serviceId: services[0]?.id || "",
      deviceType: deviceTypes[0]?.id || defaultDeviceTypes[0]?.id || "",
      priority: "Medium",
      technicianName: teamMembers.find((m) => m.enabled)?.name.ar || "",
      createdDate: today,
      executionDate: today,
      notes: "",
      actionsTaken: "",
      finalResolution: "",
      attachments: "",
    },
  });

  const enabledDepartments = departments.filter((dep) => dep.enabled);
  const attachmentsValue = form.watch("attachments") || "";
  const attachmentNames = attachmentsValue
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);

  const appendAttachments = (files: FileList | File[]) => {
    const nextFiles = Array.from(files).map((file) => file.name);
    const merged = Array.from(new Set([...attachmentNames, ...nextFiles]));
    form.setValue("attachments", merged.join(", "), { shouldDirty: true, shouldValidate: true });
  };

  useEffect(() => {
    if (!editingTask) {
      form.reset({
        id: nextTaskNumber,
        status: "New",
        department: departments[0]?.id || defaultDepartments[0]?.id || "",
        employeeName: "",
        serviceId: services[0]?.id || "",
        deviceType: deviceTypes[0]?.id || defaultDeviceTypes[0]?.id || "",
        priority: "Medium",
        technicianName: teamMembers.find((m) => m.enabled)?.name.ar || "",
        createdDate: today,
        executionDate: today,
        notes: "",
        actionsTaken: "",
        finalResolution: "",
        attachments: "",
      });
      return;
    }

    form.reset({
      id: editingTask.id,
      status: (ticketStatusOptions.includes(editingTask.status) ? editingTask.status : "New") as TaskFormValues["status"],
      department: editingTask.department || editingTask.location.ar || departments[0]?.id || "",
      employeeName: editingTask.employeeName || editingTask.title.ar.replace("تذكرة دعم فني -", "").trim(),
      serviceId: editingTask.serviceId,
      deviceType: editingTask.deviceType || deviceTypes[0]?.id || "",
      priority: editingTask.priority,
      technicianName: editingTask.technicianName || editingTask.assignee || teamMembers.find((m) => m.enabled)?.name.ar || "",
      createdDate: getDateInputValue(editingTask.createdDate || editingTask.startDate),
      executionDate: getDateInputValue(editingTask.executionDate || editingTask.dueDate),
      notes: editingTask.notes.ar,
      actionsTaken: editingTask.actionsTaken?.ar || "",
      finalResolution: editingTask.finalResolution?.ar || "",
      attachments: editingTask.attachments.join(", "),
    });
  }, [departments, editingTask, form, nextTaskNumber, services, today]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="max-h-[92vh] w-full max-w-5xl overflow-y-auto rounded-[2rem] border border-white/60 bg-white p-6 shadow-2xl dark:border-slate-700 dark:bg-slate-900">
        <div className="mb-5 flex items-center justify-between">
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-300">TICKET / TASK FORM</p>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">
              {editingTask ? (isArabic ? "تعديل تذكرة دعم فني" : "Edit IT Support Ticket") : isArabic ? "تذكرة دعم فني جديدة" : "New IT Support Ticket"}
            </h2>
          </div>
          <button type="button" onClick={() => onOpenChange(false)} className="rounded-2xl border border-slate-200 p-2 dark:border-slate-700">
            <X className="h-5 w-5" />
          </button>
        </div>
        <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4 sm:grid-cols-2">
          <Field label={isArabic ? "رقم المهمة" : "Task Number"}>
            <input {...form.register("id")} readOnly className="field-input bg-slate-100 font-bold dark:bg-slate-800" />
          </Field>
          <Field label={isArabic ? "حالة المهمة" : "Task Status"}>
            <select {...form.register("status")} className="field-input">
              {ticketStatusOptions.map((status) => (
                <option key={status} value={status}>
                  {localized(statusLabels[status], language)}
                </option>
              ))}
            </select>
          </Field>
          <Field label={isArabic ? "الجهة" : "Department / Organization"}>
            <select {...form.register("department")} className="field-input">
              {enabledDepartments.map((dep) => (
                <option key={dep.id} value={dep.id}>
                  {localized(dep.name, language)} ({dep.code})
                </option>
              ))}
            </select>
          </Field>
          <Field label={isArabic ? "اسم الموظف/ة" : "Employee Name"}>
            <input {...form.register("employeeName")} className="field-input" />
          </Field>
          <Field label={isArabic ? "نوع الخدمة" : "Service Type"}>
            <select {...form.register("serviceId")} className="field-input">
              {services.map((service) => (
                <option key={service.id} value={service.id}>
                  {service.iconData.type === "emoji" ? service.iconData.value : "🛠️"} {localized(service.name, language)}
                </option>
              ))}
            </select>
          </Field>
          <Field label={isArabic ? "نوع الجهاز" : "Device Type"}>
            <select {...form.register("deviceType")} className="field-input">
              {deviceTypes.filter((dt) => dt.enabled).map((dt) => (
                <option key={dt.id} value={dt.id}>
                  {dt.iconData.type === "emoji" ? dt.iconData.value : "📟"} {localized(dt.name, language)}
                </option>
              ))}
            </select>
          </Field>
          <Field label={isArabic ? "الأولوية" : "Priority"}>
            <select {...form.register("priority")} className="field-input">
              {priorityOrder.map((priority) => (
                <option key={priority} value={priority}>
                  {localized(priorityLabels[priority], language)}
                </option>
              ))}
            </select>
          </Field>
          <Field label={isArabic ? "اسم الفني" : "Technician Name"}>
            <select {...form.register("technicianName")} className="field-input">
              {teamMembers.filter((m) => m.enabled).map((member) => (
                <option key={member.id} value={localized(member.name, language)}>
                  {localized(member.name, language)} — {localized(member.jobTitle, language)}
                </option>
              ))}
            </select>
          </Field>
          <Field label={isArabic ? "تاريخ الإنشاء" : "Created Date"}>
            <input type="date" {...form.register("createdDate")} readOnly className="field-input bg-slate-100 dark:bg-slate-800" />
          </Field>
          <Field label={isArabic ? "تاريخ التنفيذ" : "Execution Date"}>
            <input type="date" {...form.register("executionDate")} className="field-input" />
          </Field>
          <Field label={isArabic ? "الملاحظات" : "Notes"}>
            <textarea {...form.register("notes")} className="field-input min-h-28" />
          </Field>
          <Field label={isArabic ? "الإجراءات التي تم تنفيذها" : "Actions Taken"}>
            <textarea {...form.register("actionsTaken")} className="field-input min-h-28" />
          </Field>
          <div className="sm:col-span-2">
            <Field label={isArabic ? "الحل النهائي" : "Final Resolution"}>
              <textarea {...form.register("finalResolution")} className="field-input min-h-28" />
            </Field>
          </div>
          <div className="sm:col-span-2">
            <Field label={isArabic ? "المرفقات" : "Attachments"}>
              <div
                onDragOver={(event) => {
                  event.preventDefault();
                  setDragActive(true);
                }}
                onDragLeave={() => setDragActive(false)}
                onDrop={(event) => {
                  event.preventDefault();
                  setDragActive(false);
                  appendAttachments(event.dataTransfer.files);
                }}
                className={cn(
                  "rounded-3xl border border-dashed p-5 text-center transition",
                  dragActive
                    ? "border-emerald-500 bg-emerald-500/10"
                    : "border-slate-300 bg-slate-50/80 dark:border-slate-700 dark:bg-slate-800/60",
                )}
              >
                <Paperclip className="mx-auto h-9 w-9 text-emerald-600 dark:text-emerald-300" />
                <p className="mt-2 text-sm font-semibold text-slate-700 dark:text-slate-200">
                  {isArabic ? "اسحب وأفلت الملفات هنا أو استخدم زر إضافة المرفقات" : "Drag and drop files here or use Add Attachments"}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400">PDF, Word, Excel, Images</p>
                <input {...form.register("attachments")} readOnly className="field-input mt-3" />
                {attachmentNames.length ? (
                  <div className="mt-3 flex flex-wrap justify-center gap-2">
                    {attachmentNames.map((attachment) => (
                      <span key={attachment} className="rounded-full bg-blue-500/10 px-3 py-1 text-xs font-bold text-blue-700 dark:text-blue-300">
                        {attachment}
                      </span>
                    ))}
                  </div>
                ) : null}
              </div>
            </Field>
          </div>
          <div className="sm:col-span-2 flex flex-wrap justify-end gap-3">
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-2xl border border-slate-200 px-5 py-3 text-sm font-semibold text-slate-700 transition hover:shadow-md dark:border-slate-700 dark:text-slate-200">
              <input type="file" multiple accept="image/*,.pdf,.doc,.docx,.xls,.xlsx" className="hidden" onChange={(event) => event.target.files && appendAttachments(event.target.files)} />
              <Paperclip className="h-4 w-4" />
              {isArabic ? "إضافة المرفقات" : "Add Attachments"}
            </label>
            <button type="submit" className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-[var(--primary-green)] to-[var(--primary-blue)] px-5 py-3 text-sm font-bold text-white">
              <Save className="h-4 w-4" />
              {isArabic ? "حفظ المهمة" : "Save Task"}
            </button>
            <button
              type="button"
              onClick={() => editingTask && printTaskDocument(editingTask, language, settings)}
              disabled={!editingTask}
              className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 px-5 py-3 text-sm font-semibold text-slate-700 transition hover:shadow-md disabled:cursor-not-allowed disabled:opacity-50 dark:border-slate-700 dark:text-slate-200"
            >
              <Printer className="h-4 w-4" />
              {isArabic ? "طباعة" : "Print"}
            </button>
            {editingTask ? (
              <button type="submit" className="inline-flex items-center gap-2 rounded-2xl border border-blue-200 px-5 py-3 text-sm font-semibold text-blue-700 transition hover:shadow-md dark:border-blue-500/30 dark:text-blue-300">
                <Pencil className="h-4 w-4" />
                {isArabic ? "تعديل" : "Edit"}
              </button>
            ) : null}
            <button type="button" onClick={() => onOpenChange(false)} className="inline-flex items-center gap-2 rounded-2xl border border-rose-200 px-5 py-3 text-sm font-semibold text-rose-600 dark:border-rose-500/30 dark:text-rose-300">
              <X className="h-4 w-4" />
              {isArabic ? "إلغاء" : "Cancel"}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

function SearchModal({
  open,
  onClose,
  results,
  searchTerm,
  setSearchTerm,
  placeholder,
  onSelect,
}: {
  open: boolean;
  onClose: () => void;
  results: SearchResult[];
  searchTerm: string;
  setSearchTerm: React.Dispatch<React.SetStateAction<string>>;
  placeholder: string;
  onSelect: (route: string) => void;
}) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-slate-950/60 p-4 pt-20 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-3xl rounded-[2rem] border border-white/60 bg-white p-5 shadow-2xl dark:border-slate-700 dark:bg-slate-900">
        <div className="flex items-center gap-3 rounded-3xl border border-slate-200 bg-slate-50 px-4 py-3 dark:border-slate-700 dark:bg-slate-800">
          <Search className="h-5 w-5 text-slate-400" />
          <input
            autoFocus
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
            placeholder={placeholder}
            className="w-full bg-transparent text-sm outline-none"
          />
          <button type="button" onClick={onClose} className="rounded-2xl border border-slate-200 p-2 dark:border-slate-700">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="mt-4 max-h-[60vh] overflow-y-auto">
          {results.length ? (
            <div className="space-y-2">
              {results.map((result) => (
                <button
                  key={result.id}
                  type="button"
                  onClick={() => onSelect(result.route)}
                  className="flex w-full items-start justify-between rounded-3xl border border-slate-200/70 bg-white/80 p-4 text-start transition hover:border-emerald-500/20 hover:bg-emerald-500/5 dark:border-slate-700 dark:bg-slate-800/80"
                >
                  <div>
                    <div className="font-semibold text-slate-900 dark:text-white">{result.title}</div>
                    <div className="text-sm text-slate-500 dark:text-slate-300">{result.subtitle}</div>
                  </div>
                  <div className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold capitalize text-slate-600 dark:bg-slate-700 dark:text-slate-200">
                    {result.type}
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="rounded-3xl border border-dashed border-slate-300 p-10 text-center text-sm text-slate-500 dark:border-slate-700 dark:text-slate-300">
              {searchTerm ? "No matches found." : "Start typing to search across the platform."}
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}

function MessagesModal({
  open,
  onClose,
  messages,
  language,
}: {
  open: boolean;
  onClose: () => void;
  messages: MessageItem[];
  language: Language;
}) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-slate-950/60 p-4 pt-20 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-2xl rounded-[2rem] border border-white/60 bg-white p-5 shadow-2xl dark:border-slate-700 dark:bg-slate-900">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-2xl font-black text-slate-900 dark:text-white">{language === "ar" ? "الرسائل" : "Messages"}</h3>
          <button type="button" onClick={onClose} className="rounded-2xl border border-slate-200 p-2 dark:border-slate-700">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="space-y-3">
          {messages.map((message) => (
            <div key={message.id} className="rounded-3xl border border-slate-200/70 bg-white/80 p-4 dark:border-slate-700 dark:bg-slate-800/80">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="font-bold text-slate-900 dark:text-white">{localized(message.subject, language)}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">{message.sender}</div>
                </div>
                <div className="text-xs text-slate-400">{message.time}</div>
              </div>
              <div className="mt-2 text-sm text-slate-500 dark:text-slate-300">{localized(message.preview, language)}</div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}

function TaskDetailModal({ task, onClose, language }: { task: Task | null; onClose: () => void; language: Language }) {
  if (!task) return null;
  const isArabic = language === "ar";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-2xl rounded-[2rem] border border-white/60 bg-white p-6 shadow-2xl dark:border-slate-700 dark:bg-slate-900">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-2xl font-black text-slate-900 dark:text-white">{localized(task.title, language)}</h3>
          <button type="button" onClick={onClose} className="rounded-2xl border border-slate-200 p-2 dark:border-slate-700">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="space-y-4">
          <div className="flex flex-wrap gap-2">
            <Badge className={getPriorityColor(task.priority)}>{localized(priorityLabels[task.priority], language)}</Badge>
            <Badge className={getTaskStatusColor(task.status)}>{localized(statusLabels[task.status], language)}</Badge>
          </div>
          <p className="text-sm leading-7 text-slate-600 dark:text-slate-300">{localized(task.description, language)}</p>
          <div className="grid gap-3 sm:grid-cols-2">
            <MetricTile label={isArabic ? "الخدمة" : "Service"} value={localized(task.service, language)} />
            <MetricTile label={isArabic ? "المسؤول" : "Assignee"} value={task.assignee} />
            <MetricTile label={isArabic ? "الموقع" : "Location"} value={localized(task.location, language)} />
            <MetricTile label={isArabic ? "الاستحقاق" : "Due Date"} value={getDateInputValue(task.dueDate)} />
          </div>
          <div className="rounded-3xl border border-slate-200/70 bg-white/80 p-4 dark:border-slate-700 dark:bg-slate-800/80">
            <div className="mb-2 text-sm font-bold text-slate-900 dark:text-white">{isArabic ? "المرفقات" : "Attachments"}</div>
            <div className="flex flex-wrap gap-2">
              {task.attachments.map((attachment) => (
                <span key={attachment} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-600 dark:bg-slate-700 dark:text-slate-200">
                  {attachment}
                </span>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function TaskAiModal({ task, onClose, language }: { task: Task | null; onClose: () => void; language: Language }) {
  if (!task) return null;
  const isArabic = language === "ar";
  const suggestions: LocalizedText[] = [
    {
      ar: `الأولوية الحالية ${localized(priorityLabels[task.priority], "ar")} وتحتاج متابعة خلال ${task.timeLabel}.`,
      en: `Current priority is ${localized(priorityLabels[task.priority], "en")} and should be revisited around ${task.timeLabel}.`,
    },
    {
      ar: task.status === "Delayed" ? "اقترح إعادة الجدولة وإشعار المسؤول فورًا." : "استمر في التنفيذ مع تحديث الحالة بعد الانتهاء من الخطوة الحالية.",
      en: task.status === "Delayed" ? "Recommend rescheduling and notifying the owner immediately." : "Continue execution and update status after the current step.",
    },
    {
      ar: `أفضل خدمة مرتبطة بهذه المهمة هي ${localized(task.service, "ar")} مع دعم تعاوني من الفريق.`,
      en: `The best linked service for this task is ${localized(task.service, "en")} with collaborative team support.`,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm">
      <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-2xl rounded-[2rem] border border-white/60 bg-white p-6 shadow-2xl dark:border-slate-700 dark:bg-slate-900">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <div className="text-sm text-slate-500 dark:text-slate-300">{isArabic ? "تحليل AI" : "AI Analysis"}</div>
            <h3 className="text-2xl font-black text-slate-900 dark:text-white">{localized(task.title, language)}</h3>
          </div>
          <button type="button" onClick={onClose} className="rounded-2xl border border-slate-200 p-2 dark:border-slate-700">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="space-y-3">
          {suggestions.map((suggestion) => (
            <div key={suggestion.en} className="rounded-3xl border border-emerald-500/10 bg-emerald-500/5 p-4 text-sm text-slate-600 dark:text-slate-200">
              {localized(suggestion, language)}
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}

function ShellCard({
  children,
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "rounded-[2rem] border border-white/70 bg-white/75 shadow-xl shadow-slate-200/60 backdrop-blur-xl transition-transform duration-200 hover:-translate-y-0.5 dark:border-slate-800 dark:bg-slate-900/70 dark:shadow-slate-950/30",
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
}

function ChartCard({ 
  title, 
  children, 
  isEmpty 
}: { 
  title: string; 
  children: React.ReactNode;
  isEmpty?: boolean;
}) {
  return (
    <ShellCard className="p-5">
      <SectionHeader title={title} actionLabel="" />
      <div className="mt-4 h-[260px] relative">
        {isEmpty ? (
          <div className="absolute inset-0 flex items-center justify-center text-slate-400 text-sm font-medium">
            No Data Available
          </div>
        ) : children}
      </div>
    </ShellCard>
  );
}

function SectionHeader({ title, actionLabel }: { title: string; actionLabel: string }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <h3 className="text-xl font-black text-slate-900 dark:text-white">{title}</h3>
      {actionLabel ? <div className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600 dark:bg-slate-800 dark:text-slate-200">{actionLabel}</div> : null}
    </div>
  );
}

function Badge({ className, children }: { className?: string; children: React.ReactNode }) {
  return <span className={cn("rounded-full px-3 py-1 text-xs font-bold", className)}>{children}</span>;
}

function QuickMetricRow({ label, value, accent }: { label: string; value: string | number; accent: string }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200/70 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-800/80">
      <div className="flex items-center gap-3">
        <span className={cn("h-3 w-3 rounded-full", accent)} />
        <span className="text-sm text-slate-600 dark:text-slate-200">{label}</span>
      </div>
      <span className="text-lg font-black text-slate-900 dark:text-white">{value}</span>
    </div>
  );
}

function MetricTile({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-3xl border border-slate-200/70 bg-white/80 p-4 text-center dark:border-slate-700 dark:bg-slate-800/80">
      <div className="text-xs font-medium text-slate-500 dark:text-slate-300">{label}</div>
      <div className="mt-2 text-xl font-black text-slate-900 dark:text-white">{value}</div>
    </div>
  );
}

function DynamicIcon({ icon, className, size = 24 }: { icon?: any; className?: string; size?: number }) {
  if (!icon) return null;
  const data = icon as any;
  if (data.type === "emoji") {
    return <span className={cn("inline-flex items-center justify-center", className)} style={{ fontSize: size }}>{data.value}</span>;
  }
  if (data.type === "lucide") {
    const LucideIcon = iconMap[data.value] || Settings;
    return <LucideIcon className={className} size={size} />;
  }
  if (data.type === "image") {
    return <img src={data.value} className={cn("object-contain", className)} style={{ width: size, height: size }} alt="Icon" />;
  }
  return null;
}

function IconPicker({ 
  value, 
  onChange, 
  isArabic 
}: { 
  value: any; 
  onChange: (data: any) => void; 
  isArabic: boolean 
}) {
  const [activeTab, setActiveTab] = useState<"emoji" | "lucide" | "image">(value?.type || "emoji");
  const emojis = ["💻", "🌐", "🖨️", "📠", "📧", "⚙️", "🖥️", "🏛️", "📺", "📽️", "📞", "📡", "🔌", "🛡️", "📷", "🎤", "📱", "🖧", "🔧", "🧩", "💡"];
  const lucideIcons = Object.keys(iconMap);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      onChange({ type: "image", value: reader.result as string });
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-3 rounded-2xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-900/50">
      <div className="flex gap-2">
        {(["emoji", "lucide", "image"] as const).map((tab) => (
          <button
            key={tab}
            type="button"
            onClick={() => setActiveTab(tab)}
            className={cn(
              "flex-1 rounded-xl px-3 py-2 text-xs font-bold transition",
              activeTab === tab 
                ? "bg-[var(--primary-green)] text-white shadow-sm" 
                : "bg-white text-slate-600 hover:bg-slate-100 dark:bg-slate-800 dark:text-slate-300"
            )}
          >
            {tab === "emoji" ? (isArabic ? "إيموجي" : "Emoji") : 
             tab === "lucide" ? (isArabic ? "أيقونة" : "Lucide") : 
             (isArabic ? "صورة" : "Image")}
          </button>
        ))}
      </div>

      <div className="max-h-40 overflow-y-auto">
        {activeTab === "emoji" && (
          <div className="grid grid-cols-6 gap-2">
            {emojis.map((e) => (
              <button
                key={e}
                type="button"
                onClick={() => onChange({ type: "emoji", value: e })}
                className={cn(
                  "flex h-10 items-center justify-center rounded-xl text-xl transition hover:bg-white dark:hover:bg-slate-800",
                  value?.type === "emoji" && value?.value === e && "ring-2 ring-[var(--primary-green)] bg-white dark:bg-slate-800"
                )}
              >
                {e}
              </button>
            ))}
          </div>
        )}

        {activeTab === "lucide" && (
          <div className="grid grid-cols-6 gap-2">
            {lucideIcons.map((name) => {
              const Icon = iconMap[name];
              return (
                <button
                  key={name}
                  type="button"
                  onClick={() => onChange({ type: "lucide", value: name })}
                  className={cn(
                    "flex h-10 items-center justify-center rounded-xl transition hover:bg-white dark:hover:bg-slate-800",
                    value?.type === "lucide" && value?.value === name && "ring-2 ring-[var(--primary-green)] bg-white dark:bg-slate-800"
                  )}
                  title={name}
                >
                  <Icon size={20} />
                </button>
              );
            })}
          </div>
        )}

        {activeTab === "image" && (
          <div className="space-y-3">
            <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-slate-300 p-4 transition hover:border-[var(--primary-green)] dark:border-slate-700">
              <Upload size={24} className="text-slate-400" />
              <span className="text-xs text-slate-500">{isArabic ? "اختر صورة" : "Choose image"}</span>
              <input type="file" className="hidden" accept="image/*" onChange={handleFileUpload} />
            </label>
            {value?.type === "image" && (
              <div className="flex items-center gap-3 rounded-xl bg-white p-2 dark:bg-slate-800">
                <img src={value.value} className="h-10 w-10 rounded-lg object-contain" alt="Preview" />
                <span className="text-[10px] text-slate-500 line-clamp-1">{isArabic ? "تم رفع الصورة" : "Image uploaded"}</span>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="flex items-center justify-between border-t border-slate-200 pt-3 dark:border-slate-700">
        <span className="text-xs font-semibold text-slate-500">{isArabic ? "المعاينة:" : "Preview:"}</span>
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white shadow-sm dark:bg-slate-800">
          <DynamicIcon icon={value} size={24} />
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-semibold text-slate-600 dark:text-slate-300">{label}</span>
      {children}
    </label>
  );
}

function IconButton({
  children,
  onClick,
  label,
  badge,
}: {
  children: React.ReactNode;
  onClick: () => void;
  label: string;
  badge?: number;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={label}
      className="relative inline-flex h-12 w-12 items-center justify-center rounded-2xl border border-slate-200 bg-white text-slate-700 shadow-sm transition hover:border-slate-300 hover:shadow-md dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
    >
      {children}
      {badge ? (
        <span className="absolute -end-1 -top-1 inline-flex min-h-5 min-w-5 items-center justify-center rounded-full bg-emerald-500 px-1 text-[10px] font-bold text-white">
          {badge}
        </span>
      ) : null}
    </button>
  );
}

function ActionIconButton({
  children,
  onClick,
  label,
  tone = "default",
  rounded,
}: {
  children: React.ReactNode;
  onClick: () => void;
  label: string;
  tone?: "default" | "danger";
  rounded: boolean;
}) {
  return (
    <button
      type="button"
      title={label}
      onClick={onClick}
      className={cn(
        "inline-flex h-9 w-9 items-center justify-center border bg-white/95 shadow-[0_6px_18px_rgba(15,23,42,0.08)] backdrop-blur transition duration-200 hover:-translate-y-0.5 hover:scale-105 hover:shadow-[0_10px_24px_rgba(15,23,42,0.14)] active:scale-95 dark:bg-slate-900/90",
        rounded ? "rounded-full" : "rounded-xl",
        tone === "danger"
          ? "border-rose-200 text-rose-600 dark:border-rose-500/30 dark:text-rose-300"
          : "border-slate-200 text-slate-700 dark:border-slate-700 dark:text-slate-200",
      )}
    >
      {children}
    </button>
  );
}

export default App;
